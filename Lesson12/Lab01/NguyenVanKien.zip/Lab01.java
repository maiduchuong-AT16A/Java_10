/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CT090126_Lession12_Lab1_NguyenVanKien;

/**
 *
 * @author Admin
 */
import java.util.*;
import java.text.*;
public class Lab01 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhap so testcase cho bai 1:");
        int t1 = sc.nextInt();
        for (int i = 1; i <= t1; i++) { 
            int day = sc.nextInt(); 
            int month = sc.nextInt() - 1; 
            int year = sc.nextInt();

            Calendar cal = Calendar.getInstance(); 
            cal.clear(); 
            cal.set(year, month, day); 
            Date date = cal.getTime(); 

            System.out.println("Case #" + i + ":"); 
            System.out.println(date); 
        }
        SimpleDateFormat sdf = new SimpleDateFormat("EEE dd-MM-yyyy");
        System.out.println("Nhap so testcase cho bai 2:");
        int t2 = sc.nextInt();
        for(int i = 1 ;i<=t2;i++){
            int day = sc.nextInt();
            int month = sc.nextInt()-1;
            int year = sc.nextInt();
            
            Calendar cal = Calendar.getInstance();
            cal.set(year,month, day);
            System.out.println("Case#"  + i + ":");
            System.out.println(sdf.format(cal.getTime()));
            
            Calendar startOfWeek = (Calendar) cal.clone(); 
            startOfWeek.setFirstDayOfWeek(Calendar.MONDAY);
            startOfWeek.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
            System.out.println(sdf.format(startOfWeek.getTime())); 

            Calendar endOfWeek = (Calendar) cal.clone(); 
            endOfWeek.setFirstDayOfWeek(Calendar.MONDAY); 
            endOfWeek.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
            System.out.println(sdf.format(endOfWeek.getTime()));
        }
        System.out.println("Nhap so testcase cho bai 3:");
        int t3 = sc.nextInt();
        for(int i = 1; i<=t3;i++){
            int day = sc.nextInt();
            int month = sc.nextInt()-1;
            int year = sc.nextInt();
            
            Calendar cal = Calendar.getInstance();
            cal.set(year,month, day);
            
            System.out.println("Case#"+i+":");
            System.out.println(sdf.format(cal.getTime()));
            
            cal.add(Calendar.DAY_OF_MONTH,-1);
            System.out.println(sdf.format(cal.getTime()));
            
            cal.add(Calendar.DAY_OF_MONTH, 2);
            System.out.println(sdf.format(cal.getTime()));
            
            cal.set(Calendar.DAY_OF_MONTH, 1); 
            System.out.println(sdf.format(cal.getTime())); 

            cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH)); 
            System.out.println(sdf.format(cal.getTime()));
        }
    }
}
