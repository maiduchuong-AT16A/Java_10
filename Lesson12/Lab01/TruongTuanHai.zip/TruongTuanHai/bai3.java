/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.actvn.lession12.lab01.TruongTuanHai;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class bai3 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        SimpleDateFormat sdf = new SimpleDateFormat("E dd-MM-yyyy");

        for (int i = 1; i <= t; i++) {
            int day = sc.nextInt();
            int month = sc.nextInt();
            int year = sc.nextInt();
            Calendar cal = new GregorianCalendar(year, month - 1, day);

            System.out.println("Case #" + i + ":");
            System.out.println(sdf.format(cal.getTime()));

            cal.add(Calendar.DATE, -1);
            System.out.println(sdf.format(cal.getTime()));

            cal.add(Calendar.DATE, 2);
            System.out.println(sdf.format(cal.getTime()));

            cal.set(Calendar.DAY_OF_MONTH, 1);
            System.out.println(sdf.format(cal.getTime()));

            cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
            System.out.println(sdf.format(cal.getTime()));
        }
    }
}
