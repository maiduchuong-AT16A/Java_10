package Lab01;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.Scanner;
import java.util.TimeZone;

public class bai03 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int T = sc.nextInt();
        int count = 1;

        SimpleDateFormat df = new SimpleDateFormat("EEE dd-MM-yyyy");

        for (int t = 1; t <= T; t++) {

            Calendar cal = Calendar.getInstance();
            int d = sc.nextInt();
            int m = sc.nextInt();
            int y = sc.nextInt();

            cal.set(Calendar.DAY_OF_MONTH, d);
            cal.set(Calendar.MONTH, m - 1);
            cal.set(Calendar.YEAR, y);
            System.out.printf("CASE #%d:\n", count++);

            System.out.println(df.format(cal.getTime()));

            cal.add(Calendar.DAY_OF_MONTH, -1);
            System.out.println(df.format(cal.getTime()));

            cal.add(Calendar.DAY_OF_MONTH, 2);
            System.out.println(df.format(cal.getTime()));

            cal.set(Calendar.DAY_OF_MONTH, d);
            cal.set(Calendar.MONTH, m - 1);
            cal.set(Calendar.YEAR, y);

            cal.set(Calendar.DAY_OF_MONTH, 1);
            System.out.println(df.format(cal.getTime()));

            int maxDay = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
            cal.set(Calendar.DAY_OF_MONTH, maxDay);
            System.out.println(df.format(cal.getTime()));
        }
    }
}
