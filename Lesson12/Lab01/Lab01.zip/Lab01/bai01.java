package Lab01;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Scanner;
import java.util.TimeZone;

public class bai01 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        Calendar cal = Calendar.getInstance();
        int count = 1;
        SimpleDateFormat df = new SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy", Locale.ENGLISH);
        df.setTimeZone(TimeZone.getTimeZone("Asia/Bangkok"));

        for (int i = 0; i < t; i++) {
            cal = Calendar.getInstance();
            int d = sc.nextInt();
            int m = sc.nextInt();
            int y = sc.nextInt();
            cal.set(Calendar.DAY_OF_MONTH, d);
            cal.set(Calendar.MONTH, m - 1);
            cal.set(Calendar.YEAR, y);
            System.out.printf("CASE #%d:\n", count++);

            Date date = cal.getTime();
            System.out.println(df.format(date));
        }

    }
}
