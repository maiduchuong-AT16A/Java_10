package Lab01;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

public class bai02 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        Calendar cal = Calendar.getInstance();
        int count = 1;
        SimpleDateFormat df = new SimpleDateFormat("EEE dd-MM-yyyy");

        for (int i = 0; i < t; i++) {
            cal = Calendar.getInstance();
            int d = sc.nextInt();
            int m = sc.nextInt();
            int y = sc.nextInt();
            cal.set(Calendar.DAY_OF_MONTH, d);
            cal.set(Calendar.MONTH, m - 1);
            cal.set(Calendar.YEAR, y);
            System.out.printf("CASE #%d:\n", count++);
            Date date1 = cal.getTime();
            System.out.println(df.format(date1));

            int now = cal.get(Calendar.DAY_OF_WEEK);
            if (now != 2) {
                cal.add(Calendar.DAY_OF_MONTH, -(now - 2));
            }
            Date date2 = cal.getTime();
            System.out.println(df.format(date2));

            cal.set(Calendar.DAY_OF_MONTH, d);
            cal.set(Calendar.MONTH, m - 1);
            cal.set(Calendar.YEAR, y);

            if (now != 1) {
                cal.add(Calendar.DAY_OF_MONTH, (8-now));
            }
            Date date3 = cal.getTime();
            System.out.println(df.format(date3));
        }

    }
}
