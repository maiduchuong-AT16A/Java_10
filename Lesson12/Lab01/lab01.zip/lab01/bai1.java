/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.act.vn.lesson12;

import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author manh
 */
public class bai1 {
    //B1
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        for(int i =0;i<t;i++)
        {
            int day = sc. nextInt();
            int month = sc.nextInt();
            int year = sc.nextInt();
            Calendar cal = Calendar.getInstance();
            cal.set(year, month-1, day, 0, 0, 0);
            Date date = cal.getTime();
            System.out.printf("Case #%d:\n",i+1);
            System.out.println(date.toString());
            
        }
        
    }
}
