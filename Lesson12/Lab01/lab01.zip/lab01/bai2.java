/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.act.vn.lesson12;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author manh
 */
public class bai2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        SimpleDateFormat df = new SimpleDateFormat("EEE dd-MM-yyyy");
        for (int i = 0; i < t; i++) {
            int day = sc.nextInt();
            int month = sc.nextInt();
            int year = sc.nextInt();
            Calendar cal = Calendar.getInstance();
            cal.set(year, month-1, day);
            Date inputDate = cal.getTime();
            System.out.printf("Case #%d:\n", i + 1);
            System.out.println(df.format(inputDate));
            int now = cal.get(Calendar.DAY_OF_WEEK);
            if(now!=2)
            {
                cal.add(Calendar.DAY_OF_MONTH, -(now-2));
            }
            Date date2 = cal.getTime();
            System.out.println(df.format(date2));
            cal.set(year, month-1, day);
            if(now!=1)
            {
                cal.add(Calendar.DAY_OF_MONTH, 8-now);
            }
             Date date3 = cal.getTime();
            System.out.println(df.format(date3));
        }
    }
}
