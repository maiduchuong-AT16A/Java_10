/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.act.vn.lesson12;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author manh
 */
public class bai3 {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        SimpleDateFormat df = new SimpleDateFormat("EEE dd-MM-yyyy");
        int t = sc.nextInt();
        for (int i = 0; i < t; i++) {
            int day = sc.nextInt();
            int month = sc.nextInt();
            int year = sc.nextInt();
            Calendar cal = Calendar.getInstance();
            cal.set(year, month - 1, day);
            Date inputDate = cal.getTime();
            System.out.printf("Case #%d:\n", i + 1);
            System.out.println(df.format(inputDate));
            cal.add(Calendar.DAY_OF_MONTH, -1);
            System.out.println(df.format(cal.getTime()));
            cal.add(Calendar.DAY_OF_MONTH, 2);
            System.out.println(df.format(cal.getTime()));
            cal.set(year, month - 1, day);
            int now = cal.get(Calendar.DAY_OF_MONTH);
            if (now != 1) {
                cal.add(Calendar.DAY_OF_MONTH, -(now - 1));
            }
            System.out.println(df.format(cal.getTime()));
            int max = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
            cal.set(Calendar.DAY_OF_MONTH, max);
            System.out.println(df.format(cal.getTime()));
        }
    }
}
