/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab01_bai12;

/**
 *
 * @author OS
 */
import java.text.SimpleDateFormat;
import java.util.Scanner;
import java.util.Date;
import java.util.Calendar;

public class Bai2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        
        SimpleDateFormat sdf = new SimpleDateFormat("EEE dd-MM-yyyy");

        for(int i = 1; i <= n; i++){
            Calendar cal = Calendar.getInstance();
            
            int ngay = sc.nextInt();
            int thang = sc.nextInt();
            int nam = sc.nextInt();
            
            cal.set(nam, thang - 1, ngay);
            
            Date inputDate = cal.getTime();
            
            Calendar firstDay = (Calendar) cal.clone();
            int dayToMonday = (firstDay.get(Calendar.DAY_OF_WEEK) - 2 + 7) % 7;
            firstDay.add(Calendar.DATE, -dayToMonday);
            
            Calendar lastDay = (Calendar) cal.clone();
            int dayToSunday = (1 - lastDay.get(Calendar.DAY_OF_WEEK) + 7) % 7;
            lastDay.add(Calendar.DATE, dayToSunday);
            
            System.out.println("Case #" + i + ":");
            System.out.println(sdf.format(inputDate));
            System.out.println(sdf.format(firstDay.getTime()));
            System.out.println(sdf.format(lastDay.getTime()));
        }
    }
}
 