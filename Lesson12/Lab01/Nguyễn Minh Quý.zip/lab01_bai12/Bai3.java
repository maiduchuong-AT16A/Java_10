/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab01_bai12;

/**
 *
 * @author OS
 */
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Scanner;

public class Bai3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt(); 
        SimpleDateFormat sdf = new SimpleDateFormat("EEE dd-MM-yyyy");

        for (int i = 1; i <= n; i++) {
            int ngay = sc.nextInt();
            int thang = sc.nextInt();
            int nam = sc.nextInt();

            Calendar cal = Calendar.getInstance();
            cal.set(nam, thang - 1, ngay);
            
            Calendar truoc = (Calendar) cal.clone();
            truoc.add(Calendar.DATE, -1);

            Calendar sau = (Calendar) cal.clone();
            sau.add(Calendar.DATE, 1);

            Calendar dauThang = (Calendar) cal.clone();
            dauThang.set(Calendar.DAY_OF_MONTH, 1);

            Calendar cuoiThang = (Calendar) cal.clone();
            int ngayCuoi = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
            cuoiThang.set(Calendar.DAY_OF_MONTH, ngayCuoi);

            System.out.println("Case #" + i + ":");
            System.out.println(sdf.format(cal.getTime()));
            System.out.println(sdf.format(truoc.getTime()));
            System.out.println(sdf.format(sau.getTime()));
            System.out.println(sdf.format(dauThang.getTime()));
            System.out.println(sdf.format(cuoiThang.getTime()));
        }
    }
}