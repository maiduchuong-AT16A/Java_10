/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab01_bai12;

/**
 *
 * @author OS
 */
import java.util.Scanner;
import java.util.Calendar;
import java.util.Date;


public class Bai1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        
        for(int i = 1; i <= n; i++){
            int ngay = scanner.nextInt();
            int thang = scanner.nextInt();
            int nam = scanner.nextInt();
            
            Calendar cal = Calendar.getInstance();
            cal.set(nam, thang - 1, ngay);
            
            Date date = cal.getTime();
            
            System.out.println("Case #" + i + ":");
            System.out.println(date.toString());
        }
    }
}

