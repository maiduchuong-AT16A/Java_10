package com.act.vn.Lesson12.Nguyen_Thanh_Tuan.Lab01;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.Scanner;

public class Bai3 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        SimpleDateFormat sdf = new SimpleDateFormat("EEE dd-MM-yyyy", Locale.ENGLISH);
        int T = sc.nextInt();
        for (int t = 1; t <= T; t++) {
            int day = sc.nextInt();
            int month = sc.nextInt();
            int year = sc.nextInt();

            Calendar cal = Calendar.getInstance();
            cal.set(year, month - 1, day);

            Calendar beforDay = (Calendar) cal.clone();
            beforDay.add(Calendar.DATE, -1);

            Calendar afterDay = (Calendar) cal.clone();
            afterDay.add(Calendar.DATE, 1);

            Calendar firstMonth = (Calendar) cal.clone();
            firstMonth.set(Calendar.DAY_OF_MONTH, 1);

            Calendar lastMonth = (Calendar) cal.clone();
            int lastDay = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
            lastMonth.set(Calendar.DAY_OF_MONTH, lastDay);

            System.out.println("Case #" + t + ":");
            System.out.println(sdf.format(cal.getTime()));
            System.out.println(sdf.format(beforDay.getTime()));
            System.out.println(sdf.format(afterDay.getTime()));
            System.out.println(sdf.format(firstMonth.getTime()));
            System.out.println(sdf.format(lastMonth.getTime()));

        }
        sc.close();
    }
}
