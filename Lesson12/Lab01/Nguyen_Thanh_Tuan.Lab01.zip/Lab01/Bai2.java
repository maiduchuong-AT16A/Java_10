package com.act.vn.Lesson12.Nguyen_Thanh_Tuan.Lab01;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Scanner;

public class Bai2 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        SimpleDateFormat sdf = new SimpleDateFormat("EEE dd-MM-yyyy", Locale.ENGLISH);
        int T = sc.nextInt();
        for (int t = 1; t <= T; t++) {
            int day = sc.nextInt();
            int month = sc.nextInt();
            int year = sc.nextInt();

            Calendar cal = Calendar.getInstance();
            cal.set(year, month - 1, day);

            Date inputDate = cal.getTime();
            Calendar firstDay = (Calendar) cal.clone();
            int dayToMonDay = (firstDay.get(Calendar.DAY_OF_WEEK) - 2 + 7) % 7;
            firstDay.add(Calendar.DATE, -dayToMonDay);

            Calendar lastDay = (Calendar) cal.clone();
            int dayToSunday = (1 - lastDay.get(Calendar.DAY_OF_WEEK) + 7) % 7;
            lastDay.add(Calendar.DATE, dayToSunday);

            System.out.println("Case #" + t + ":");
            System.out.println(sdf.format(inputDate));
            System.out.println(sdf.format(firstDay.getTime()));
            System.out.println(sdf.format(lastDay.getTime()));
        }
        sc.close();
    }
}
