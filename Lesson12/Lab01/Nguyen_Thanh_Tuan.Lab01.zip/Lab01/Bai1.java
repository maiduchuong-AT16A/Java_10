package com.act.vn.Lesson12.Nguyen_Thanh_Tuan.Lab01;

import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

public class Bai1 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int T = sc.nextInt();
        for (int t = 1; t <= T; t++) {
            int day = sc.nextInt();
            int month = sc.nextInt();
            int year = sc.nextInt();

            Calendar cal = Calendar.getInstance();
            cal.set(year, month - 1, day);

            Date date = cal.getTime();
            System.out.println("Case #" + t + ":");
            System.out.println(date.toString());
        }
        sc.close();
    }
}
