
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author manh
 */
public class bailab022 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        for (int i = 0; i < t; i++) {
            int day1 = sc.nextInt();
            int month1 = sc.nextInt();
            int year1 = sc.nextInt();
            int gio1 = sc.nextInt();
            int phut1 = sc.nextInt();
            int giay1 = sc.nextInt();
            int day2 = sc.nextInt();
            int month2 = sc.nextInt();
            int year2 = sc.nextInt();
            int gio2 = sc.nextInt();
            int phut2 = sc.nextInt();
            int giay2 = sc.nextInt();
            LocalDateTime date1 = LocalDateTime.of(year1, month1, day1, gio1, phut1, giay1);
            LocalDateTime date2 = LocalDateTime.of(year2, month2, day2, gio2, phut2, giay2);
            if (date1.isAfter(date2)) {
                LocalDateTime tmp = date1;
                date1 = date2;
                date2 = tmp;
            }
            Duration dr = Duration.between(date1, date2);
            long totalsecond = dr.getSeconds();
            long days = totalsecond / (24 * 3600);
            totalsecond %= (24 * 3600);
            long hours = totalsecond / 3600;
            totalsecond %= 3600;
            long minutes = totalsecond / 60;
            long second = totalsecond % 60;
            System.out.printf("Case #%d:\n", i+1);
            System.out.printf("Difference between (%02d/%02d/%d %02d:%02d:%02d) and (%02d/%02d/%d %02d:%02d:%02d):\n",
                    day1, month1, year1, gio1, phut1, giay1, day2, month2, year2, gio2, phut2, giay2);
            System.out.printf("%d Days, %d Hours, %d Minutes, %d Seconds\n\n",
                    days, hours, minutes, second);
        }
    }
}
