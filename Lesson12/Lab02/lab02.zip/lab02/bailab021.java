
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.Calendar;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author manh
 */
public class bailab021 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        for (int i = 0; i < t; i++) {
            int day1 = sc.nextInt();
            int month1 = sc.nextInt();
            int year1 = sc.nextInt();
            int day2 = sc.nextInt();
            int month2 = sc.nextInt();
            int year2 = sc.nextInt();
            LocalDate date1 = LocalDate.of(year1, month1, day1);
            LocalDate date2 = LocalDate.of(year2, month2, day2);
            Period p = Period.between(date1, date2);
            System.out.printf("Case #%d:\n", i + 1);
            System.out.printf("Difference between %02d/%02d/%02d and %02d/%02d/%02d:\n", day1, month1, year1, day2, month2, year2);
            System.out.printf("%d Year(s), %d Month(s), %d Day(s)\n", Math.abs(p.getYears()), Math.abs(p.getMonths()), Math.abs(p.getDays()));
        }
    }
}
