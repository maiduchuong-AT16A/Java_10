/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.actvn.lession12.lab02.TruongTuanHai;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class bai2 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");

        for (int i = 1; i <= t; i++) {
            int d1 = sc.nextInt(), m1 = sc.nextInt(), y1 = sc.nextInt();
            int h1 = sc.nextInt(), min1 = sc.nextInt(), s1 = sc.nextInt();
            int d2 = sc.nextInt(), m2 = sc.nextInt(), y2 = sc.nextInt();
            int h2 = sc.nextInt(), min2 = sc.nextInt(), s2 = sc.nextInt();

            LocalDateTime dt1 = LocalDateTime.of(y1, m1, d1, h1, min1, s1);
            LocalDateTime dt2 = LocalDateTime.of(y2, m2, d2, h2, min2, s2);

            Duration duration = Duration.between(dt1, dt2);
            long seconds = Math.abs(duration.getSeconds());

            long days = seconds / (24 * 3600);
            seconds %= (24 * 3600);
            long hours = seconds / 3600;
            seconds %= 3600;
            long minutes = seconds / 60;
            seconds %= 60;

            System.out.printf("Case #%d:\n", i);
            System.out.println("Difference between (" + dt1.format(formatter) + ") and (" + dt2.format(formatter) + "):");
            System.out.printf("%d Days, %d Hours, %d Minutes, %d Seconds\n", days, hours, minutes, seconds);
        }
    }
}
