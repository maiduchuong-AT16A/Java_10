/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.actvn.lession12.lab02.TruongTuanHai;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class bai1 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        for (int i = 1; i <= t; i++) {
            int d1 = sc.nextInt(), m1 = sc.nextInt(), y1 = sc.nextInt();
            int d2 = sc.nextInt(), m2 = sc.nextInt(), y2 = sc.nextInt();

            LocalDate date1 = LocalDate.of(y1, m1, d1);
            LocalDate date2 = LocalDate.of(y2, m2, d2);

            Period period = Period.between(date1, date2);
            if (period.isNegative()) {
                period = period.negated();
            }

            System.out.printf("Case #%d:\n", i);
            System.out.println("Difference between " + date1.format(formatter) + " and " + date2.format(formatter) + ":");
            System.out.printf("%d Year(s), %d Month(s), %d Day(s)\n",
                    period.getYears(), period.getMonths(), period.getDays());
        }
    }
}
