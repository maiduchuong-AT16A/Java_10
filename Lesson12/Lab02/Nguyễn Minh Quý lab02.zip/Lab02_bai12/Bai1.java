/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lab02_bai12;

/**
 *
 * @author OS
 */
import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

public class Bai1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int soLuongCase = sc.nextInt();

        for (int i = 1; i <= soLuongCase; i++) {
            int ngay1 = sc.nextInt();
            int thang1 = sc.nextInt();
            int nam1 = sc.nextInt();

            int ngay2 = sc.nextInt();
            int thang2 = sc.nextInt();
            int nam2 = sc.nextInt();

            LocalDate date1 = LocalDate.of(nam1, thang1, ngay1);
            LocalDate date2 = LocalDate.of(nam2, thang2, ngay2);

            if (date1.isAfter(date2)) {
                LocalDate temp = date1;
                date1 = date2;
                date2 = temp;
            }

            Period chenhLech = Period.between(date1, date2);

            System.out.printf("Case #%d:\n", i);
            System.out.printf("Difference between %02d/%02d/%d and %02d/%02d/%d:\n",
                    date1.getDayOfMonth(), date1.getMonthValue(), date1.getYear(),
                    date2.getDayOfMonth(), date2.getMonthValue(), date2.getYear());

            System.out.printf("%d Year(s), %d Month(s), %d Day(s)\n\n",
                    chenhLech.getYears(), chenhLech.getMonths(), chenhLech.getDays());
        }
    }
}
