/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lab02_bai12;

/**
 *
 * @author OS
 */
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Bai2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();

        for (int t = 1; t <= n; t++) {
            int d1 = sc.nextInt(), m1 = sc.nextInt(), y1 = sc.nextInt();
            int h1 = sc.nextInt(), min1 = sc.nextInt(), s1 = sc.nextInt();
            
            LocalDateTime time1 = LocalDateTime.of(y1, m1, d1, h1, min1, s1);

            int d2 = sc.nextInt(), m2 = sc.nextInt(), y2 = sc.nextInt();
            int h2 = sc.nextInt(), min2 = sc.nextInt(), s2 = sc.nextInt();
            
            LocalDateTime time2 = LocalDateTime.of(y2, m2, d2, h2, min2, s2);
            if (time1.isAfter(time2)) {f(y2, m2, d2, h2, min2, s2);

                LocalDateTime temp = time1;
                time1 = time2;
                time2 = temp;
            }

            Duration duration = Duration.between(time1, time2);
            long totalSeconds = duration.getSeconds();

            long days = totalSeconds / (24 * 3600);
            totalSeconds %= (24 * 3600);
            long hours = totalSeconds / 3600;
            totalSeconds %= 3600;
            long minutes = totalSeconds / 60;
            long seconds = totalSeconds % 60;

            DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");

            System.out.println("Case #" + t + ":");
            System.out.println("Difference between (" + time1.format(fmt) + ") and (" + time2.format(fmt) + "):");
            System.out.println(days + " Days, " + hours + " Hours, " + minutes + " Minutes, " + seconds + " Seconds");
        }
    }

    private static void f(int y2, int m2, int d2, int h2, int min2, int s2) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
