package com.act.vn.Lesson12.Nguyen_Thanh_Tuan.Lab02;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Bai1 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        int T = sc.nextInt();

        for (int t = 1; t <= T; t++) {
            int day_1 = sc.nextInt();
            int month_1 = sc.nextInt();
            int year_1 = sc.nextInt();
            LocalDate date_1 = LocalDate.of(year_1, month_1, day_1);

            int day_2 = sc.nextInt();
            int month_2 = sc.nextInt();
            int year_2 = sc.nextInt();
            LocalDate date_2 = LocalDate.of(year_2, month_2, day_2);

            if (date_1.isAfter(date_2)) {
                LocalDate temp = date_2;
                date_2 = date_1;
                date_1 = temp;
            }

            Period period = Period.between(date_1, date_2);

            System.out.println("Case #" + t + ":");
            System.err.println("Difference between " + date_1.format(format) + " and " + date_2.format(format) + ":");
            System.out.println(period.getYears() + " Year(s), " + period.getMonths() + " Month(s), " + period.getDays() + " Day(s)");
        }
        sc.close();
    }
}
