package com.act.vn.Lesson12.Nguyen_Thanh_Tuan.Lab02;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Bai2 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:MM:ss");
        int T = sc.nextInt();

        for (int t = 1; t <= T; t++) {
            int day1 = sc.nextInt();
            int month1 = sc.nextInt();
            int year1 = sc.nextInt();
            int hour1 = sc.nextInt();
            int minute1 = sc.nextInt();
            int second1 = sc.nextInt();

            int day2 = sc.nextInt();
            int month2 = sc.nextInt();
            int year2 = sc.nextInt();
            int hour2 = sc.nextInt();
            int minute2 = sc.nextInt();
            int second2 = sc.nextInt();

            LocalDateTime firstDateTime = LocalDateTime.of(year1, month1, day1, hour1, minute1, second1);
            LocalDateTime secondDateTime = LocalDateTime.of(year2, month2, day2, hour2, minute2, second2);

            if (firstDateTime.isAfter(secondDateTime)) {
                LocalDateTime temp = firstDateTime;
                firstDateTime = secondDateTime;
                secondDateTime = temp;
            }

            Duration duration = Duration.between(firstDateTime, secondDateTime);

            long days = duration.toDays();
            long hours = duration.toHours() % 24;
            long mintues = duration.toMinutes() % 60;
            long seconds = duration.toSeconds() % 60;

            System.out.println("Case #" + t + ":");
            System.out.println("Difference between (" + firstDateTime.format(format) + ") and (" + secondDateTime.format(format) + "):");
            System.out.println(days + " Days, " + hours + " Hours, " + mintues + " Minutes, " + seconds + " Seconds");
        }
    }
}
