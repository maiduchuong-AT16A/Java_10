package Lab02;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class bai02 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int T = sc.nextInt();

        for (int t = 1; t <= T; t++) {
            int d1 = sc.nextInt(), m1 = sc.nextInt(), y1 = sc.nextInt();
            int h1 = sc.nextInt(), min1 = sc.nextInt(), s1 = sc.nextInt();

            int d2 = sc.nextInt(), m2 = sc.nextInt(), y2 = sc.nextInt();
            int h2 = sc.nextInt(), min2 = sc.nextInt(), s2 = sc.nextInt();

            LocalDateTime date1 = LocalDateTime.of(y1, m1, d1, h1, min1, s1);
            LocalDateTime date2 = LocalDateTime.of(y2, m2, d2, h2, min2, s2);

            if (date1.isAfter(date2)) {
                LocalDateTime tmp = date1;
                date1 = date2;
                date2 = tmp;
            }
            long datedif = ChronoUnit.DAYS.between(date1, date2);
            long totalseconddif = ChronoUnit.SECONDS.between(date1, date2);
            long seconddif = totalseconddif - datedif * 86400;
            long hoursdif = seconddif / 3600;
            long minutedif = (seconddif - hoursdif * 3600) / 60;
            long lastsecdif = seconddif - hoursdif * 3600 - minutedif * 60;

            System.out.printf("Case #%d:\n", t);
            System.out.printf("Difference between (%02d/%02d/%d %02d:%02d:%02d) and (%02d/%02d/%d %02d:%02d:%02d):\n",
                    d1, m1, y1, h1, min1, s1, d2, m2, y2, h2, min2, s2);
            System.out.printf("%d Days, %d Hours, %d Minutes, %d Seconds\n\n",
                    datedif, hoursdif, minutedif, lastsecdif);
        }
    }
}
