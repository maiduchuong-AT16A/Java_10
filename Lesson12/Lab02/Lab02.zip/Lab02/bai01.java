package Lab02;

import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

public class bai01 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int T = sc.nextInt();

        for (int t = 1; t <= T; t++) {
            int d1 = sc.nextInt();
            int m1 = sc.nextInt();
            int y1 = sc.nextInt();
            int d2 = sc.nextInt();
            int m2 = sc.nextInt();
            int y2 = sc.nextInt();

            LocalDate date1 = LocalDate.of(y1, m1, d1);
            LocalDate date2 = LocalDate.of(y2, m2, d2);

            Period p = Period.between(date1, date2);
            

            System.out.printf("Case #%d:\n", t);
            System.out.printf("Difference between %02d/%02d/%d and %02d/%02d/%d:\n",
                    d1, m1, y1, d2, m2, y2);
            System.out.printf("%d Year(s), %d Month(s), %d Day(s)\n\n",
                    Math.abs(p.getYears()), Math.abs(p.getMonths()), Math.abs(p.getDays()));
        }
    }
}
