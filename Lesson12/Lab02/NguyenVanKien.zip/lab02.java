/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package NguyenVanKien_Lession12_Lab02;

/**
 *
 * @author Admin
 */
import java.text.*;
import java.util.*;
import java.time.*;
import java.time.temporal.ChronoUnit;

public class lab02 {

    public static void main(String[] args) {
        System.out.println("Nhap so testcase cua bai 1:");
        Scanner sc = new Scanner(System.in);
        int t1 = sc.nextInt();
        for (int i = 1; i <= t1; i++) {
            System.out.println("Case#" + i + ":");
            int d1 = sc.nextInt();
            int m1 = sc.nextInt();
            int y1 = sc.nextInt();
            int d2 = sc.nextInt();
            int m2 = sc.nextInt();
            int y2 = sc.nextInt();

            LocalDate date1 = LocalDate.of(y1, m1, d1);
            LocalDate date2 = LocalDate.of(y2, m2, d2);

            Period diff = Period.between(date1, date2);
            if (diff.isNegative()) {
                diff = Period.between(date2, date1);
            }

            System.out.printf("Difference between %02d/%02d/%02d and %02d/%02d/%02d:%n", d1, m1, y1, d2, m2, y2);
            System.out.printf("%d Year(s), %d Month(s), %d Day(s)%n", diff.getYears(), diff.getMonths(), diff.getDays());
        }
        System.out.println("Nhap so testcase cua bai 2:");
        int t2 = sc.nextInt();
        for (int i = 1; i <= t2; i++) {
            int d1 = sc.nextInt();
            int m1 = sc.nextInt();
            int y1 = sc.nextInt();

            int h1 = sc.nextInt();
            int min1 = sc.nextInt();
            int s1 = sc.nextInt();

            int d2 = sc.nextInt();
            int m2 = sc.nextInt();
            int y2 = sc.nextInt();

            int h2 = sc.nextInt();
            int min2 = sc.nextInt();
            int s2 = sc.nextInt();

            LocalDateTime dt1 = LocalDateTime.of(y1, m1, d1, h1, min1, s1);
            LocalDateTime dt2 = LocalDateTime.of(y2, m2, d2, h2, min2, s2);

            if (dt2.isBefore(dt1)) {
                LocalDateTime tmp = dt1;
                dt1 = dt2;
                dt2 = tmp;
            }

            long totalSeconds = ChronoUnit.SECONDS.between(dt1, dt2); // Tính tổng số giây giữa hai thời điểm

            long days = totalSeconds / (24 * 3600);
            long hours = (totalSeconds % (24 * 3600)) / 3600;
            long minutes = (totalSeconds % 3600) / 60;
            long seconds = totalSeconds % 60;

            System.out.println("Case #" + i + ":");
            System.out.printf("Difference between (%02d/%02d/%04d %02d:%02d:%02d) and (%02d/%02d/%04d %02d:%02d:%02d):%n",
                    d1, m1, y1, h1, min1, s1, d2, m2, y2, h2, min2, s2);
            System.out.printf("%d Days, %d Hours, %d Minutes, %d Seconds\n",
                    days, hours, minutes, seconds);
        }
    }
}
