/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.act.vn.lesson131;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author manh
 */
public class Lab01_Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int N = sc.nextInt();
        List<Integer> list = new ArrayList<>();
        for (int i = 0; i < N; i++) {
            int type = sc.nextInt();
            switch (type) {
                case (1): {
                    String lenh = sc.next();

                    if (lenh.equals("F")) {
                        int X = sc.nextInt();
                        list.add(0, X);
                    } else if (lenh.equals("L")) {
                        int X = sc.nextInt();
                        list.add(X);
                    } else if (lenh.equals("P")) {

                        int Y = sc.nextInt();
                        int X = sc.nextInt();
                        if (Y >= 0 && Y < list.size()) {
                            list.add(Y, X);
                        } else {
                            list.add(X);
                        }
                    }
                    break;
                }
                case 2: {
                    int X = sc.nextInt();
                    int count = 0;
                    Iterator<Integer> it = list.iterator();
                    while (it.hasNext()) {
                        if (it.next() == X) {
                            it.remove();
                            count++;
                        }
                    }
                    System.out.println(count);
                    break;
                }

                case 3: {
                    int X = sc.nextInt();
                    int count = 0;
                    for (Integer list1 : list) {
                        if (list1.equals(X)) {
                            count++;
                        }
                    }
                    System.out.println(count);
                    break;
                }
                case 4: {
                    int X = sc.nextInt();
                    int Y = sc.nextInt();
                    for (int idk = X; idk <= Y && idk < list.size(); idk++) {
                        System.out.print(list.get(idk) + " ");
                    }
                    System.out.println();
                    break;
                }
                case 5: {
                    for (int num : list) {
                        System.out.print(num + " ");
                    }
                    System.out.println();
                    break;
                }
            }
        }
        sc.close();
    }
}
