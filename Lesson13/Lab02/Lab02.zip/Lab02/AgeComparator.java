/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lab02;

import java.time.LocalDate;
import java.time.Period;

/**
 *
 * @author manh
 */
public class AgeComparator implements comparator {

    @Override
    public int compare(Student o1, Student o2) {
        int age1 = Period.between(o1.getBirthday(), LocalDate.now()).getYears();
        int age2 = Period.between(o2.getBirthday(), LocalDate.now()).getYears();
        return Integer.compare(age1, age2);
    }

}
