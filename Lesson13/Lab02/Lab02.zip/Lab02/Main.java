/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lab02;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import Lab02.comparator;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author manh
 */
public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int N = sc.nextInt();
        List<Student> list = new ArrayList<>();
        DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        for (int i = 0; i < N; i++) {
            int type = sc.nextInt();
            switch (type) {
                case 1: {
                    int id = sc.nextInt();
                    String fn = sc.next();
                    String ln = sc.next();
                    LocalDate lcd = LocalDate.parse(sc.next(), df);
                    double gpa = sc.nextDouble();
                    list.add(new Student(id, fn, ln, lcd, gpa));
                    break;
                }
                case 2: {// field đầu tiên là dạng int nên là sửa lại đi nhé

                    int field = sc.nextInt();
                    String str = sc.next();

                    Iterator<Student> it = list.iterator();
                    while (it.hasNext()) {
                        Student s = it.next();
                        if ((field == 1 && s.getFirstName().equals(str))
                                || (field == 2 && s.getLastName().equals(str))) {
                            it.remove();

                        }
                    }

                    break;
                }
                case 3: {
                    int id = sc.nextInt();
                    int field = sc.nextInt();
                    for (Student s : list) {
                        if (s.getId() == id) {
                            switch (field) {
                                case 1: {
                                    String fn = sc.next();
                                    s.setFirstName(fn);
                                    break;
                                }
                                case 2: {
                                    String ln = sc.next();
                                    s.setLastName(ln);
                                    break;
                                }
                                case 3: {
                                    df = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                                    LocalDate lcd = LocalDate.parse(sc.next(), df);
                                    s.setBirthday(lcd);
                                    break;
                                }
                                case 4: {
                                    double gpa = sc.nextDouble();
                                    s.setGpa(gpa);
                                    break;
                                }

                            }
                            break;
                        }
                    }

                    break;
                }
                case 4: {
                    int X = sc.nextInt();
                    Comparator<Student> comparator = null;
                    switch (X) {
                        case 1:
                            comparator = new LastNameComparator()
                                    .thenComparing(new FirstNameComparator())
                                    .thenComparing(new AgeComparator())
                                    .thenComparing(new GPAComparator());
                            break;
                        case 2:
                            comparator = new AgeComparator()
                                    .thenComparing(new LastNameComparator())
                                    .thenComparing(new FirstNameComparator())
                                    .thenComparing(new GPAComparator());
                            break;
                        case 3:
                            comparator = Comparator.comparing(Student::getGpa).reversed()
                                    .thenComparing(Student::getLastName)
                                    .thenComparing(Student::getFirstName)
                                    .thenComparing(new AgeComparator());
                            break;
                        default:
                            break;
                    }
                    if (comparator != null) {
                        Collections.sort(list, comparator);
                    }
                    break;
                }
                case 5: {

                    int countss = Math.min(10, list.size());
                    for (int idk = 0; idk < countss; idk++) {
                        System.out.println(list.get(idk).toString());
                    }
                    break;
                }
                case 6: {
                    for (Student s : list) {
                        System.out.println(s);
                    }
                    break;
                }

            }
        }
    }

}
