/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lab02;

import java.time.LocalDate;

/**
 *
 * @author manh
 */
public class Student {

    public int id;
    public String FirstName;
    public String LastName;
    public LocalDate birthday;
    public double gpa;

    public Student(int id, String FirstName, String LastName, LocalDate birthday, double gpa) {
        this.id = id;
        this.FirstName = FirstName;
        this.LastName = LastName;
        this.birthday = birthday;
        this.gpa = gpa;
    }

    @Override
    public String toString() {
        return "Student{id =" + id + ",firstName=" + FirstName + ",lastName=" + LastName + ",birthday=" + birthday + ",GPA=" + gpa+"}";
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String FirstName) {
        this.FirstName = FirstName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String LastName) {
        this.LastName = LastName;
    }

    public LocalDate getBirthday() {
        return birthday;
    }

    public void setBirthday(LocalDate birthday) {
        this.birthday = birthday;
    }

    public double getGpa() {
        return gpa;
    }

    public void setGpa(double gpa) {
        this.gpa = gpa;
    }
    
}
