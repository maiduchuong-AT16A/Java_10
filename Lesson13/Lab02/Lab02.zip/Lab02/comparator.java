/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lab02;

import java.util.Comparator;

/**
 *
 * @author manh
 */
public interface comparator extends Comparator<Student>{
     @Override
     int compare(Student o1, Student o2);
}
