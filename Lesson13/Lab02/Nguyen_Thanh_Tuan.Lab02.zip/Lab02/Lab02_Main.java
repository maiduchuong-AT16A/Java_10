package com.act.vn.Lesson13.Nguyen_Thanh_Tuan.Lab02;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Lab02_Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int N = sc.nextInt();
        sc.nextLine();

        List<Student> studentList = new ArrayList<>();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        for (int i = 1; i <= N; i++) {
            String line = sc.nextLine();
            String[] parst = line.split(" ");
            String command = parst[0];
            switch (command) {
                case "1":
                    int id = Integer.parseInt(parst[1]);
                    String firstName = parst[2];
                    String lastName = parst[3];
                    LocalDate birthday = LocalDate.parse(parst[4], formatter);
                    double gpa = Double.parseDouble(parst[5]);
                    studentList.add(new Student(id, firstName, lastName, birthday, gpa));
                    break;
                case "2":
                    int field = Integer.parseInt(parst[1]);
                    String str = parst[2];
                    if (field == 1) {
                        studentList.removeIf(student -> student.getFirstName().equals(str));
                    } else if (field == 2) {
                        studentList.removeIf(student -> student.getLastName().equals(str));
                    }
                    break;
                case "3":
                    int editId = Integer.parseInt(parst[1]);
                    int editField = Integer.parseInt(parst[2]);
                    String editStr = parst[3];
                    for (Student student : studentList) {
                        if (student.getId() == editId) {
                            if (editField == 1) {
                                student.setFirstName(editStr);
                            } else if (editField == 2) {
                                student.setLastName(editStr);
                            } else if (editField == 3) {
                                student.setBirthday(LocalDate.parse(editStr, DateTimeFormatter.ofPattern("yyyy-MM-dd")));
                            } else if (editField == 4) {
                                student.setGpa(Double.parseDouble(editStr));
                            }
                        }
                    }
                    break;
                case "4":
                    int sortType = Integer.parseInt(parst[1]);
                    if (sortType == 1) {
                        Collections.sort(studentList, new LastNameComparator().thenComparing(new FirstNameComparator()).thenComparing(new AgeComparator()).thenComparing(new GPAComparator()));
                    } else if (sortType == 2) {
                        Collections.sort(studentList, new AgeComparator().thenComparing(new LastNameComparator()).thenComparing(new FirstNameComparator()).thenComparing(new GPAComparator()));
                    } else if (sortType == 3) {
                        Collections.sort(studentList, new GPAComparator().thenComparing(new LastNameComparator()).thenComparing(new FirstNameComparator()).thenComparing(new GPAComparator()));
                    }
                    break;
                case "5":
                    int limit = Math.min(studentList.size(), 10);
                    for (int j = 0; j < limit; j++) {
                        System.out.println(studentList.get(j).toString());
                    }
                    System.out.println("-----------------------------------");
                    break;
                case "6":
                    for (Student student : studentList) {
                        System.out.println(student.toString());
                    }
                    System.out.println("-----------------------------");
                    break;
            }
        }
        sc.close();
    }
}
