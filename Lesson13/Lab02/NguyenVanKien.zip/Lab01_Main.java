/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package NguyenVanKien_Lession13_Lab01;

/**
 *
 * @author Admin
 */
import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;

public class Lab01_Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int N = sc.nextInt();
        sc.nextLine();

        List<Integer> list = new ArrayList<>();
        for (int i = 0; i < N; i++) {
            String line = sc.nextLine();
            String[] parts = line.split(" ");
            int command = Integer.parseInt(parts[0]);

            switch (command) {
                case 1: {
                    String type = parts[1];
                    if (type.equals("F")) {
                        int X = Integer.parseInt(parts[2]);
                        list.add(0, X);
                    } else if (type.equals("L")) {
                        int X = Integer.parseInt(parts[2]);
                        list.add(X);
                    } else {
                        int Y = Integer.parseInt(parts[2]);
                        int X = Integer.parseInt(parts[3]);
                        if (Y >= 0 && Y < list.size()) {
                            list.add(Y, X);
                        } else {
                            list.add(X);
                        }
                    }
                    break;
                }
                case 2: {
                    int X = Integer.parseInt(parts[1]);
                    int count = 0;

                    while (list.contains(X)) {
                        list.remove(Integer.valueOf(X));
                        count++;
                    }

                    System.out.println(count);
                    break;
                }
                case 3: {
                    int X = Integer.parseInt(parts[1]);
                    int count = 0;
                    for (int val : list) {
                        if (val == X) {
                            count++;
                        }
                    }
                    System.out.println(count);
                    break;
                }
                case 4: {
                    int X = Integer.parseInt(parts[1]);
                    int Y = Integer.parseInt(parts[2]);

                    if (X < 0) {
                        X = 0;
                    }
                    if (Y >= list.size()) {
                        Y = list.size() - 1;
                    }

                    for (int idx = X; idx <= Y; idx++) {
                        System.out.print(list.get(idx));
                        if (idx < Y) {
                            System.out.print(" ");
                        }
                    }
                    System.out.println();
                    break;
                }
                case 5: {
                    for (int j = 0; j < list.size(); j++) {
                        System.out.print(list.get(j));
                        if(j < list.size() - 1);
                        System.out.print(" ");
                    }
                    System.out.println();
                    break;
                }
            }
        }
    }
}
