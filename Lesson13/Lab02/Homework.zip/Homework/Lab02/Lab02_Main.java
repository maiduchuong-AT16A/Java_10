package Homework.Lab02;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.Scanner;

import javax.swing.text.GapContent;
import javax.swing.text.AttributeSet.ColorAttribute;

public class Lab02_Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Student> listStudents = new ArrayList<>();
        int N = sc.nextInt();
        Comparator<Student> cmp1 = new LastNameComparator().thenComparing(new FirstNameComparator())
                .thenComparing(new AgeComparator()).thenComparing(new GPAComparator());
        Comparator<Student> cmp2 = new AgeComparator().thenComparing(new LastNameComparator())
                .thenComparing(new FirstNameComparator()).thenComparing(new GPAComparator());
        Comparator<Student> cmp3 = new GPAComparator().thenComparing(new LastNameComparator())
                .thenComparing(new FirstNameComparator()).thenComparing(new AgeComparator());
        for (int j = 0; j <= N; j++) {
            int choose = sc.nextInt();

            switch (choose) {
                case 1: {
                    int id = sc.nextInt();
                    String FirstName = sc.next();
                    String LastName = sc.next();
                    String birthDate = sc.next();
                    LocalDate birthDay = LocalDate.parse(birthDate);
                    double gpa = sc.nextDouble();
                    Student a = new Student(id, FirstName, LastName, birthDay, gpa);
                    listStudents.add(a);
                    break;
                }
                case 2: {
                    int nextchoose = sc.nextInt();
                    String deleteName = sc.next();
                    for (int i = 0; i < listStudents.size(); i++) {

                        if (nextchoose == 1) {
                            if (deleteName.compareTo(listStudents.get(i).getFirstName()) == 0) {
                                listStudents.remove(i);
                                i--;
                            }
                        } else {
                            if (deleteName.compareTo(listStudents.get(i).getLastName()) == 0) {
                                listStudents.remove(i);
                                i--;
                            }
                        }

                    }
                    break;
                }
                case 3: {
                    int IDchange = sc.nextInt();
                    for (Student s : listStudents) {
                        if (s.getId() == IDchange) {
                            int nextchoose = sc.nextInt();
                            switch (nextchoose) {
                                case 1: {
                                    String changeFirstname = sc.next();
                                    s.setFirstName(changeFirstname);
                                    break;
                                }
                                case 2: {
                                    String changLastname = sc.next();
                                    s.setLastName(changLastname);
                                    break;
                                }
                                case 3: {
                                    String changeBirthdate = sc.next();
                                    LocalDate changeBirhtday = LocalDate.parse(changeBirthdate);
                                    s.setBirthday(changeBirhtday);
                                    break;
                                }
                                case 4: {
                                    double changeGPA = sc.nextDouble();
                                    s.setGpa(changeGPA);
                                    break;
                                }

                            }
                        }
                    }
                    break;

                }
                case 4: {
                    int nextchoose = sc.nextInt();
                    if (nextchoose == 1) {
                        Collections.sort(listStudents, cmp1);
                    } else if (nextchoose == 2) {
                        Collections.sort(listStudents, cmp2);
                    } else if (nextchoose == 3) {
                        Collections.sort(listStudents, cmp3);
                    }
                    break;
                }
                case 5: {
                    if (listStudents.size() > 9) {
                        for (int i = 0; i < 10; i++) {
                            System.out.println(listStudents.get(i).toString());

                        }
                        System.out.println("");

                    } else {
                        for (Student i : listStudents) {
                            System.out.println(i.toString());

                        }
                        System.out.println("");

                    }
                    break;
                }
                case 6: {
                    for (Student i : listStudents) {
                        System.out.println(i.toString());

                    }
                    System.out.println("");

                    break;
                }

            }
        }
    }
}
