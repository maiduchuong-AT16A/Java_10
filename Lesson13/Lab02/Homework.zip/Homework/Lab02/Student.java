package Homework.Lab02;

import java.text.DateFormat;
import java.time.LocalDate;

public class Student {
    private int id;
    private String firstName;
    private String lastName;
    private LocalDate birthday;
    private double gpa;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public LocalDate getBirthday() {
        return birthday;
    }

    public void setBirthday(LocalDate birthday) {
        this.birthday = birthday;
    }

    public double getGpa() {
        return gpa;
    }

    public void setGpa(double gpa) {
        this.gpa = gpa;
    }

    public Student(int id, String firstName, String lastName, LocalDate birthday, double gpa) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.birthday = birthday;
        this.gpa = gpa;
    }

    @Override
    public String toString() {
        String birthdayString = this.getBirthday().toString();
        return String.format("Student{id=%d, firstName=%s, lastName=%s, birthday=%s, GPA=%.2f} ", this.getId(),
                this.getFirstName(), this.getLastName(), birthdayString, this.getGpa());
    }

}
