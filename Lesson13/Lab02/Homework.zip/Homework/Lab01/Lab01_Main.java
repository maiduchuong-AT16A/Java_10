package Homework.Lab01;

import java.util.ArrayList;
import java.util.Scanner;

public class Lab01_Main {
    private static void addFirst(ArrayList<Integer> a, int X) {
        a.add(0, X);
    }

    private static void addLast(ArrayList<Integer> a, int X) {
        a.add(a.size(), X);
    }

    private static void addTolist(ArrayList<Integer> a, int X, int Y) {
        if (Y < a.size() && Y >= 0) {
            a.add(Y, X);
        } else {
            addLast(a, X);
        }
    }

    private static void Remove(ArrayList<Integer> a, int X) {
        int count = 0;
        for (int i = 0; i < a.size();) {
            if (a.get(i) == X) {
                a.remove(i);
                count++;
            }
            else{
                i++;
            }
        }
        System.out.println(count);
    }

    private static void Frequency(ArrayList<Integer> a, int X) {
        int count = 0;
        for (int i  = 0; i < a.size();i++) {
            if (a.get(i) == X) {
                count++;
            }
        }
        System.out.println(count);
    }

    private static void showFromXtoY(ArrayList<Integer> a, int X, int Y) {
        for (int i = X; i <= Y; i++) {
            System.out.printf("%d ", a.get(i));
        }
        System.out.println("");
    }

    private static void showAll(ArrayList<Integer> a) {
        for (int item : a) {
            System.out.printf("%d ",item);
        }
        System.out.println("");
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int N = sc.nextInt();
        ArrayList<Integer> List = new ArrayList<>();
        for (int i = 0; i < N; i++) {
            int choose = sc.nextInt();
            
            switch (choose) {
                case 1: {
                    String letter = sc.next();
                    if (letter.charAt(0) == 'F') {
                        int X = sc.nextInt();
                        addFirst(List, X);
                    } else if (letter.charAt(0) == 'L') {
                        int X = sc.nextInt();
                        addLast(List, X);
                    } else if (letter.charAt(0) == 'P') {
                        int Y = sc.nextInt();
                        int X = sc.nextInt();

                        addTolist(List, X, Y);
                    }
                    break;
                }
                case 2:
                {
                    int X = sc.nextInt();
                    Remove(List, X);
                    break;
                }
                case 3:
                {
                    int X = sc.nextInt();
                    Frequency(List, X);
                    break;
                }
                case 4:
                {
                    int X = sc.nextInt();
                    int Y = sc.nextInt();
                    showFromXtoY(List, X, Y);
                    break;
                }
                case 5:
                {
                    showAll(List);
                    break;
                }
            }
        }
    }
}
