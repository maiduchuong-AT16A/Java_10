/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.actvn.lession13.lab02.TruongTuanHai;

import java.util.Comparator;

/**
 *
 * @author Admin
 */
public class FirstNameComparator implements Comparator<Student>{

    @Override
    public int compare(Student o1, Student o2) {
       return o1.getFirstName().compareTo(o2.getFirstName());
    }
}
