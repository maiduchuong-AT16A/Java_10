/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.actvn.lession13.lab02.TruongTuanHai;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class Lab02_Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        List<Student> students = new ArrayList<>();

        int n = sc.nextInt();
        sc.nextLine();

        for (int i = 0; i < n; i++) {
            String[] parts = sc.nextLine().trim().split(" ");
            int cmd = Integer.parseInt(parts[0]);

            switch (cmd) {
                case 1: {
                    int id = Integer.parseInt(parts[1]);
                    String firstName = parts[2];
                    String lastName = parts[3];
                    String birthday = parts[4];
                    double gpa = Double.parseDouble(parts[5]);
                    students.add(new Student(id, firstName, lastName, birthday, gpa));
                    break;
                }

                case 2: {
                    int field = Integer.parseInt(parts[1]);
                    String value = parts[2];
                    if (field == 1) {
                        students.removeIf(student -> student.getFirstName().equals(value));
                    } else if (field == 2) {
                        students.removeIf(student -> student.getLastName().equals(value));
                    }
                    break;
                }

                case 3: {
                    int id = Integer.parseInt(parts[1]);
                    int field = Integer.parseInt(parts[2]);
                    String value = parts[3];

                    for (Student s : students) {
                        if (s.getId() == id) {
                            switch (field) {
                                case 1:
                                    s.setFirstName(value);
                                    break;
                                case 2:
                                    s.setLastName(value);
                                    break;
                                case 3:
                                    s.setBirthday(value);
                                    break;
                                case 4:
                                    s.setGpa(Double.parseDouble(value));
                                    break;
                            }
                            break;
                        }
                    }
                    break;
                }

                case 4: {
                    int type = Integer.parseInt(parts[1]);
                    Comparator<Student> comparator = null;

                    switch (type) {
                        case 1:
                            comparator = Comparator
                                    .comparing(Student::getLastName)
                                    .thenComparing(Student::getFirstName)
                                    .thenComparing(Student::getAge)
                                    .thenComparing(Student::getGpa);
                            break;

                        case 2:
                            comparator = Comparator
                                    .comparing(Student::getAge)
                                    .thenComparing(Student::getLastName)
                                    .thenComparing(Student::getFirstName)
                                    .thenComparing(Student::getGpa);
                            break;

                        case 3:
                            comparator = Comparator
                                    .comparing(Student::getGpa).reversed()
                                    .thenComparing(Student::getLastName)
                                    .thenComparing(Student::getFirstName)
                                    .thenComparing(Student::getAge);
                            break;
                    }

                    if (comparator != null) {
                        students.sort(comparator);
                    }
                    break;
                }

                case 5: {
                    int count = Math.min(10, students.size());
                    for (int j = 0; j < count; j++) {
                        System.out.println(students.get(j));
                    }
                    break;
                }

                case 6: {
                    for (Student s : students) {
                        System.out.println(s);
                    }
                    break;
                }
            }
        }

        sc.close();
    }
}
