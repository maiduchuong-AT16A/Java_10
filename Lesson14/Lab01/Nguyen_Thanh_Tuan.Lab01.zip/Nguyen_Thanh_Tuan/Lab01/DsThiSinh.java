package com.act.vn.Lesson14.Nguyen_Thanh_Tuan.Lab01;

import java.io.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DsThiSinh {

    private List<ThiSinh> list;

    public DsThiSinh() {
        this.list = new ArrayList<>();
    }

    public void docFile(String filePath) {
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader(filePath));
            String line = null;
            String[] value = null;
            ThiSinh thiSinh = null;
            br.readLine();
            while ((line = br.readLine()) != null) {
                value = line.split(",");
                thiSinh = new ThiSinh(Integer.parseInt(value[0]), value[1], value[2], value[3], Double.parseDouble(value[4]));
                list.add(thiSinh);
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(DsThiSinh.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(DsThiSinh.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException ex) {
                    Logger.getLogger(DsThiSinh.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }

    public void locTheoGioiTinh(String gioiTinh) {
        list.stream()
                .filter(ts -> ts.getGioiTinh().equalsIgnoreCase(gioiTinh))
                .sorted(Comparator.comparing(ThiSinh::getHoTen))
                .forEach(System.out::println);
    }

    public void locTheoTinh(String tinh) {
        list.stream()
                .filter(ts -> ts.getTinh().equalsIgnoreCase(tinh))
                .sorted(Comparator.comparing(ThiSinh::getHoTen))
                .forEach(System.out::println);
    }

    public void suaThongTin(int sbd, int type, String newValue) {
        for (ThiSinh ts : list) {
            if (ts.getSbd() == sbd) {
                if (type == 1) {
                    ts.setTinh(newValue);
                } else if (type == 2) {
                    ts.setTongDiem(Double.parseDouble(newValue));
                }
            }
            return;
        }
    }

    public void xoaThiSinh(int sbd) {
        boolean removed = list.removeIf(ts -> ts.getSbd() == sbd);
        System.out.println(removed ? 1 : 0);
    }

    public void layTopY(int y) {
        list.stream()
                .sorted(Comparator.comparingDouble(ThiSinh::getTongDiem).reversed())
                .limit(y)
                .sorted(Comparator.comparing(ThiSinh::getHoTen))
                .forEach(System.out::println);
    }

    public void sapXepVaGhiFile(String filePath) {
        list.sort(ThiSinh.getComparator());
        BufferedWriter bw = null;
        try {
            bw = new BufferedWriter(new FileWriter(filePath));
            bw.write("SBD,HoTen,GioiTinh,Tinh,TongDiem");
            bw.newLine();
            for (ThiSinh ts : list) {
                String line = ts.getSbd() + "," + ts.getHoTen() + "," + ts.getGioiTinh() + ","
                        + ts.getTinh() + "," + ts.getTongDiem();
                bw.write(line);
                bw.newLine();
            }
        } catch (IOException ex) {
            Logger.getLogger(DsThiSinh.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                bw.close();
            } catch (IOException ex) {
                Logger.getLogger(DsThiSinh.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
