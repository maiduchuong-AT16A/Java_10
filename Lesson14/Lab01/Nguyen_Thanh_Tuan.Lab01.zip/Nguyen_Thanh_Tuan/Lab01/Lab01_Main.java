package com.act.vn.Lesson14.Nguyen_Thanh_Tuan.Lab01;

import java.io.File;
import java.util.Scanner;

public class Lab01_Main {

    static private String curDir = System.getProperty("user.dir");
    static private String separator = File.separator;
    static private String folder_CSV = curDir + separator + "data";
    static private String CSV_INPUT = folder_CSV + separator + "diemthi_input.csv";
    static private String CSV_OUTPUT = folder_CSV + separator + "diemthi_output.csv";

    public static void main(String[] args) {
        DsThiSinh qlts = new DsThiSinh();
        qlts.docFile(CSV_INPUT);

        Scanner sc = new Scanner(System.in);

        int N = Integer.parseInt(sc.nextLine());
        for (int n = 0; n < N; n++) {
            String line = sc.nextLine();
            String[] parts = line.split(" ");
            int command = Integer.parseInt(parts[0]);

            switch (command) {
                case 1:
                    qlts.locTheoGioiTinh(parts[1]);
                    break;
                case 2:
                    qlts.locTheoTinh(parts[1]);
                    break;
                case 3:
                    int sbdSua = Integer.parseInt(parts[1]);
                    int type = Integer.parseInt(parts[2]);
                    String newValue = parts[3];
                    qlts.suaThongTin(sbdSua, type, newValue);
                    break;
                case 4:
                    int sbdXoa = Integer.parseInt(parts[1]);
                    qlts.xoaThiSinh(sbdXoa);
                    break;
                case 5:
                    int y = Integer.parseInt(parts[1]);
                    qlts.layTopY(y);
                    break;
                case 6:
                    qlts.sapXepVaGhiFile(CSV_OUTPUT);
                    break;
                default:
                    System.out.println("Loi!");
                    break;
            }
        }
    }
}
