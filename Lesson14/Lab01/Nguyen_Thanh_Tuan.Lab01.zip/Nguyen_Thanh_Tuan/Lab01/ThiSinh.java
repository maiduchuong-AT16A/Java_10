package com.act.vn.Lesson14.Nguyen_Thanh_Tuan.Lab01;

import java.util.Comparator;
import java.util.Objects;

public class ThiSinh {

    private int sbd;
    private String hoTen;
    private String gioiTinh;
    private String tinh;
    private double tongDiem;

    public ThiSinh(int sbd, String hoTen, String gioiTinh, String tinh, double tongDiem) {
        this.sbd = sbd;
        this.hoTen = hoTen;
        this.gioiTinh = gioiTinh;
        this.tinh = tinh;
        this.tongDiem = tongDiem;
    }

    public int getSbd() {
        return sbd;
    }

    public void setSbd(int sbd) {
        this.sbd = sbd;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public String getGioiTinh() {
        return gioiTinh;
    }

    public void setGioiTinh(String gioiTinh) {
        this.gioiTinh = gioiTinh;
    }

    public String getTinh() {
        return tinh;
    }

    public void setTinh(String tinh) {
        this.tinh = tinh;
    }

    public double getTongDiem() {
        return tongDiem;
    }

    public void setTongDiem(double tongDiem) {
        this.tongDiem = tongDiem;
    }

    @Override
    public String toString() {
        return "ThiSinh{" + "sbd=" + sbd + ", hoTen=" + hoTen + ", gioiTinh=" + gioiTinh + ", tinh=" + tinh + ", tongDiem=" + tongDiem + '}';
    }

    @Override
    public int hashCode() {
        return Objects.hash(sbd);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        ThiSinh thiSinh = (ThiSinh) obj;
        return sbd == thiSinh.sbd;
    }

    public static Comparator<ThiSinh> getComparator() {
        return Comparator.comparing(ThiSinh::getTongDiem).reversed()
                .thenComparing(ThiSinh::getHoTen)
                .thenComparing(ThiSinh::getTinh);
    }

}
