package com.mycompany.lab01_main;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.opencsv.CSVWriter;
import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;

/**
 *
 * @author Admin
 */
public class Lab01_Main {

    private static String FIle_Path = System.getProperty("user.dir");
    private static String curSep = File.separator;
    private static String CSV_input = FIle_Path + curSep + "Lab01" + curSep+ "diemthi_input.csv";
    private static List<DiemThi> List = new ArrayList<>();
    private static String CSV_output = FIle_Path + curSep + "Lab01" + curSep + "diemthi_output.csv";

    public static void readCSV() {
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader(CSV_input));
            String line = null;
            String[] property = null;
            DiemThi diemthi = null;
            try {
                br.readLine();
            } catch (IOException ex) {
                Logger.getLogger(Lab01_Main.class.getName()).log(Level.SEVERE, null, ex);
            }
            try {
                while ((line = br.readLine()) != null) {
                    property = line.split(",");
                    diemthi = new DiemThi(Integer.valueOf(property[0]), property[1],
                            property[2], property[3], Double.valueOf(property[4]));
                    List.add(diemthi);
                }
            } catch (IOException ex) {
                Logger.getLogger(Lab01_Main.class.getName()).log(Level.SEVERE, null, ex);
            }

        } catch (FileNotFoundException ex) {
            Logger.getLogger(Lab01_Main.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException ex) {
                    Logger.getLogger(Lab01_Main.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }

    }

    public static <E> void writeCSV(List<E> list) {
        FileWriter fw = null;
        try {
            fw = new FileWriter(CSV_output);
            for (E item : list) {
                if (item instanceof DiemThi) {
                    DiemThi diemthi = (DiemThi) item;
                    fw.append(String.valueOf(diemthi.getSBD())).append(",")
                            .append(diemthi.getHoTen()).append(",")
                            .append(diemthi.getGioiTinh()).append(",")
                            .append(diemthi.getTinh()).append(",")
                            .append(String.valueOf(diemthi.getTongDiem())).append("\n");
                }
            }
        } catch (IOException ex) {
            Logger.getLogger(Lab01_Main.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (fw != null) {
                try {
                    fw.close();
                } catch (IOException ex) {
                    Logger.getLogger(Lab01_Main.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }

    }

    static void readCSV_OpenCsv() {
        Reader reader = null;
        try {
            reader = new FileReader(CSV_input);
            CsvToBean<DiemThi> diemthi = new CsvToBeanBuilder<DiemThi>(reader)
                    .withType(DiemThi.class)
                    .withIgnoreLeadingWhiteSpace(true)
                    .withSkipLines(1)
                    .build();
            List = diemthi.parse();
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }

    }
    static void writeCSV_OpenCsv() {
        Writer wr = null;
        try {
            wr = new FileWriter(CSV_output);
            CSVWriter diemthi = new CSVWriter(wr,CSVWriter.DEFAULT_SEPARATOR,
                    CSVWriter.NO_QUOTE_CHARACTER,
                    CSVWriter.NO_ESCAPE_CHARACTER,
                    CSVWriter.RFC4180_LINE_END);
                    for(DiemThi item: List){
                        diemthi.writeNext(new String[]{
                                String.valueOf(item.getSBD()),
                                item.getHoTen(),
                                item.getGioiTinh(),
                                item.getTinh(),
                                String.valueOf(item.getTongDiem())
                        });
                    }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }finally{
            if(wr!=null){
                try {
                    wr.close();
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int N = sc.nextInt();
       readCSV();

        for (int i = 1; i <= N; i++) {
            int choose = sc.nextInt();
            switch (choose) {
                case 1: {
                    String Gioi_Tinh = sc.next();
                    for (DiemThi stu : List) {
                        if (stu.getGioiTinh().equals(Gioi_Tinh)) {
                            System.out.println(stu.toString());
                        }
                    }
                    break;
                }
                case 2: {
                    String Tinh = sc.next();
                    boolean flag = false;
                    for (DiemThi stu : List) {
                        if (stu.getTinh().equals(Tinh)) {
                            System.out.println(stu.toString());
                            flag = true;
                        }
                    }
                    if (!flag) {
                        System.out.println("Khong co hoc sinh nao co Tinh can tim");
                    }
                    break;
                }
                case 3: {
                    int SBD = sc.nextInt();
                    for (DiemThi stu : List) {
                        if (SBD == stu.getSBD()) {
                            int Y = sc.nextInt();
                            if (Y == 1) {
                                String Tinh = sc.next();
                                stu.setTinh(Tinh);
                            } else {
                                double X = sc.nextDouble();
                                stu.setTongDiem(X);
                            }
                        }

                    }
                    break;
                }
                case 4: {
                    int SBD = sc.nextInt();

                    boolean flag = false;
                    for (int j = 0; j < List.size(); j++) {
                        if (List.get(j).getSBD() == SBD) {
                            List.remove(j);
                            flag = true;
                            j--;
                        }
                    }
                    if (flag) {
                        System.out.println("1");
                    } else {
                        System.out.println("0");
                    }
                    break;
                }
                case 5: {
                    int Y = sc.nextInt();
                    Collections.sort(List, Compare.SoTongDiem);
                    for (int j = 0; j < Y; j++) {
                        System.out.println(List.get(j));
                    }
                    break;
                }
                case 6: {
                    Collections.sort(List, Compare.SoTatCa);
                   writeCSV(List);
                    break;
                }

            }

        }

    }

}
