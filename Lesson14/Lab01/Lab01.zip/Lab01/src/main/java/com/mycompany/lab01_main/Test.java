package com.mycompany.lab01_main;

public class Test {
  public static void main(String[] args) {
    String filePath = System.getProperty("user.dir");
    System.out.println(filePath);
  }  
}
