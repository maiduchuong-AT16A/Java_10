/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lab01_main;

import java.util.Comparator;

/**
 *
 * @author Admin
 */
public class Compare {

    public static Comparator<DiemThi> SoTongDiem = new Comparator<DiemThi>() {
        @Override
        public int compare(DiemThi o1, DiemThi o2) {
            return Double.compare(o2.getTongDiem(), o1.getTongDiem());
        }
    };
    public static Comparator<DiemThi> SoTatCa = Comparator.comparingDouble(DiemThi::getTongDiem)
            .thenComparing(DiemThi::getHoTen).thenComparing(DiemThi::getTinh);
}
