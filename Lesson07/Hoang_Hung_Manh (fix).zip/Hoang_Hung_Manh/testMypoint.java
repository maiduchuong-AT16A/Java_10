/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.act.vn.lesson7.Hoang_Hung_Manh;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author manh
 */
public class testMypoint {

    public static void main(String[] args) throws FileNotFoundException {
        Mypoint point1 = new Mypoint(15, 20);
        Mypoint point2 = new Mypoint();
        Mypoint point3 = new Mypoint();
        Scanner sc = new Scanner(System.in);
        int k = sc.nextInt();
        int j = sc.nextInt();
        point2.setX(k);
        point2.setY(j);
        point3.SetXY(5, 6);
        double a = point1.getDistance(10, 10);
        double b = point2.getDistance(10, 10);
        double c = point3.getDistance(10, 10);
        System.out.println("diem 1 la: " + point1.toString() + " Khoang cach toi diem 10 10  la: " + a);
        System.out.println("diem 2 la: " + point2.toString() + " Khoang cach toi diem 10 10  la: " + b);
        System.out.println("diem 3 la: " + point3.toString() + " Khoang cach toi diem 10 10  la: " + c);
    }
}
