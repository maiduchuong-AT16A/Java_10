/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.act.vn.lesson7.Hoang_Hung_Manh;

/**
 *
 * @author manh
 */
public class TestMyCircle {
   
    public static void main(String[] args) {
        myCricle c1 = new myCricle(2,3,5);
        Mypoint point = new Mypoint(6,6);
        myCricle c2 = new myCricle(8,point);
        double a = c1.getCircumference();
        double b = c1.getArea();
        double c = c2.getCircumference();
        double d = c2.getArea();
        String e = c1.toString();
        String f = c2.toString();
        System.out.println("chu vi c1 la: "+a);
        System.out.println("chu vi c2 la: "+b);
        System.out.println("dien tich c1 la: "+c);
        System.out.println("dien tich c2 la: "+d);
        System.out.println(e);
        System.out.println(f);
    }

}
