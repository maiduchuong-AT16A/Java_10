/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.actvn.Lesson07.Vu_Khai_Hoan;

/**
 *
 * @author ACER
 */
public class TestMyCircle {
    public static void main(String[] args) {
        MyCircle c1 = new MyCircle(2, 3, 5);
        MyPoint p = new MyPoint(6, 6);
        MyCircle c2 = new MyCircle(p, 8);
        
        System.out.printf("C1: Circumference = %.3f, Area = %.3f\n", c1.getCircumference(), c1.getArea());
        System.out.printf("C1: Circumference = %.3f, Area = %.3f\n", c2.getCircumference(), c2.getArea());
        
        System.out.println(c1);
        System.out.println(c2);
    }
}
