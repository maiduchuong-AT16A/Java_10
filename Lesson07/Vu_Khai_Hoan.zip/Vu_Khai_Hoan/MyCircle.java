/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.actvn.Lesson07.Vu_Khai_Hoan;

/**
 *
 * @author ACER
 */
public class MyCircle {
    private MyPoint o;
    private double r;
    final double PI = 3.14; 
    
    public MyCircle() {
        this.o = new MyPoint();
        this.r = 0;
    }
    
    public MyCircle(double x, double y, double r) {
        this.o = new MyPoint(x, y);
        this.r = r;
    }
    
    public MyCircle(MyPoint o, double r) {
        this.o = o;
        this.r = r;
    }

    public MyPoint getO() {
        return o;
    }

    public void setO(MyPoint o) {
        this.o = o;
    }

    public double getR() {
        return r;
    }

    public void setR(double r) {
        this.r = r;
    }
    
    public double getCircumference() {
        return 2 * PI * this.r;
    }
    
    public double getArea() {
        return PI * this.r * this.r;
    }

    @Override
    public String toString() {
        return String.format("Circle info: %s, radius = %.2f, circumference = %.3f, area = %.3f", this.o, this.r, getCircumference(), getArea());
    }
    
}

