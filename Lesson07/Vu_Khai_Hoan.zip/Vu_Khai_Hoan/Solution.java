/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.actvn.Lesson07.Vu_Khai_Hoan;

import java.util.Scanner;

/**
 *
 * @author ACER
 */
public class Solution {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int T = sc.nextInt();
        for(int i = 0; i < T; i++) {
            System.out.println("Case #" + (i+1) + ": ");
            int n = sc.nextInt();
            MyPoint point[] = new MyPoint[n];
            for(int j = 0; j < n; j++) {
                double x = sc.nextDouble();
                double y = sc.nextDouble();
                point[j] = new MyPoint(x, y);
            }
            
            int k = sc.nextInt();
            double x1 = sc.nextDouble();
            double x2 = sc.nextDouble();
            System.out.printf("distance = %.3f\n", point[k].getDistance(x1, x1));
            
            int p = sc.nextInt();
            System.out.println(point[p].toString());
            
            int m = sc.nextInt();
            
            MyPoint o[] = new MyPoint[m];
            for(int j = 0; j < m; j++) {
                double x = sc.nextDouble();
                double y = sc.nextDouble();
                o[j] = new MyPoint(x, y);
            }
            
            double r[] = new double[m];
            for(int j = 0; j < m; j++) {
                r[j] = sc.nextDouble();
            }
            
            MyCircle circle[] = new MyCircle[m];
            for(int j = 0; j < m; j++) {
                circle[j] = new MyCircle(o[j], r[j]);
            }
            
            int q = sc.nextInt();
            System.out.println(circle[q].toString());
            
            int I = sc.nextInt();
            int J = sc.nextInt();
            MyCircle cI = circle[I];
            MyCircle cJ = circle[J];
            double d = cI.getO().getDistance(cJ.getO().getX(), cJ.getO().getY());
            double tongBk = cI.getR() + cJ.getR();
            double hieuBk = Math.abs(cI.getR() - cJ.getR());
            if(d < hieuBk) {
                System.out.printf("Circle %d is inside Circle %d\n", I, J);
            } else if(d > tongBk) {
                System.out.printf("Circle %d does not intersect Circle %d\n", I, J);
            } else {
                System.out.printf("Circle %d intersects with Circle %d\n", I, J);
            }
        }
    }
}
