/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lession07;

/**
 *
 * @author Admin
 */
public class MyCircle {

    private double r;
    private MyPoint tam;

    public MyCircle() {
        this.tam = new MyPoint();
        this.r = 0;
    }

    public MyCircle(double x, double y, double r) {
        this.tam = new MyPoint(x, y);
        this.r = r;
    }

    public MyCircle(double r) {
        this.tam = tam;
        this.r = r;
    }

    public double getR() {
        return r;
    }

    public void setR(double r) {
        this.r = r;
    }

    public MyPoint getTam() {
        return tam;
    }

    public void setTam(MyPoint tam) {
        this.tam = tam;
    }

    public double getCircumference() {
        return 2 * r * Math.PI;
    }

    public double getArea() {
        return Math.PI * r * r;
    }

    @Override
    public String toString() {
        return String.format("Circle info: %s, radius = %.2f, circumference = %.3f, area = %.3f",
                tam.toString(), r, getCircumference(), getArea());
    }
}


