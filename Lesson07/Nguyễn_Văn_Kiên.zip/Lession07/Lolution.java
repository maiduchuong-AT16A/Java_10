/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lession07;

/**
 *
 * @author Admin
 */
import java.util.Scanner;

public class Lolution {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int T = sc.nextInt();
        for (int t = 1; t <= T; t++) {
            int n = sc.nextInt();
            MyPoint[] points = new MyPoint[n];
            for (int i = 0; i < n; i++) {
                double x = sc.nextDouble();
                double y = sc.nextDouble();
                points[i] = new MyPoint(x, y);
            }
            int k = sc.nextInt();
            double x1 = sc.nextDouble();
            double y1 = sc.nextDouble();
            double distance = points[k].getDistance(x1, y1);

            int p = sc.nextInt();
            int m = sc.nextInt();
            MyCircle[] circles = new MyCircle[m];
            for (int i = 0; i < m; i++) {
                double cx = sc.nextDouble();
                double cy = sc.nextDouble();
                circles[i] = new MyCircle(cx, cy, 0);
            }
            for (int i = 0; i < m; i++) {
                double r = sc.nextDouble();
                circles[i].setR(r);
            }
            int q = sc.nextInt();
            int i = sc.nextInt();
            int j = sc.nextInt();
            System.out.printf("Case #%d\n", t);
            System.out.printf("distance = %.3f\n", distance);
            System.out.println(points[p]);
            System.out.println(circles[q]);

            double d = circles[i].getTam().getDistance(
                    circles[j].getTam().getX(), circles[j].getTam().getY()
            );
            double sum = circles[i].getR() + circles[j].getR();
            double diff = Math.abs(circles[i].getR() - circles[j].getR());

            if (d > sum) {
                System.out.printf("Circle %d does not intersect Circle %d\n", i, j);
            } else if (d < diff) {
                System.out.printf("Circle %d is inside Circle %d\n", i, j);
            } else {
                System.out.printf("Circle %d intersects with Circle %d\n", i, j);
            }
        }
    }
}
