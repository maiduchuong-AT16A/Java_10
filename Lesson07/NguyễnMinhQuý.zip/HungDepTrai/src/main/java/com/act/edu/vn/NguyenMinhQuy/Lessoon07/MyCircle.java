/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.act.edu.vn.NguyenMinhQuy.Lessoon07;

import java.util.Scanner;

/**
 *
 * @author OS
 */
public class MyCircle {
    private MyPoint tam;
    private double banKinh;
    

    public MyCircle() {
        this.tam = new MyPoint();
        this.banKinh = 0;
    }

    public MyCircle(double x, double y, double banKinh) {
        this.tam = new MyPoint(x, y);
        this.banKinh = banKinh;
    } 

    public MyCircle(MyPoint tam, double banKinh) {
        this.tam = tam;
        this.banKinh = banKinh;
    }

    public MyPoint getTam() {
        return tam;
    }

    public double getBanKinh() {
        return banKinh;
    }

    public void setTam(MyPoint tam) {
        this.tam = tam;
    }

    public void setBanKinh(double banKinh) {
        this.banKinh = banKinh;
    }
    
    public double getCircumference(){
        return 2 * Math.PI * this.banKinh;
    }
    
    public double getArea(){
        return Math.PI * this.banKinh * this.banKinh;
    }

    @Override
    public String toString() {
    return String.format("Circle info: (%.2f, %.2f), radius = %.2f, circumference = %.3f, area = %.3f",
            tam.getX(), tam.getY(), banKinh, getCircumference(), getArea());
    }
    
    
}
