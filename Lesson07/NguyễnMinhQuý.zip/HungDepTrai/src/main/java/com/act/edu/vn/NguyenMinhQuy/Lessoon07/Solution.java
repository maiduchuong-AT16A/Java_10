/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.act.edu.vn.NguyenMinhQuy.Lessoon07;

/**
 *
 * @author OS
 */

import java.util.Scanner;

public class Solution {

    /**
     *
     * @param a
     * @param i
     * @param j
     */
    public static void check(MyCircle a[], int i, int j){
        if(a[i].getBanKinh() + a[j].getBanKinh() < a[i].getTam().getDistance(a[j].getTam().getX(), a[j].getTam().getY())) System.out.printf("Circle %d does not intersect Circle %d", i, j);         
        else if(a[i].getBanKinh() - a[j].getBanKinh() > a[i].getTam().getDistance(a[j].getTam().getX(), a[j].getTam().getY())) System.out.printf("Circle %d is inside Circle %d", j, i); 
        else if(0 - a[i].getBanKinh() + a[j].getBanKinh() > a[i].getTam().getDistance(a[j].getTam().getX(), a[j].getTam().getY())) System.out.printf("Circle %d is inside Circle %d", i, j); 
        else System.out.printf("Circle %d intersects with Circle %d", i, j); 
    }
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int t = input.nextInt();
        
        for(int i = 1; i <= t; i++){
            
            System.out.println("Case #" + i + ":");
            //diem
            int n = input.nextInt();
            MyPoint[] diem = new MyPoint[n];   
            for(int j = 0; j< n; j++){
                double a = input.nextDouble();
                double b = input.nextDouble();
                diem[j] = new MyPoint();
                diem[j].setXY(a, b); 
            }
            int k = input.nextInt();
            double x1 = input.nextDouble();
            double y1 = input.nextDouble();
            System.out.printf("distance = %.3f\n", diem[k].getDistance(x1, y1));
            int p = input.nextInt();
            System.out.println(diem[p].toString());
            
            //duong tron
            int m = input.nextInt();
            MyCircle[] duongTron = new MyCircle[m];
            double xtron[] = new double[m];
            double ytron[] = new double[m];
            double banKinhTron[] = new double[m];
            for(int z = 0; z < m; z++){
                xtron[z] = input.nextDouble();
                ytron[z] = input.nextDouble();
            }
            for(int z = 0; z < m; z++){
                banKinhTron[z] = input.nextDouble();
                duongTron[z] = new MyCircle(xtron[z], ytron[z], banKinhTron[z]);
            }
            int q = input.nextInt();
            System.out.println(duongTron[q].toString());  
            int u = input.nextInt();
            int v = input.nextInt();
            check(duongTron, u, v);
        }
    }
}
