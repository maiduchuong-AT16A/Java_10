package Lesson07.Nguyen_Thanh_Hung;

public class MyPoint {
	private double x;
	private double y;
	
	public MyPoint() {
		super();
		this.x = 0.0;
		this.y = 0.0;
	}
	public MyPoint(double x, double y) {
		super();
		this.x = x;
		this.y = y;
	}
	
	
	
	public double getX() {
		return x;
	}
	public void setX(double x) {
		this.x = x;
	}
	public double getY() {
		return y;
	}
	public void setY(double y) {
		this.y = y;
	}
	public void setXY(double x, double y) {
		this.x = x;
		this.y = y;
	}
	public double getDistance(double x1, double y1) {
		double xKc = this.x - x1 ;
		double yKc = this.y - y1 ;
		double Kc;
		return Kc = Math.sqrt(xKc*xKc+yKc*yKc);
		
	}
	@Override
	public String toString() {
		return "MyPoint [x=" + x + ", y=" + y + "]";
	}
	
}
