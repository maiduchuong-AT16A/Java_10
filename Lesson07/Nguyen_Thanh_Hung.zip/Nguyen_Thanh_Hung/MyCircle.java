package Lesson07.Nguyen_Thanh_Hung;

public class MyCircle {
	public MyCircle(double x,double y, double radius) {
		super();
		this.center = new MyPoint(x,y);
		this.radius = radius;
	}
	public MyCircle() {
		super();
		this.center = new MyPoint(0,0);
		this.radius = 0;
	}
	private MyPoint center;
	private double radius;
	public MyPoint getCenter() {
		return center;
	}
	public void setCenter(MyPoint center) {
		this.center = center;
	}
	public double getRadius() {
		return radius;
	}
	public void setRadius(double radius) {
		this.radius = radius;
	}
	
	public double getCircumference() {
		return 2 * Math.PI * radius;
	}
	public double getArea() {
		return Math.PI * radius *radius;
	}
	@Override
	public String toString() {
		return "Circle info:" + center + ", radius=" + radius + ", circumference" + getCircumference() + ", area"
				+ getArea() ;
	}
	
}
