package Lesson07.Nguyen_Thanh_Hung;

public class TestMyCircle {
	public static void main(String[] args) {
		MyCircle c1 = new MyCircle(2,3,5);
		MyCircle c2 = new MyCircle(6,6,8);
		System.out.println("chu vi hình tròn c1:" + c1.getCircumference());
		System.out.println("diện tích hình tròn c1:"+ c1.getArea());
		System.out.println("chu vi hình tròn c2:" + c2.getCircumference());
		System.out.println("diện tích hình tròn c2:"+ c2.getArea());
		System.out.println("thông tin của đường tròn c1:"+c1.toString());
		System.out.println("thông tin của đường tròn c2:"+c2.toString());

	}
}
