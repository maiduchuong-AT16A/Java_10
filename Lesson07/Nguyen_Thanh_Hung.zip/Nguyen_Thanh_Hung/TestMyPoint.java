package Lesson07.Nguyen_Thanh_Hung;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class TestMyPoint {
	public static void main(String[] args) throws FileNotFoundException {
		System.setIn(new FileInputStream("input.txt"));
		Scanner sc = new Scanner(System.in);
		
		MyPoint p1 = new MyPoint(15,20);
		MyPoint p2 = new MyPoint();
		int a = sc.nextInt();
		int b = sc.nextInt();
		p2.setX(a);
		p2.setY(b);
		
		MyPoint p3 = new MyPoint();
		int c = sc.nextInt();
		int d = sc.nextInt();
		p3.setXY(c,d);
		
		System.out.println("Khoảng cách từ điểm p1 đến điểm có tọa độ(10,10) là :"+p1.getDistance(10,10));
		System.out.println("Khoảng cách từ điểm p2 đến điểm có tọa độ(10,10) là :"+p2.getDistance(10,10));
		System.out.println("Khoảng cách từ điểm p3 đến điểm có tọa độ(10,10) là :"+p3.getDistance(10,10));
		System.out.println("Thông tin điểm p1 :"+ p1.toString());
		System.out.println("Thông tin điểm p2 :"+ p2.toString());
		System.out.println("Thông tin điểm p3 :"+ p3.toString());
	
	}
}
