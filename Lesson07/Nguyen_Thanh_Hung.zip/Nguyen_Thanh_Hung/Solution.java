package Lesson07.Nguyen_Thanh_Hung;

import java.util.Scanner;

public class Solution {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int T = sc.nextInt();
		for( int i=1; i<=T;i++) {
			System.out.println("Case #" + i);
		}
		int n = sc.nextInt();
		MyPoint[] MP1 = new MyPoint[n];
		
		for( int i =0;i<n;i++) {
			double x = sc.nextDouble();
			double y = sc.nextDouble();
			MP1[i] = new MyPoint(x,y);
		}
		
		int k = sc.nextInt();
        double x1 = sc.nextDouble();
        double y1 = sc.nextDouble();
        double distance = MP1[k].getDistance(x1, y1);
        System.out.println("distance = " + String.format("%.3f", distance));
        
        int p = sc.nextInt();
        System.out.println(MP1[p].toString());
        
        int m = sc.nextInt();
        MyCircle[] circles = new MyCircle[m];
        
        double[] centerX = new double[m];
        double[] centerY = new double[m];
        for (int i = 0; i < m; i++) {
            centerX[i] = sc.nextDouble();
            centerY[i] = sc.nextDouble();
        }
        
        for (int i = 0; i < m; i++) {
            double radius = sc.nextDouble();
            circles[i] = new MyCircle(centerX[i], centerY[i], radius);
        }
        
        int q = sc.nextInt();
        MyCircle circle = circles[q];
        System.out.println("Circle info: (" + circle.getCenter().getX() + ", " + circle.getCenter().getY() + ")" + 
                         ", radius = " + circle.getRadius() + 
                         ", circumference = " + String.format("%.3f", circle.getCircumference()) + 
                         ", area = " + String.format("%.3f", circle.getArea()));
        int i = sc.nextInt();
        int j = sc.nextInt();
        
        MyCircle circle1 = circles[i];
        MyCircle circle2 = circles[j];
        double distance12 = circle1.getCenter().getDistance(circle2.getCenter().getX(), circle2.getCenter().getY());
        double radiusSum = circle1.getRadius() + circle2.getRadius();
        double radiusDiff = Math.abs(circle1.getRadius() - circle2.getRadius());
        
        String relativePosition;
		if (distance12 < radiusDiff) {
        	if (circle1.getRadius() < circle2.getRadius()) {
                relativePosition = "Circle " + i + " is inside Circle " + j;
            } else {
                relativePosition = "Circle " + j + " is inside Circle " + i;
            }
        } else if (distance12 <= radiusSum) {
        	relativePosition = "Circle " + i + " intersects with Circle " + j;
        } else {
        	relativePosition = "Circle " + i + " does not intersect Circle " + j;
        }
        
        System.out.println(relativePosition);
    }
        
	}
	
