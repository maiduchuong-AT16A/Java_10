/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.act.vn.lesson7.Hoang_Hung_Manh;

import java.util.Scanner;

/**
 *
 * @author manh
 */
public class Solution {

    public Mypoint a = new Mypoint();
    public myCricle circle = new myCricle();
    public Mypoint tam = new Mypoint();

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int T = sc.nextInt();
        for (int t = 0; t < T; t++) {
            System.out.println("Case#" + (t + 1) + ": ");
            int n = sc.nextInt();
            Mypoint b[] = new Mypoint[n];
            for (int i = 0; i < n; i++) {
                double x = sc.nextDouble();
                double y = sc.nextDouble();
                b[i] = new Mypoint();
                b[i].SetXY(x, y);
            }
            int k = sc.nextInt();
            double x1 = sc.nextDouble();
            double y1 = sc.nextDouble();
            double c = b[k].getDistance(x1, y1);
            System.out.printf("distance = %.3f\n", c);
            int p = sc.nextInt();
            System.out.println(b[p].toString());
            int m = sc.nextInt();
            myCricle z[] = new myCricle[m];
            double[] r = new double[m];
            for (int i = 0; i < m; i++) {
                double x = sc.nextDouble();
                double y = sc.nextDouble();
                Mypoint tam = new Mypoint();
                tam.SetXY(x, y);
                z[i] = new myCricle();
                z[i].setTam(tam);
            }
            for (int i = 0; i < m; i++) {
                r[i] = sc.nextDouble();
                z[i].setBankinh(r[i]);
            }
            int q = sc.nextInt();
            System.out.println(z[q].toString());
            int i = sc.nextInt();
            int j = sc.nextInt();
            double a = z[j].tam.x;
            double g = z[j].tam.y;
            double d = z[i].getDistance(a, g);
            double f = z[i].getBankinh() - z[j].getBankinh();
            double l = z[i].getBankinh() + z[j].getBankinh();
            double h = Math.abs(f);
            if (d < h) {
                System.out.println("Circle " + i + " is inside Circle " + j);
            } else if (d == l || d == h) {
                System.out.println("Circle " + i + " intersects with Circle " + j);  // tiếp xúc
            } else if (d < l) {
                System.out.println("Circle " + i + " intersects with Circle " + j);
            } else {
                System.out.println("Circle " + i + " does not intersect Circle " + j);
            }
        }
    }
}
