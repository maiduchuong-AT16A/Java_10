/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.act.vn.lesson7.Hoang_Hung_Manh;

/**
 *
 * @author manh
 */
public class myCricle {

    public double bankinh;
    public Mypoint tam = new Mypoint();
    final double PI = 3.14;

    public myCricle() {
        this.tam.x = 0;
        this.tam.y = 0;
        this.bankinh = 0;
    }

    public myCricle(double x, double y, double r) {
        this.tam.x = x;
        this.tam.y = y;
        this.bankinh = r;
    }

    public double getBankinh() {
        return bankinh;
    }

    public Mypoint getTam() {
        return tam;
    }

    public void setBankinh(double bankinh) {
        this.bankinh = bankinh;
    }

    public void setTam(Mypoint tam) {
        this.tam = tam;
    }

    public double getCircumference() {
        return 2 * PI * this.bankinh;
    }

    public double getArea() {
        
        return  Math.round(PI * this.bankinh * this.bankinh * 100.0) / 100.0;
    }

    @Override
    public String toString() {
        return "Circle info: (" + this.tam.x + "," + this.tam.y + ")" + ", radius =" + this.bankinh + ", circumference = " + this.getCircumference() + ", area = " +this.getArea();
    }

    public double getDistance(double x1, double y1) {
        double a = (double) (tam.x - x1);
        double b = (double) (tam.y - y1);
        return Math.sqrt(a * a + b * b);
    }
}
