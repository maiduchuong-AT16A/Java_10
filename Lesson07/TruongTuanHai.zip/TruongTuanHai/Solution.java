/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.actvn.lession07.TruongTuanHai;

import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class Solution {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int T = sc.nextInt();
        for (int t = 1; t <= T; t++) {
            int n = sc.nextInt();
            MyPoint[] points = new MyPoint[n];
            for (int i = 0; i < n; i++) {
                double x = sc.nextDouble();
                double y = sc.nextDouble();
                points[i] = new MyPoint(x, y);
            }
            int k = sc.nextInt();
            double xCheck = sc.nextDouble();
            double yCheck = sc.nextDouble();
            double distance = points[k].getDistance(xCheck, yCheck);
            int p = sc.nextInt();
            MyPoint pointP = points[p];
            int m = sc.nextInt();
            MyPoint[] centers = new MyPoint[m];
            for (int i = 0; i < m; i++) {
                double x = sc.nextDouble();
                double y = sc.nextDouble();
                centers[i] = new MyPoint(x, y);
            }
            double[] radii = new double[m];
            for (int i = 0; i < m; i++) {
                radii[i] = sc.nextDouble();
            }
            MyCircle[] circles = new MyCircle[m];
            for (int i = 0; i < m; i++) {
                circles[i] = new MyCircle(centers[i], radii[i]);
            }
            int q = sc.nextInt();
            MyCircle circleQ = circles[q];
            int i = sc.nextInt();
            int j = sc.nextInt();
            MyCircle ci = circles[i];
            MyCircle cj = circles[j];
            double x1 = ci.getCenter().getX();
            double y1 = ci.getCenter().getY();
            double x2 = cj.getCenter().getX();
            double y2 = cj.getCenter().getY();
            double d = Math.sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
            String result = "";
            if (d > ci.getRadius() + cj.getRadius()) {
                result = "Circle " + i + " does not intersect Circle " + j;
            } else if (d + ci.getRadius() < cj.getRadius()) {
                result = "Circle " + i + " is inside Circle " + j;
            } else if (d + cj.getRadius() < ci.getRadius()) {
                result = "Circle " + j + " is inside Circle " + i;
            } else {
                result = "Circle " + j + " intersects with Circle " + i;
            }
            System.out.println("Case #" + t + ":");
            System.out.printf("distance = %.3f\n", distance);
            System.out.println(pointP.toString());
            System.out.println(circleQ.toString());
            System.out.println(result);
        }
        sc.close();
    }
}
