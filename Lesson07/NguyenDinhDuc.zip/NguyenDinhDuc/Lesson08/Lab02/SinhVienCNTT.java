package Lab02;

public class SinhVienCNTT extends SinhVien {
    private double diemWeb;
    private double diemAndroid;
    private double diemNhung;

    public SinhVienCNTT(String hoten, double diemWeb, double diemAndroid, double diemNhung) {
        super(hoten, "CNTT");
        this.diemWeb = diemWeb;
        this.diemAndroid = diemAndroid;
        this.diemNhung = diemNhung;
    }

    @Override
    public double getDiem() {
        return (diemWeb + diemAndroid * 2 + diemNhung*2) / 5;
    }

}
