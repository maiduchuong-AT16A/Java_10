package Lab02;

public class SinhVienATTT extends SinhVien {

    private double diemMD;
    private double diemLTAT;
    private double diemDTS;

    public SinhVienATTT(String hoten, double diemMD, double diemLTAT, double diemDTS) {
        super(hoten, "ATTT");
        this.diemMD = diemMD;
        this.diemLTAT = diemLTAT;
        this.diemDTS = diemDTS;
    }

    @Override
    public double getDiem() {
        return (diemMD*2+diemLTAT*2+diemDTS)/5;
    }

}
