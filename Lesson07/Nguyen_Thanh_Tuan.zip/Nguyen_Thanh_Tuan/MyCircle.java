package com.act.vn.Lesson07.Nguyen_Thanh_Tuan;

public class MyCircle {

    private MyPoint center;
    private double radius;

    public MyCircle() {
        this.center = new MyPoint();
        this.radius = 0;
    }

    public MyCircle(double x, double y, double radius) {
        this.center = new MyPoint(x, y);
        this.radius = radius;
    }

    public MyCircle(MyPoint center, double radius) {
        this.center = center;
        this.radius = radius;
    }

    public MyPoint getCenter() {
        return center;
    }

    public void setCenter(MyPoint center) {
        this.center = center;
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    public double getCircumference() {
        return 2 * Math.PI * radius;
    }

    public double getArea() {
        return Math.PI * radius * radius;
    }

    @Override
    public String toString() {
        return String.format(
                "Circle info: %s, radius = %.2f, circumference = %.3f, area = %.3f",
                center.toString(), radius, getCircumference(), getArea());
    }

}
