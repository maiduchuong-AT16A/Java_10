package com.act.vn.Lesson07.Nguyen_Thanh_Tuan;

import java.util.Scanner;

public class Solution {

    private static double khoangCach(MyCircle c1, MyCircle c2) {
        return c1.getCenter().getDistance(c2.getCenter().getX(), c2.getCenter().getY());
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int T = Integer.parseInt(sc.nextLine());
        for (int t = 1; t <= T; t++) {

            int n = Integer.parseInt(sc.nextLine());
            MyPoint[] points = new MyPoint[n];
            String[] pointData = sc.nextLine().split(" ");
            for (int i = 0; i < n; i++) {
                double x = Double.parseDouble(pointData[2 * i]);
                double y = Double.parseDouble(pointData[2 * i + 1]);
                points[i] = new MyPoint(x, y);
            }

            String[] d3 = sc.nextLine().split(" ");
            int k = Integer.parseInt(d3[0]);
            double x1 = Double.parseDouble(d3[1]);
            double y1 = Double.parseDouble(d3[2]);
            double distance = points[k].getDistance(x1, y1);

            int p = Integer.parseInt(sc.nextLine());

            int m = Integer.parseInt(sc.nextLine());
            MyCircle[] circles = new MyCircle[m];
            String[] centerData = sc.nextLine().split(" ");
            String[] radiusData = sc.nextLine().split(" ");
            for (int i = 0; i < m; i++) {
                double cx = Double.parseDouble(centerData[2 * i]);
                double cy = Double.parseDouble(centerData[2 * i + 1]);
                double r = Double.parseDouble(radiusData[i]);
                circles[i] = new MyCircle(new MyPoint(cx, cy), r);
            }

            int q = Integer.parseInt(sc.nextLine());

            String[] d9 = sc.nextLine().split(" ");
            int i = Integer.parseInt(d9[0]);
            int j = Integer.parseInt(d9[1]);

            System.out.printf("Case #%d:\n", t);
            System.out.printf("distance = %.3f%n", distance);
            System.out.println(points[p]);
            System.out.println(circles[q]);
            double d = khoangCach(circles[i], circles[j]);
            double r1 = circles[i].getRadius();
            double r2 = circles[i].getRadius();
            if (d < Math.abs(r1 - r2)) {
                System.out.printf("Circle %d is inside Circle %d\n", i, j);
            } else if (d > r1 + r2) {
                System.out.printf("Circle %d does not intersect Circle %d\n", i, j);
            } else {
                System.out.printf("Circle %d intersects with Circle %d\n", i, j);
            }
        }

    }
}
