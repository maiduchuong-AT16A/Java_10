package com.act.vn.Lesson07.Nguyen_Thanh_Tuan;

public class TestMyCircle {

    public static void main(String[] args) {
        MyCircle c1 = new MyCircle(2, 3, 5);
        MyPoint p = new MyPoint(6, 6);
        MyCircle c2 = new MyCircle(p, 8);
        System.out.printf("Circumference of c1: %.3f%n", c1.getCircumference());
        System.out.printf("Area of c1: %.3f%n", c1.getArea());

        System.out.printf("Circumference of c2: %.3f%n", c2.getCircumference());
        System.out.printf("Area of c2: %.3f%n", c2.getArea());

        System.out.println(c1);
        System.out.println(c2);
    }
}
