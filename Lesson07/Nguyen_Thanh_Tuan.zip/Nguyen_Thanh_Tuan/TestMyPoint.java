package com.act.vn.Lesson07.Nguyen_Thanh_Tuan;

public class TestMyPoint {

    public static void main(String[] args) {
        MyPoint p1 = new MyPoint(15, 20);
        MyPoint p2 = new MyPoint();
        p2.setX(2);
        p2.setY(3);
        MyPoint p3 = new MyPoint();
        p3.setXY(5, 6);

        System.out.printf("Distance from p1 to (10, 10): %.3f%n", p1.getDistance(10, 10));
        System.out.printf("Distance from p2 to (10, 10): %.3f%n", p2.getDistance(10, 10));
        System.out.printf("Distance from p3 to (10, 10): %.3f%n", p3.getDistance(10, 10));

        System.out.println(p1);
        System.out.println(p2);
        System.out.println(p3);
    }
}
