/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.act.vn.lesson06.Hoang_Hung_Manh;
import java.util.Scanner;
import static com.act.vn.lesson06.Hoang_Hung_Manh.Practice.getFibonacci;
import static com.act.vn.lesson06.Hoang_Hung_Manh.Practice.getMax;
import static com.act.vn.lesson06.Hoang_Hung_Manh.Practice.getMin;
import static com.act.vn.lesson06.Hoang_Hung_Manh.Practice.sum;
import static com.act.vn.lesson06.Hoang_Hung_Manh.Practice.toLowerCase;
import static com.act.vn.lesson06.Hoang_Hung_Manh.Practice.toUpperCase;
import static com.act.vn.lesson06.Hoang_Hung_Manh.Practice.toUpperfirstchar;

/**
 *
 * @author manh
 */
public class Solution {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        for (int i = 0; i < n; i++) {
            System.out.println("Case #" + (i+1)+":");
            int t = sc.nextInt();
            double[] m = new double[t];
            for (int j = 0; j < t; j++) {
                m[j] = sc.nextDouble();
            }
            sc.nextLine();
            String b = sc.nextLine();
            String c = sc.nextLine();
            int a = sc.nextInt();
            System.out.println("Sum: "+sum(m));
            System.out.println("Min: "+getMin(m));
            System.out.println("Max: "+getMax(m));
            System.out.println("To upper: " + toUpperCase(b));
            System.out.println("To lower: " + toLowerCase(c));
            System.out.println("To upper first char: " + toUpperfirstchar(b) + " - " + toUpperfirstchar(c));
            System.out.printf("Fibonacci(%d): %d\n", a, getFibonacci(a));
        }
    }
}
