package Lesson06.Nguyen_Thanh_Hung;

import java.util.Scanner;

public class Solution {
    public static void main(String[] args) {
        Scanner scanner = new java.util.Scanner(System.in);
        int T = scanner.nextInt();
        
        for (int testCase = 1; testCase <= T; testCase++) {
            System.out.println("Case #" + testCase + ":");
            
            // Đọc input cho từng dòng
            int n = scanner.nextInt(); // số lượng phần tử mảng 1 chiều
            double[] arr1 = new double[n];
            for (int i = 0; i < n; i++) {
                arr1[i] = scanner.nextDouble();
            }
            
            int m = scanner.nextInt(); // kích thước mảng 1 chiều thứ 2
            // Consume newline after reading m
            scanner.nextLine();
            
            String str1 = scanner.nextLine();
            String str2 = scanner.nextLine();
            int k = scanner.nextInt();
            
            // Tính toán và in kết quả
            System.out.println(Practice.sum(arr1));
            System.out.println(Practice.getMin(arr1));
            System.out.println(Practice.getMax(arr1));
            System.out.println(Practice.ToUpper(str1));
            System.out.println(Practice.ToLower(str2));
            System.out.println(Practice.toUpperFirstChar(str1 + " " + str2));
            System.out.println(Practice.getFibonacci(k));
        }
        
        scanner.close();
    }
}
