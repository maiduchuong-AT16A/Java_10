package Lesson06.Nguyen_Thanh_Hung;

public class Practice {
	public static final double sum(double... x) {
		int s = 0;
		for (double i : x) {
			s += i;

		}
		return s;
	}

	public static final double getMin(double... x) {
		double min = x[0];
		for (int i = 0; i < x.length; i++) {
			if (x[i] < min) {
				min = x[i];
			}
		}
		return min;
	}

	public static final double getMax(double... x) {
		double max = x[0];
		for (int i = 0; i < x.length; i++) {
			if (x[i] < max) {
				max = x[i];
			}
		}
		return max;
	}

	public static String ToUpper(String str) {
		String S = "";
		for (int i = 0; i < str.length(); i++) {
			char c = str.charAt(i);
			if (c >= 'a' && c <= 'z') {
				c = (char) (c - 32);
			}
			S = S + c;
		}
		return S;
	}

	public static String ToLower(String str) {
		String St = "";
		for (int i = 0; i < str.length(); i++) {
			char c = str.charAt(i);
			if (c >= 'A' && c <= 'Z') {
				c = (char) (c + 32);
			}
			St = St + c;
		}
		return St;
	}

	public static String toUpperFirstChar(String str) {
		String[] words = str.split(" ");
		for (int i = 0; i < words.length; i++) {
			if (words[i].length() == 0) {
				continue;
			}
			char firstChar = words[i].charAt(0);
			String upperFirstChar = String.valueOf(firstChar).toUpperCase();
			words[i] = upperFirstChar + words[i].substring(1).toLowerCase();
		}
		return String.join(" ", words);
	}

	public static long getFibonacci(int position) {
		if (position <= 0)
			return 0;
		if (position == 1 || position == 2)
			return 1;

		long a = 1, b = 1, result = 0;
		for (int i = 3; i <= position; i++) {
			result = a + b;
			a = b;
			b = result;
		}
		return result;
	}

}
