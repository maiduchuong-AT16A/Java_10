/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javacore.basic.lesson6;

import java.util.Scanner;

/**
 *
 * @author OS
 */
public class Solution{
    static Scanner sc = new Scanner (System.in);
    static String str1, str2;
    static int k;
    static int n;
    static double[] db;
    static void nhap(){
        n = sc.nextInt();
        db = new double[n];
        for(int i = 0; i < n; i++){
            db[i] = sc.nextDouble();
        }sc.nextLine();
        str1 = sc.nextLine();
        str2 = sc.nextLine();
        k = sc.nextInt(); sc.nextLine();
    }
    
    static void solve(int x){
        System.out.println("Case #" + x);
        System.out.println("Sum: " + pratice.getSum(db));
        System.out.println("Min: " + pratice.getMin(db));
        System.out.println("Max: " + pratice.getMax(db));
        System.out.println("To uppper: " + pratice.toUpper(str1));
        System.out.println("To lower: " + pratice.toLowwer(str2));
        System.out.println("To upper first char: " + pratice.toUpperFirstChar(str1) + " - " + pratice.toUpperFirstChar(str2));
        System.out.println("Fibonaci(" + k + "): " + pratice.getFibonaci(k));
    }
    
    public static void main(String[] args) {
        int t = sc.nextInt();
        for(int i = 1; i <= t; i++){
            nhap();
            solve(i);
        }
    }
}
