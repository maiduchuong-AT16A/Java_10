/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javacore.basic.lesson6;

/**
 *
 * @author OS
 */
public class pratice {
    public static final double getSum(double ...a){
        double sum = 0;
        for(double mem : a){
            sum += mem;
        }
        return sum;
    }
    
    public static final double getMax(double ...a){
        double max = -Double.MAX_VALUE;
        for(double mem : a){
            if(max < mem) max = mem;
        }
        return max;
    }
    
    public static final double getMin(double ...a){
        double min = Double.MAX_VALUE;
        for(double mem : a){
            if(min > mem) min = mem;
        }
        return min;
    }
    
    public static final String toUpper(String a){
        String res = "";
        for(int i = 0; i < a.length(); i ++){
            char c = a.charAt(i);
            if(c >= 'a' && c <= 'z') {
                c = (char)((int)a.charAt(i) - 32);
            }
            res += c;
        }
        return res;
    }
    
    public static final String toLowwer(String a){
        String res = "";
        for(int i = 0; i < a.length(); i ++){
            char c = a.charAt(i);
            if(c >= 'A' && c <= 'Z') {
                c = (char)((int)a.charAt(i) + 32);
            }
            res += c;
        }
        return res;
    }
    
    public static final String toUpperFirstChar(String a){
        String[] word = a.split(" ");
        String[] UpperFirstChar = new String[100];
        for(int i = 0; i < word.length; i++){
            UpperFirstChar[i] = String.valueOf(word[i].charAt(0)).toUpperCase();
            word[i] = UpperFirstChar[i] + toLowwer(word[i].substring(1));
        }
        String str = String.join(" ", word);
        return str;
    }
    
    public static final long getFibonaci(int position){
        if(position == 1) return 1;
        if(position == 2) return 1;
        return getFibonaci(position - 1) + getFibonaci(position - 2);
    }
}
