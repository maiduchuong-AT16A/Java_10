package javacore.basic.lesson06;

public class Practice {
	public static final double sum(double... values) {
        double result = 0;
        for (int i = 0; i < values.length; i++) {
            result += values[i];
        }
        return result;
    }

    public static final double getMin(double... values) {
        if (values.length == 0) return 0;
        double minValue = values[0];
        for (int i = 1; i < values.length; i++) {
            if (values[i] < minValue) {
                minValue = values[i];
            }
        }
        return minValue;
    }

    public static final double getMax(double... values) {
        if (values.length == 0) return 0;
        double maxValue = values[0];
        for (int i = 1; i < values.length; i++) {
            if (values[i] > maxValue) {
                maxValue = values[i];
            }
        }
        return maxValue;
    }

    public static String toUpper(String s) {
        String result = "";
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= 'a' && c <= 'z') {
                result += (char)(c - 32);
            } else {
                result += c;
            }
        }
        return result;
    }

    public static String toLower(String s) {
        String result = "";
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= 'A' && c <= 'Z') {
                result += (char)(c + 32);
            } else {
                result += c;
            }
        }
        return result;
    }

    public static String toUpperFirstChar(String input) {
        String[] parts = input.split(" ");
        String finalStr = "";
        for (int i = 0; i < parts.length; i++) {
            if (parts[i].length() == 0) continue;
            char first = parts[i].charAt(0);
            String upper = String.valueOf((char)(first >= 'a' && first <= 'z' ? first - 32 : first));
            String rest = parts[i].substring(1);
            finalStr += upper + rest;
            if (i != parts.length - 1) finalStr += " ";
        }
        return finalStr;
    }

    public static long getFibonacci(int pos) {
        if (pos <= 0) return 0;
        if (pos == 1) return 1;
        return getFibonacci(pos - 1) + getFibonacci(pos - 2);
    }
}
