package javacore.basic.lesson06;

import java.util.Scanner;

public class Solution {
	public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int testCount = Integer.parseInt(input.nextLine());

        for (int tc = 1; tc <= testCount; tc++) {
            int n = Integer.parseInt(input.nextLine());
            String[] nums = input.nextLine().split(" ");
            double[] arr = new double[n];
            for (int i = 0; i < n; i++) {
                arr[i] = Double.parseDouble(nums[i]);
            }

            String str1 = input.nextLine();
            String str2 = input.nextLine();
            int k = Integer.parseInt(input.nextLine());

            double tong = Practice.sum(arr);
            double nhoNhat = Practice.getMin(arr);
            double lonNhat = Practice.getMax(arr);
            String str1Upper = Practice.toUpper(str1);
            String str2Lower = Practice.toLower(str2);
            String fullTitle = Practice.toUpperFirstChar(str1) + " - " + Practice.toUpperFirstChar(str2);
            long fib = Practice.getFibonacci(k);

            System.out.println("Case #" + tc + ":");
            System.out.printf("Sum: %.2f\n", tong);
            System.out.println("Min: " + nhoNhat);
            System.out.println("Max: " + lonNhat);
            System.out.println("To upper: " + str1Upper);
            System.out.println("To lower: " + str2Lower);
            System.out.println("To upper first char: " + fullTitle);
            System.out.println("Fibonacci(" + k + "): " + fib);
        }

        input.close();
    }
}
