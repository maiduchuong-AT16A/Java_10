/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.act.vn.Lesson08.Lab01.Vu_Khai_Hoan;

/**
 *
 * @author ACER
 */
public class HinhChuNhat {
    private double W;
    private double H;
    
    public HinhChuNhat() {
        
    }

    public HinhChuNhat(double W, double H) {
        this.W = W;
        this.H = H;
    }

    public double getW() {
        return W;
    }

    public void setW(double W) {
        this.W = W;
    }

    public double getH() {
        return H;
    }

    public void setH(double H) {
        this.H = H;
    }
    
    public double chuVi() {
        return (W+H)*2;
    }
    
    public double dienTich() {
        return W*H;
    }
    
    public String hienThiThongTin() {
        return String.format("HCN(%f, %f): chu vi = %f, dien tich = %f", getW(), getH(), chuVi(), dienTich());
    }
}
