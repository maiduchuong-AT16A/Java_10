/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.act.vn.Lesson08.Lab01.Vu_Khai_Hoan;

/**
 *
 * @author ACER
 */
public class HinhVuong extends HinhChuNhat{
    double C;
    
    public HinhVuong() {
        
    }

    public HinhVuong(double C) {
        this.C = C;
    }

    public double getC() {
        return C;
    }

    public void setC(double C) {
        this.C = C;
    }
    
    @Override
    public double chuVi() {
        return C*4;
    }
    
    @Override
    public double dienTich() {
        return C*C;
    }
    
    @Override
    public String hienThiThongTin() {
        return String.format("HV(canh = %f): chu vi = %f, dien tich = %f", getC(), chuVi(), dienTich());
    }
    
    
}
