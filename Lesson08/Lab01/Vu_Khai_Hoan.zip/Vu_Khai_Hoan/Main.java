/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.act.vn.Lesson08.Lab01.Vu_Khai_Hoan;

import java.util.Scanner;

/**
 *
 * @author ACER
 */
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int T = sc.nextInt();
        for(int i = 0; i < T; i++) {
            int M = sc.nextInt();
            int N = sc.nextInt();
            
            int p = sc.nextInt();
            int q = sc.nextInt();
            
            HinhChuNhat hcn[] = new HinhChuNhat[M];
            for(int j = 0; j < M; j++) {
                double w = sc.nextDouble();
                double h = sc.nextDouble();
                hcn[j] = new HinhChuNhat(w, h);
            }
            
            HinhVuong hv[] = new HinhVuong[N];
            for(int j = 0; j < M; j++) {
                double c = sc.nextDouble();
                hv[j] = new HinhVuong(c);
            }

            int P = sc.nextInt();
            int Q = sc.nextInt();
            
            for(int j = 0; j < p; j++) {
                System.out.println(hcn[P].hienThiThongTin());
            }
            for(int j = 0; j < q; j++) {
                System.out.println(hv[Q].hienThiThongTin());
            }
        }
    }
}
