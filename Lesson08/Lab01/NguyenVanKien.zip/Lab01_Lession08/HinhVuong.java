/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lab01_Lession08;

/**
 *
 * @author Admin
 */
public class HinhVuong extends HinhChuNhat{
    private double canh;
    public HinhVuong(){
        
    }
    public HinhVuong(double canh){
        super(canh,canh);
    }
    public void hienThiThongTin(){
        System.out.printf("HV(Canh = %.6f): chu vi = %.3f, dien tich = %.3f\n",
                canh, getChuVi(),getDienTich());
    }
}
