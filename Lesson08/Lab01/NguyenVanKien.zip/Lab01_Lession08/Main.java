/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lab01_Lession08;

import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int T = sc.nextInt();
        for (int t = 1; t <= T; t++) {
            System.out.println("Case#" + t + ":");
            int M = sc.nextInt();
            int N = sc.nextInt();
            int P = sc.nextInt();
            int Q = sc.nextInt();
            HinhChuNhat[] hcn = new HinhChuNhat[M];
            for (int i = 0; i < M; i++) {
                double dai = sc.nextDouble();
                double rong = sc.nextDouble();
                hcn[i] = new HinhChuNhat(dai, rong);
            }
            HinhVuong[] hv = new HinhVuong[N];
            for (int i = 0; i < N; i++) {
                double canh = sc.nextDouble();
                hv[i] = new HinhVuong(canh);
            }
            for (int i = 0; i < P; i++) {
                int k = sc.nextInt();
                hcn[k].hienThiThongTin();
            }
            for (int i = 0; i < Q; i++) {
                int k = sc.nextInt();
                hv[k].hienThiThongTin();
            }
        }
    }
}
