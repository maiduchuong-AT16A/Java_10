/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lab01_Lession08;

/**
 *
 * @author Admin
 */
public class HinhChuNhat {
    private double chieuDai, chieuRong;
    public HinhChuNhat(){
        
    }
    public HinhChuNhat(double chieuDai, double chieuRong){
        this.chieuDai = chieuDai;
        this.chieuRong = chieuRong;
    }

    public double getChieuDai() {
        return chieuDai;
    }

    public void setChieuDai(double chieuDai) {
        this.chieuDai = chieuDai;
    }

    public double getChieuRong() {
        return chieuRong;
    }

    public void setChieuRong(double chieuRong) {
        this.chieuRong = chieuRong;
    }
    public double getChuVi(){
        return 2*(chieuDai + chieuRong);
    }
    public double getDienTich(){
        return chieuDai * chieuRong;
    }
    public void hienThiThongTin(){
        System.out.printf("HCN(%.06f, %.06f): chu vi = %.3f, dien tich = %.3f\n",
                chieuDai, chieuRong, getChuVi(), getDienTich());
    }
    
}
