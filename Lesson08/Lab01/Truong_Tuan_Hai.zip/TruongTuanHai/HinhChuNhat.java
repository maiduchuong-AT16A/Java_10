/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.actvn.lession08.lab01.TruongTuanHai;

/**
 *
 * @author Admin
 */
public class HinhChuNhat {

    private double chieuDai;
    private double chieuRong;

    public HinhChuNhat() {
    }

    public HinhChuNhat(double chieuDai, double chieuRong) {
        this.chieuDai = chieuDai;
        this.chieuRong = chieuRong;
    }

    public double getChieuDai() {
        return chieuDai;
    }

    public void setChieuDai(double chieuDai) {
        this.chieuDai = chieuDai;
    }

    public double getChieuRong() {
        return chieuRong;
    }

    public void setChieuRong(double chieuRong) {
        this.chieuRong = chieuRong;
    }

    public double getChuVi() {
        double chuVi = 2 * (this.chieuDai + this.chieuRong);
        return chuVi;
    }

    public double getDienTich() {
        double dienTich = this.chieuDai * this.chieuRong;
        return dienTich;
    }

    public String hienThiThongTin() {
        return String.format("HCN(%.6f, %.6f): chu vi = %.3f, dien tich = %.3f", chieuDai, chieuRong, getChuVi(), getDienTich());
    }
}
