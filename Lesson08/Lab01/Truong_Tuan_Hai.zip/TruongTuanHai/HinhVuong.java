/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.actvn.lession08.lab01.TruongTuanHai;

/**
 *
 * @author Admin
 */
public class HinhVuong extends HinhChuNhat {

    private double canh;

    public HinhVuong() {
    }

    public HinhVuong(double canh) {
        this.canh = canh;
    }

    public double getCanh() {
        return canh;
    }

    public void setCanh(double canh) {
        this.canh = canh;
    }

    @Override
    public double getChuVi() {
        double chuVi = 4 * this.canh;
        return chuVi;
    }

    @Override
    public double getDienTich() {
        double dienTich = this.canh * this.canh;
        return dienTich;
    }

    @Override
    public String hienThiThongTin() {
        return String.format("HV(canh = %.6f): chu vi = %.3f, dien tich = %.3f", canh, getChuVi(), getDienTich());
    }
}
