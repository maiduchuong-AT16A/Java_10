
package lap01;

public class HinhVuong extends HinhChuNhat{
    private double canh;

    public HinhVuong() {
    }

    public HinhVuong(double canh) {
        this.canh = canh;
    }

    public double getCanh() {
        return canh;
    }

    public void setCanh(double canh) {
        this.canh = canh;
    }
    
    @Override
    public double getChuVi(){
        return canh * 4;
    }
    
    @Override
    public double getDienTich(){
        return canh * canh;
    }
    
    @Override
    public String hienThiThongTin(){
        return String.format("HV(canh = %.6f) : chu vi = %.3f, dientich = %.3f", getCanh(), getChuVi(), getDienTich());
    }
    
    
}
