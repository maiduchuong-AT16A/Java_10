package lap01;
public class HinhChuNhat {
    private double chieuDai;
    private double chieuRong;

    public HinhChuNhat() {
    }

    public HinhChuNhat(double chieuDai, double chieuRong) {
        this.chieuDai = chieuDai;
        this.chieuRong = chieuRong;
    }

    public double getChieuDai() {
        return chieuDai;
    }

    public void setChieuDai(double chieuDai) {
        this.chieuDai = chieuDai;
    }

    public double getChieuRong() {
        return chieuRong;
    }

    public void setChieuRong(double chieuRong) {
        this.chieuRong = chieuRong;
    }
    
    public double getChuVi(){
        return (chieuDai + chieuRong) * 2;
    }
    
    public double getDienTich(){
        return chieuDai * chieuRong;
    }
    
    public String hienThiThongTin(){
        return String.format("HCN(%.6f, %.6f), Chu Vi = %.3f, dien tich = %.3f", chieuDai, chieuRong, getChuVi(), getDienTich());
    }
}
