package com.actvn.Lesson08.Lab01.Dinh_Trong_Viet_Phu;

public class HinhChuNhat {
	private double chieuDai;
	private double chieuRong;
	public HinhChuNhat() {
		
	}
	public HinhChuNhat(double chieuDai, double chieuRong) {
		this.chieuDai = chieuDai;
		this.chieuRong = chieuRong;
	}
	public double getChieuDai() {
		return chieuDai;
	}
	public void setChieuDai(double chieuDai) {
		this.chieuDai = chieuDai;
	}
	public double getChieuRong() {
		return chieuRong;
	}
	public void setChieuRong(double chieuRong) {
		this.chieuRong = chieuRong;
	}
	
	public double getChuVi() {
		return (this.chieuDai + this.chieuRong)*2;
	}
	
	public double getDienTich() {
		return this.chieuDai*this.chieuRong;
	}
	
	public String hienThiThongTin() {
		return String.format("HCN(%.6f, %.6f): chu vi = %.3f, dien tich = %.3f",
	            chieuDai, chieuRong, getChuVi(), getDienTich());
	}
}
