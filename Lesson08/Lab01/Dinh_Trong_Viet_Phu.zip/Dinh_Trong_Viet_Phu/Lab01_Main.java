package com.actvn.Lesson08.Lab01.Dinh_Trong_Viet_Phu;

import java.util.Scanner;

public class Lab01_Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		int T = sc.nextInt();
		for (int t = 1; t <= T; t++) {
			int M = sc.nextInt();
			int N = sc.nextInt();
			int P = sc.nextInt();
			int Q = sc.nextInt();

			HinhChuNhat[] dsHCN = new HinhChuNhat[M];
			HinhVuong[] dsHV = new HinhVuong[N];

			for (int i = 0; i < M; i++) {
				double chieuDai = sc.nextDouble();
				double chieuRong = sc.nextDouble();
				dsHCN[i] = new HinhChuNhat(chieuDai, chieuRong);
			}

			for (int i = 0; i < N; i++) {
				double canh = sc.nextDouble();
				dsHV[i] = new HinhVuong(canh);
			}

			System.out.println("Case #" + t + ":");
			System.out.println(dsHCN[P].hienThiThongTin());
			System.out.println(dsHV[Q].hienThiThongTin());
		}

		sc.close();
	}
}
