package com.actvn.Lesson08.Lab01.Dinh_Trong_Viet_Phu;

public class HinhVuong extends HinhChuNhat{
	private double canh;

	public HinhVuong() {
	}

	public HinhVuong(double canh) {
		super();
		this.canh = canh;
	}

	public double getCanh() {
		return canh;
	}

	public void setCanh(double canh) {
		this.canh = canh;
	}

	@Override
	public double getChuVi() {
		// TODO Auto-generated method stub
		return canh*4;
	}

	@Override
	public double getDienTich() {
		// TODO Auto-generated method stub
		return canh*canh;
	}

	@Override
	public String hienThiThongTin() {
		// TODO Auto-generated method stub
		return String.format("HV(canh = %.6f): chu vi = %.3f, dien tich = %.3f",
	            canh, getChuVi(), getDienTich());
	}
	
}
