/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.act.edu.vn.NguyenMinhQuy.Lesson08;

/**
 *
 * @author OS
 */
import java.util.Scanner;

public class Lab01_Main {
    static Scanner sc = new Scanner(System.in);
    
    static int M, N, P, Q;
    static HinhChuNhat HCN[] = new HinhChuNhat[105];
    static HinhVuong HV[] = new HinhVuong[105];
    static int p[] = new int[105];
    static int q[] = new int[105];
    
    public static void input(){
        M = sc.nextInt();
        N = sc.nextInt();
        P = sc.nextInt();
        Q = sc.nextInt();
        
        for(int i = 0; i < M; i++){
            double dai = sc.nextDouble();
            double rong = sc.nextDouble();
            HCN[i] = new HinhChuNhat(dai, rong);
        }
        
        for(int i = 0; i < N; i++){
            double canh = sc.nextDouble();
            HV[i] = new HinhVuong(canh);
        }
        
        for(int i = 0; i < P; i++){
            p[i] = sc.nextInt();
        }
        
        for(int i = 0; i < Q; i++){
            q[i] = sc.nextInt();
        }
    }
    
    public static void solve(int stt){
        System.out.println("Case #" + stt + ":");
        for(int i = 0; i < P; i++){
            System.out.println(HCN[p[i]].hienThiThongTin());
        }
        
        for(int i = 0; i < Q; i++){
            System.out.println(HV[q[i]].hienThiThongTin());
        }
    }

    public static void main(String[] args) {
        int t = sc.nextInt();
        for(int i = 1; i <= t; i++){
            input();
            solve(i);
        }
    }
}
