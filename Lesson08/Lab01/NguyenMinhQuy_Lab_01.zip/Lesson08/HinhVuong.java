/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.act.edu.vn.NguyenMinhQuy.Lesson08;

/**
 *
 * @author OS
 */
public class HinhVuong extends HinhChuNhat{
    
    private double canh;

    public HinhVuong() {
    }

    public HinhVuong(double canh) {
        
        this.canh = canh;
        super.setDai(canh);
        super.setRong(canh);
    }

    public double getCanh() {
        return canh;
    }

    public void setCanh(double canh) {
        this.canh = canh;
    }

    @Override
    public double getChuVi() {
        return 4 * this.canh; // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public double getDienTich() {
        return this.canh * this.canh; // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    /**
     *
     * @return
     */
    @Override
    public String hienThiThongTin() {
        return String.format("HV(canh = %.6f): chu vi = %.3f, dien tich = %.3f", canh,getChuVi(),getDienTich());
    }
}
