/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.act.edu.vn.NguyenMinhQuy.Lesson08;

/**
 *
 * @author OS
 */
public class HinhChuNhat {
    private double dai;
    private double rong;

    public HinhChuNhat(double dai, double rong) {
        this.dai = dai;
        this.rong = rong;
    }

    public HinhChuNhat() {
    }

    public double getDai() {
        return dai;
    }

    public void setDai(double dai) {
        this.dai = dai;
    }

    public void setRong(double rong) {
        this.rong = rong;
    }

    public double getRong() {
        return rong;
    }
    
    public double getChuVi(){
        return 2 * (this.dai + this.rong);
    }
    
    public double getDienTich(){
        return this.dai * this.rong;
    }
    
    /**
     *
     * @return
     */
    public String hienThiThongTin(){
        return String.format("HCN(%.6f, %.6f): chu vi = %.3f, dien tich = %.3f", this.dai,this.rong,getChuVi(),getDienTich());
    }
}
