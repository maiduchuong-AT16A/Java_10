package com.act.vn.Lesson08.Nguyen_Thanh_Tuan.Lab01;

import java.util.Scanner;

public class Lab01_Main {

    static Scanner sc = new Scanner(System.in);

    static int M, N, P, Q;
    static HinhChuNhat HCN[] = new HinhChuNhat[105];
    static HinhVuong HV[] = new HinhVuong[105];
    static int p[] = new int[105];
    static int q[] = new int[105];

    static void input() {
        M = sc.nextInt();
        N = sc.nextInt();
        P = sc.nextInt();
        Q = sc.nextInt();

        for (int i = 0; i < M; i++) {
            double chieuDai = sc.nextDouble();
            double chieuRong = sc.nextDouble();
            HCN[i] = new HinhChuNhat(chieuDai, chieuRong);
        }

        for (int i = 0; i < N; i++) {
            double canh = sc.nextDouble();
            HV[i] = new HinhVuong(canh);
        }

        for (int i = 0; i < P; i++) {
            p[i] = sc.nextInt();
        }

        for (int i = 0; i < Q; i++) {
            q[i] = sc.nextInt();
        }
    }

    static void solve(int stt) {
        System.out.printf("Case #%d:\n", stt);
        for (int i = 0; i < P; i++) {
            System.out.println(HCN[p[i]].hienThiThongTin());
        }

        for (int i = 0; i < Q; i++) {
            System.out.println(HV[q[i]].hienThiThongTin());
        }
    }

    public static void main(String[] args) {

        int T = sc.nextInt();

        for (int i = 0; i < T; i++) {
            input();
            solve(i + 1);
        }
    }
}
