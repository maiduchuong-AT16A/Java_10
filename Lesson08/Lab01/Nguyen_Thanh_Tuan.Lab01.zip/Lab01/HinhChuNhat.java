package com.act.vn.Lesson08.Nguyen_Thanh_Tuan.Lab01;

public class HinhChuNhat {

    private double ChieuDai;
    private double ChieuRong;

    public HinhChuNhat() {
    }

    public HinhChuNhat(double ChieuDai, double ChieuRong) {
        this.ChieuDai = ChieuDai;
        this.ChieuRong = ChieuRong;
    }

    public double getChieuDai() {
        return ChieuDai;
    }

    public void setChieuDai(double ChieuDai) {
        this.ChieuDai = ChieuDai;
    }

    public double getChieuRong() {
        return ChieuRong;
    }

    public void setChieuRong(double ChieuRong) {
        this.ChieuRong = ChieuRong;
    }

    public double getChuVi() {
        return (ChieuDai + ChieuRong) * 2;
    }

    public double getDienTich() {
        return ChieuDai * ChieuRong;
    }

    public String hienThiThongTin() {
        return String.format("HCN(%.6f, %.6f): chu vi = %.3f, dien tich = %.3f",
                ChieuDai, ChieuRong, getChuVi(), getDienTich());
    }
}
