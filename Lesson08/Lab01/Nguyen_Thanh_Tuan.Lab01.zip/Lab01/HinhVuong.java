package com.act.vn.Lesson08.Nguyen_Thanh_Tuan.Lab01;

public class HinhVuong extends HinhChuNhat {

    private double Canh;

    public HinhVuong() {
    }

    public HinhVuong(double Canh) {
        super(Canh, Canh);
        this.Canh = Canh;
    }

    public void setCanh(double Canh) {
        this.Canh = Canh;
    }

    public double getCanh() {
        return Canh;
    }

    @Override
    public double getChuVi() {
        return Canh * 4;
    }

    @Override
    public double getDienTich() {
        return Canh * Canh;
    }

    @Override
    public String hienThiThongTin() {
        return String.format("Hv(canh = %.6f): chu vi = %.3f, dien tich = %.3f",
                Canh, getChuVi(), getDienTich());
    }
}
