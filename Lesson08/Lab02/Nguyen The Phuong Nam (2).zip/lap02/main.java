
package lap02;
//double diemMaDoc, double diemLapTrinhAnToan, double diemDieuTraSo, String nganhHoc, String hoVaTen
import java.util.Scanner;

public class main {
    static Scanner sc = new Scanner(System.in);
    static int M, N , P;
    static int x, y, z;
    static SinhVienATTT[] attt = new SinhVienATTT[105];
    static SinhVienCNTT[] cntt = new SinhVienCNTT[105];
    static SinhVienDTVT[] dtvt = new SinhVienDTVT[105];
    
    public static void input(){
        M = sc.nextInt();
        N = sc.nextInt();
        P = sc.nextInt();
        x = sc.nextInt();
        y = sc.nextInt();
        z = sc.nextInt();
        sc.nextLine();
        
        for(int i = 0; i < M; i++){
            String hoTen = sc.nextLine();
            double md = sc.nextDouble();
            double ltat = sc.nextDouble();
            double dts = sc.nextDouble();
            sc.nextLine();
            attt[i] = new SinhVienATTT(md, ltat, dts, hoTen);
        }
        
        for(int i = 0; i < N; i++){
            String hoTen = sc.nextLine();
            double web = sc.nextDouble();
            double android = sc.nextDouble();
            double nhung = sc.nextDouble();
            sc.nextLine();
            cntt[i] = new SinhVienCNTT(web, android, nhung, hoTen);
        }
        
        for(int i = 0; i < P; i++){
            String hoTen = sc.nextLine();
            double vdk = sc.nextDouble();
            double tds = sc.nextDouble();
            double tkmodule = sc.nextDouble();
            sc.nextLine();
            dtvt[i] = new SinhVienDTVT(vdk, tds, tkmodule, hoTen);
        }
    }
    
    public static void solve(int stt){
        System.out.println("case #" + stt);
        System.out.println(attt[x].hienThiThongTin());
        System.out.println(cntt[y].hienThiThongTin());
        System.out.println(dtvt[z].hienThiThongTin());
        }
    
    public static void main(String[] args) {
        int T = sc.nextInt();
        for(int t = 1; t <= T; t++){
            input();
            solve(t);
        }
    }
}
