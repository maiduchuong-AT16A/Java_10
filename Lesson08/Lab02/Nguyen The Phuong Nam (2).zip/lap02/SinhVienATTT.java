package lap02;
public class SinhVienATTT extends SinhVien{
    private double diemMD;
    private double diemLTAT;
    private double diemDTS;

    public SinhVienATTT(double diemMD, double diemLTAT, double diemDTS, String hoVaTen) {
        super("ATTT", hoVaTen);
        this.diemMD = diemMD;
        this.diemLTAT = diemLTAT;
        this.diemDTS = diemDTS;
    }
  
    @Override
    public double getDiem() {
        return (diemMD * 2 + diemLTAT * 2 + diemDTS) / 5;
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
