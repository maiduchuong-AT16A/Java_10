/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lap02;

/**
 *
 * @author Phuong Nam
 */
public class SinhVienDTVT extends SinhVien{
    private double diemVDK;
    private double diemTDS;
    private double diemTKModule;

    public SinhVienDTVT(double diemVDK, double diemTDS, double diemTKModule, String hoVaTen) {
        super("DTVT", hoVaTen);
        this.diemVDK = diemVDK;
        this.diemTDS = diemTDS;
        this.diemTKModule = diemTKModule;
    }

    
    @Override
    public double getDiem() {
        return (diemVDK * 2 + diemTDS + diemTKModule) / 4;
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
}
