package lap02;
public abstract class SinhVien {
      private String nganhHoc;
    private String hoVaTen;

    public SinhVien(String nganhHoc, String hoVaTen) {
        this.nganhHoc = nganhHoc;
        this.hoVaTen = hoVaTen;
    }

    public String getNganhHoc() {
        return nganhHoc;
    }

    public void setNganhHoc(String nganhHoc) {
        this.nganhHoc = nganhHoc;
    }

    public String getHoVaTen() {
        return hoVaTen;
    }

    public void setHoVaTen(String hoVaTen) {
        this.hoVaTen = hoVaTen;
    }

    public abstract double getDiem();

    public String getHocLuc() {
        double diem = getDiem();
        if (diem < 4.0) {
            return "Yếu";
        } else if (diem < 6.0) {
            return "Trung bình";
        } else if (diem < 7.0) {
            return "Trung bình khá";
        } else if (diem < 8.0) {
            return "Khá";
        } else if (diem < 9.0) {
            return "Giỏi";
        } else {
            return "Xuất sắc";
        }
    }
    public String hienThiThongTin() {
        return String.format("SV: %-20s - %s - %.2f - %s", hoVaTen, nganhHoc, getDiem(), getHocLuc());
    }
}
