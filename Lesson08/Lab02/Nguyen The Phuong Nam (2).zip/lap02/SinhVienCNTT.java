/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lap02;

/**
 *
 * @author Phuong Nam
 */
public class SinhVienCNTT extends SinhVien{
    private double diemWeb;
    private double diemAndroid;
    private double diemNhung;

    public SinhVienCNTT(double diemWeb, double diemAndroid, double diemNhung, String hoVaTen) {
        super("CNTT", hoVaTen);
        this.diemWeb = diemWeb;
        this.diemAndroid = diemAndroid;
        this.diemNhung = diemNhung;
    }

    
    @Override
    public double getDiem() {
        return (diemWeb + diemAndroid * 2 + diemNhung * 2) / 5;
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
}
