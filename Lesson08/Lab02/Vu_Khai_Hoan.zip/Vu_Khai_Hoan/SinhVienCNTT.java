/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.act.vn.Lesson08.Lab02.Vu_Khai_Hoan;

/**
 *
 * @author ACER
 */
public class SinhVienCNTT extends SinhVien{
    private Double diemWeb;
    private Double diemAndroid;
    private Double diemNhung;
    
    public SinhVienCNTT(String name, Double diemWeb, Double diemAndroid, Double diemNhung) {
        super(name, "CNTT");
        this.diemWeb = diemWeb;
        this.diemAndroid = diemAndroid;
        this.diemNhung = diemNhung;
    }

    @Override
    public Double getDiem() {
        return (diemWeb+diemAndroid*2+diemNhung*2)/5;
    }
    
}
