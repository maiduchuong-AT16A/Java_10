/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.act.vn.Lesson08.Lab02.Vu_Khai_Hoan;

/**
 *
 * @author ACER
 */
public class SinhVienATTT extends SinhVien{
    private Double diemMD;
    private Double diemLTAT;
    private Double diemDTS;

    public SinhVienATTT(String name, Double diemMD, Double diemLTAT, Double diemDTS) {
        super(name, "ATTT");
        this.diemMD = diemMD;
        this.diemLTAT = diemLTAT;
        this.diemDTS = diemDTS;
    }    
    
    @Override
    public Double getDiem() {
        return (diemMD*2+diemLTAT*2+diemDTS)/5;
    }
     
}
