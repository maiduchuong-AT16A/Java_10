/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.act.vn.Lesson08.Lab02.Vu_Khai_Hoan;

/**
 *
 * @author ACER
 */
public class SinhVienDTVT extends SinhVien{

    private Double diemTDS;
    private Double diemTKModule;
    private Double diemVDK;
    
    public SinhVienDTVT(String name, Double diemTDS, Double diemTKModule, Double diemVDK) {
        super(name, "CNTT");
        this.diemTDS = diemTDS;
        this.diemTKModule = diemTKModule;
        this.diemVDK = diemVDK;
    }

    @Override
    public Double getDiem() {
        return (diemVDK*2+diemTDS+diemTKModule)/4;
    }
    
}
