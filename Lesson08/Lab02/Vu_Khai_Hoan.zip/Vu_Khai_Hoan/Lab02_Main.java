/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.act.vn.Lesson08.Lab02.Vu_Khai_Hoan;

import java.util.Scanner;

/**
 *
 * @author ACER
 */
public class Lab02_Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int T = sc.nextInt();
        for(int i = 0; i < T; i++) {
            int M = sc.nextInt();
            int N = sc.nextInt();
            int P = sc.nextInt();
            
            int x = sc.nextInt();
            int y = sc.nextInt();
            int z = sc.nextInt();
            
            sc.nextLine();
            SinhVienATTT AT[] = new SinhVienATTT[100];
            for(int j = 0; j < M; j++) {
                String name = sc.nextLine();
                double a = sc.nextDouble();
                double b = sc.nextDouble();
                double c = sc.nextDouble();
                sc.nextLine();
                AT[j] = new SinhVienATTT(name, a, b, c);
            }

            SinhVienCNTT CN[] = new SinhVienCNTT[100];
            for(int j = 0; j < N; j++) {
                String name = sc.nextLine();
                double a = sc.nextDouble();
                double b = sc.nextDouble();
                double c = sc.nextDouble();
                sc.nextLine();
                CN[j] = new SinhVienCNTT(name, a, b, c);
            }

            SinhVienDTVT DT[] = new SinhVienDTVT[100];
            for(int j = 0; j < P; j++) {
                String name = sc.nextLine();
                double a = sc.nextDouble();
                double b = sc.nextDouble();
                double c = sc.nextDouble();
                sc.nextLine();
                DT[j] = new SinhVienDTVT(name, a, b, c);
            }

            System.out.println("Case #"+(i+1)+": ");
            AT[x].hienThiThongTin();
            CN[y].hienThiThongTin();
            DT[z].hienThiThongTin();
        }
    }
}
