/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.act.vn.Lesson08.Lab02.Vu_Khai_Hoan;

/**
 *
 * @author ACER
 */
public abstract class SinhVien {
    private String name;
    private String major;

    public SinhVien(String name, String major) {
        this.name = name;
        this.major = major;
    }
    
    public abstract Double getDiem();

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }
    
    public String getHocLuc() {
        double diem = this.getDiem();
        if(diem < 4.0) {
            return "Yeu";
        } else if(diem < 6) {
            return "Trung binh";
        } else if(diem < 7) {
            return "Trung binh Kha";
        } else if(diem < 8) {
            return "Kha";
        } else if(diem < 9) {
            return "Gioi";
        } else {
            return "Xuat sac";
        }
    }
    
    public void hienThiThongTin() {
        System.out.println(String.format("SV: %s - %s - %.2f - %s", this.name, this.major, this.getDiem(), this.getHocLuc())); 
    }
}
