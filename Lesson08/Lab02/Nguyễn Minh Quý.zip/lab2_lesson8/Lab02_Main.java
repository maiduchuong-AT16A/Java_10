/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab2_lesson8;

import java.util.Scanner;

/**
 *
 * @author OS
 */
public class Lab02_Main {
    static Scanner sc = new Scanner(System.in);
    static int m, n, p, x, y, z;
    static SinhVienCNTT[] ct = new SinhVienCNTT[105];
    static SinhVienATTT[] at = new SinhVienATTT[105];
    static SinhVienDTVT[] dt = new SinhVienDTVT[105];
    
    public static void nhap(){
            m = sc.nextInt();
            n = sc.nextInt();
            p = sc.nextInt();
            x = sc.nextInt();
            y = sc.nextInt();
            z = sc.nextInt();
            sc.nextLine();
            
            for(int j = 0; j < m; j++){
                String ten = sc.nextLine();
                double md = sc.nextDouble();
                double ltat = sc.nextDouble();
                double dts = sc.nextDouble();
                sc.nextLine();
                at[j] = new SinhVienATTT(md, ltat, dts, ten, "ATTT");
            }
            
            for(int j = 0; j < m; j++){
                String ten = sc.nextLine();
                double md = sc.nextDouble();
                double ltat = sc.nextDouble();
                double dts = sc.nextDouble();
                sc.nextLine();
                ct[j] = new SinhVienCNTT(md, ltat, dts, ten, "CNTT");
            }
            for(int j = 0; j < p; j++){
                String ten = sc.nextLine();
                double md = sc.nextDouble();
                double ltat = sc.nextDouble();
                double dts = sc.nextDouble();
                sc.nextLine();
                dt[j] = new SinhVienDTVT(md, ltat, dts, ten, "DTV");
            }
    }
    
    public static void solve(int i){
        System.out.println("Case #" + i);
        System.out.println(at[x].hienThiThongTin());
        System.out.println(ct[y].hienThiThongTin());
        System.out.println(dt[z].hienThiThongTin());
    }
    
    public static void main(String[] args) {
        int t = sc.nextInt();
        for(int i = 1; i <= t; i++){
            nhap();
            solve(i);
        }
    }
}
