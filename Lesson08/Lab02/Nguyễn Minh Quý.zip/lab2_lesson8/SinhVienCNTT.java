/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab2_lesson8;

/**
 *
 * @author OS
 */
public class SinhVienCNTT extends SinhVien{
    double web, android, nhung;

    public SinhVienCNTT(double web, double android, double nhung, String hoTen, String nganhHoc) {
        super(hoTen, nganhHoc);
        this.web = web;
        this.android = android;
        this.nhung = nhung;
    }

    @Override
    double getDiem() {
        return (web + android * 2 + nhung * 2) / 5;
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
