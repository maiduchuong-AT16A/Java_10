/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab2_lesson8;

/**
 *
 * @author OS
 */
public class SinhVienDTVT extends SinhVien{
    double TDS, TKMD, VDK;

    public SinhVienDTVT(double TDS, double TKMD, double VDK, String hoTen, String nganhHoc) {
        super(hoTen, nganhHoc);
        this.TDS = TDS;
        this.TKMD = TKMD;
        this.VDK = VDK;
    }

    @Override
    double getDiem() {
        return (TDS * 2 + TKMD + VDK) / 4;
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
