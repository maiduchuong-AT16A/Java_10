/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab2_lesson8;

/**
 *
 * @author OS
 */
public class SinhVienATTT extends SinhVien{
    double MD, LTAT, DTS;

    public SinhVienATTT(double MD, double LTAT, double DTS, String hoTen, String nganhHoc) {
        super(hoTen, nganhHoc);
        this.MD = MD;
        this.LTAT = LTAT;
        this.DTS = DTS;
    }

    @Override
    double getDiem() {
        return (MD * 2 + LTAT * 2 + DTS) / 5;
    }
}
