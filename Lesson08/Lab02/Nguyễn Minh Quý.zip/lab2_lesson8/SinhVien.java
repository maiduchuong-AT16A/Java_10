/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab2_lesson8;

/**
 *
 * @author OS
 */
public abstract class SinhVien {
    private String hoTen, nganhHoc;

    public SinhVien(String hoTen, String nganhHoc) {
        this.hoTen = hoTen;
        this.nganhHoc = nganhHoc;
    }
    
    abstract double getDiem();

    public String getHoTen() {
        return hoTen;
    }

    public String getNganhHoc() {
        return nganhHoc;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public void setNganhHoc(String nganhHoc) {
        this.nganhHoc = nganhHoc;
    }
    
    String getHocLuc(double diem){
        if(diem < 4.0) return "Yeu";
        else if(4.0 <= diem && diem < 6.0) return "Trung Binh";
        else if(6.0 <= diem && diem < 7.0) return "Trung Binh Kha";
        else if(7.0 <= diem && diem < 8.0) return "Kha";
        else if(8.0 <= diem && diem < 9.0) return "Gioi";
        else return "Xuat Sac";
    }
    
    String hienThiThongTin(){
        return String.format("SV: %-20s - %s - %.2f - %s", hoTen, nganhHoc, getDiem(), getHocLuc(getDiem()));
    }
}
