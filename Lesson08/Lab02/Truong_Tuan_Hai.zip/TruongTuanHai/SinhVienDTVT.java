/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.actvn.lession08.lab02.TruongTuanHai;

/**
 *
 * @author Admin
 */
public class SinhVienDTVT extends SinhVien {

    private double diemTDS;
    private double diemTKModule;
    private double diemVDK;

    public SinhVienDTVT(String hoTen, double diemTDS, double diemTKModule, double diemVDK) {
        super(hoTen, "DTVT");
        this.diemVDK = diemVDK;
        this.diemTDS = diemTDS;
        this.diemTKModule = diemTKModule;
    }

    @Override
    double getDiem() {
        return (diemVDK * 2 + diemTDS + diemTKModule) / 4;
    }
}
