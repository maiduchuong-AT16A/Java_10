/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.actvn.lession08.lab02.TruongTuanHai;

/**
 *
 * @author Admin
 */
public abstract class SinhVien {

    private String HoTen;
    private String NganhHoc;

    public SinhVien(String HoTen, String NganhHoc) {
        this.HoTen = HoTen;
        this.NganhHoc = NganhHoc;
    }

    abstract double getDiem();

    public String getHoTen() {
        return HoTen;
    }

    public void setHoTen(String HoTen) {
        this.HoTen = HoTen;
    }

    public String getNganhHoc() {
        return NganhHoc;
    }

    public void setNganhHoc(String NganhHoc) {
        this.NganhHoc = NganhHoc;
    }

    public String getHocluc() {
        double diem = getDiem();
        if (diem < 4.0) {
            return "Yeu";
        } else if (diem < 6.0) {
            return "Trung binh";
        } else if (diem < 7.0) {
            return "Trung binh kha";
        } else if (diem < 8.0) {
            return "Kha";
        } else if (diem < 9.0) {
            return "Gioi";
        } else {
            return "Xuat sac";
        }
    }

    public String hienThiThongTin() {
        return String.format("SV: %-20s - %s - %.2f - %s", HoTen, NganhHoc, getDiem(), getHocluc());
    }
}
