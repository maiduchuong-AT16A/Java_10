/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.actvn.lession08.lab02.TruongTuanHai;

/**
 *
 * @author Admin
 */
public class SinhVienCNTT extends SinhVien {

    private double diemWeb;
    private double diemAndroid;
    private double diemNhung;

    public SinhVienCNTT(String HoTen, double diemWed, double diemAndroid, double diemNhung) {
        super(HoTen, "CNTT");
        this.diemWeb = diemWed;
        this.diemAndroid = diemAndroid;
        this.diemNhung = diemNhung;
    }

    @Override
    double getDiem() {
        return (diemWeb + diemAndroid * 2 + diemNhung * 2) / 5;
    }
}
