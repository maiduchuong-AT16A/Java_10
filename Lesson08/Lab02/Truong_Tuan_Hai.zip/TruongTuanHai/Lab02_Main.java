/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.actvn.lession08.lab02.TruongTuanHai;

import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class Lab02_Main {

    static Scanner sc = new Scanner(System.in);

    static SinhVienATTT[] attt;
    static SinhVienCNTT[] cntt;
    static SinhVienDTVT[] dtvt;
    static int x, y, z;

    public static void input() {
        int M = sc.nextInt();
        int N = sc.nextInt();
        int P = sc.nextInt();
        sc.nextLine();

        x = sc.nextInt();
        y = sc.nextInt();
        z = sc.nextInt();
        sc.nextLine();

        attt = new SinhVienATTT[M];
        cntt = new SinhVienCNTT[N];
        dtvt = new SinhVienDTVT[P];

        for (int i = 0; i < M; i++) {
            String hoTen = sc.nextLine();
            double diem1 = sc.nextDouble();
            double diem2 = sc.nextDouble();
            double diem3 = sc.nextDouble();
            sc.nextLine();
            attt[i] = new SinhVienATTT(hoTen, diem1, diem2, diem3);
        }

        for (int i = 0; i < N; i++) {
            String hoTen = sc.nextLine();
            double diem1 = sc.nextDouble();
            double diem2 = sc.nextDouble();
            double diem3 = sc.nextDouble();
            sc.nextLine();
            cntt[i] = new SinhVienCNTT(hoTen, diem1, diem2, diem3);
        }

        for (int i = 0; i < P; i++) {
            String hoTen = sc.nextLine();
            double diem1 = sc.nextDouble();
            double diem2 = sc.nextDouble();
            double diem3 = sc.nextDouble();
            sc.nextLine();
            dtvt[i] = new SinhVienDTVT(hoTen, diem1, diem2, diem3);
        }
    }

    public static void solve() {
        System.out.println(attt[x].hienThiThongTin());
        System.out.println(cntt[y].hienThiThongTin());
        System.out.println(dtvt[z].hienThiThongTin());
    }

    public static void main(String[] args) {
        int T = Integer.parseInt(sc.nextLine());
        for (int tc = 1; tc <= T; tc++) {
            input();
            System.out.println("Case #" + tc + ":");
            solve();
        }
        sc.close();
    }
}
