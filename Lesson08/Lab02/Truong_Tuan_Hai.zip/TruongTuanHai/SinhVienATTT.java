/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.actvn.lession08.lab02.TruongTuanHai;

/**
 *
 * @author Admin
 */
public class SinhVienATTT extends SinhVien {

    private double diemMD;
    private double diemLTAT;
    private double diemDTS;

    public SinhVienATTT(String HoTen, double diemMD, double diemLTAT, double diemDTS) {
        super(HoTen, "ATTT");
        this.diemMD = diemMD;
        this.diemLTAT = diemLTAT;
        this.diemDTS = diemDTS;
    }

    @Override
    double getDiem() {
        return (diemMD * 2 + diemLTAT * 2 + diemDTS) / 5;
    }
}
