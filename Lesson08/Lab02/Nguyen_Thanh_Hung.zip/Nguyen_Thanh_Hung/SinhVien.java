package Lesson08.Nguyen_Thanh_Hung;

abstract class SinhVien {
	public SinhVien(String hoTen, String nganh) {
		super();
		this.hoTen = hoTen;
		this.nganh = nganh;
	}
	private String hoTen;
	private String nganh;
	
	public abstract double getDiem();

	public String getHoTen() {
		return hoTen;
	}

	public void setHoTen(String hoTen) {
		this.hoTen = hoTen;
	}

	public String getNganhHoc() {
		return nganh;
	}

	public void setNganhHoc(String nganhHoc) {
		this.nganh = nganh;
	}
	
	public String getHocLuc() {
        double diem = getDiem();
        if (diem < 4.0) {
            return "Yếu";
        } else if (diem >= 4.0 && diem < 6.0) {
            return "Trung bình";
        } else if (diem >= 6.0 && diem < 7.0) {
            return "Trung bình khá";
        } else if (diem >= 7.0 && diem < 8.0) {
            return "Khá";
        } else if (diem >= 8.0 && diem < 9.0) {
            return "Giỏi";
        } else {
            return "Xuất sắc";
        }
    }
	public void hienThiThongTin() {
        System.out.printf("SV: %s – %s – %.2f – %s%n", 
                         hoTen, nganh, getDiem(), getHocLuc());
    }
}
	

