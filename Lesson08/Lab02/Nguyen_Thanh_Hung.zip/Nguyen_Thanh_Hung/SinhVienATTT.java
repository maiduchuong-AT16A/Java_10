package Lesson08.Nguyen_Thanh_Hung;

public class SinhVienATTT extends SinhVien {
	private double diemMD;
	private double diemLTAT;
	private double diemDTS;
	
	
	public SinhVienATTT(String hoTen, double diemMD, double diemLTAT, double diemDTS) {
        super(hoTen, "ATTT");
        this.diemMD = diemMD;
        this.diemLTAT = diemLTAT;
        this.diemDTS = diemDTS;
    }


	@Override
	public double getDiem() {
		// TODO Auto-generated method stub
		return (diemMD * 2 + diemLTAT * 2 + diemDTS) / 5;
	}

}
