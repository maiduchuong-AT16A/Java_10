package Lesson08.Nguyen_Thanh_Hung;

class SinhVienDTVT extends SinhVien {
    private double diemTDS;
    private double diemTKModule;
    private double diemVDK;
    
    public SinhVienDTVT(String hoTen, double diemTDS, double diemTKModule, double diemVDK) {
        super(hoTen, "DTVT");
        this.diemTDS = diemTDS;
        this.diemTKModule = diemTKModule;
        this.diemVDK = diemVDK;
    }
    
    @Override
    public double getDiem() {
        return (diemVDK * 2 + diemTDS + diemTKModule) / 4;
    }
}
