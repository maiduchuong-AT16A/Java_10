package Lesson08.Nguyen_Thanh_Hung;

import java.util.*;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int T = sc.nextInt();
		for (int t = 1; t <= T; t++) {
			int M = sc.nextInt();
			int N = sc.nextInt();
			int P = sc.nextInt();

			int x = sc.nextInt();
			int y = sc.nextInt();
			int z = sc.nextInt();
			sc.nextLine();

			SinhVien[] sinhVienATTT = new SinhVien[M];
			SinhVien[] sinhVienCNTT = new SinhVien[N];
			SinhVien[] sinhVienDTVT = new SinhVien[P];

			for (int i = 0; i < M; i++) {
				String hoTen = sc.nextLine();
				double diemMD = sc.nextDouble();
				double diemLTAT = sc.nextDouble();
				double diemDTS = sc.nextDouble();
				sc.nextLine();
				sinhVienATTT[i] = new SinhVienATTT(hoTen, diemMD, diemLTAT, diemDTS);
			}

			for (int i = 0; i < N; i++) {
				String hoTen = sc.nextLine();
				double diemWeb = sc.nextDouble();
				double diemAndroid = sc.nextDouble();
				double diemNhung = sc.nextDouble();
				sc.nextLine();
				sinhVienCNTT[i] = new SinhVienCNTT(hoTen, diemWeb, diemAndroid, diemNhung);
			}

			for (int i = 0; i < P; i++) {
				String hoTen = sc.nextLine();
				double diemTDS = sc.nextDouble();
				double diemTKModule = sc.nextDouble();
				double diemVDK = sc.nextDouble();
				sc.nextLine();
				sinhVienDTVT[i] = new SinhVienDTVT(hoTen, diemTDS, diemTKModule, diemVDK);
			}

			System.out.println("Case #" + t);

			sinhVienATTT[x].hienThiThongTin();

			sinhVienCNTT[y].hienThiThongTin();

			sinhVienDTVT[z].hienThiThongTin();

		}

	}
}
