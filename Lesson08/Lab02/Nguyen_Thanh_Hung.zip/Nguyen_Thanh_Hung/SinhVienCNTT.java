package Lesson08.Nguyen_Thanh_Hung;

public class SinhVienCNTT extends SinhVien {
	    private double diemWeb;
	    private double diemAndroid;
	    private double diemNhung;
	    
	    public SinhVienCNTT(String hoTen, double diemWeb, double diemAndroid, double diemNhung) {
	        super(hoTen, "CNTT");
	        this.diemWeb = diemWeb;
	        this.diemAndroid = diemAndroid;
	        this.diemNhung = diemNhung;
	    }
	    
	    @Override
	    public double getDiem() {
	        return (diemWeb + diemAndroid * 2 + diemNhung * 2) / 5;
	    }
	
}
