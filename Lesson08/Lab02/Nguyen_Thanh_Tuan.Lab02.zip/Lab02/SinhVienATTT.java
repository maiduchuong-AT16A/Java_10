package com.act.vn.Lesson08.Nguyen_Thanh_Tuan.Lab02;

public class SinhVienATTT extends SinhVien {

    private double diemMD, diemLTAT, diemDTS;

    public SinhVienATTT(String HoTen, double diemMD, double diemLTAT, double diemDTS) {
        super(HoTen, "ATTT");
        this.diemMD = diemMD;
        this.diemLTAT = diemLTAT;
        this.diemDTS = diemDTS;
    }

    @Override
    double getDiem() {
        return (diemMD * 2 + diemLTAT * 2 + diemDTS) / 5;
    }

}
