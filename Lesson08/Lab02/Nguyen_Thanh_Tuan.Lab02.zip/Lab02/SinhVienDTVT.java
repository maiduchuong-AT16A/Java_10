package com.act.vn.Lesson08.Nguyen_Thanh_Tuan.Lab02;

public class SinhVienDTVT extends SinhVien {

    private double diemVDK, diemTDS, diemTKModule;

    public SinhVienDTVT(String hoTen, double diemTDS, double diemTKModule, double diemVDK) {
        super(hoTen, "DTVT");
        this.diemVDK = diemVDK;
        this.diemTDS = diemTDS;
        this.diemTKModule = diemTKModule;
    }

    @Override
    double getDiem() {
        return (diemVDK * 2 + diemTDS + diemTKModule) / 4;
    }

}
