package com.act.vn.Lesson08.Nguyen_Thanh_Tuan.Lab02;

import java.util.Scanner;

public class Lab02_Main {

    static Scanner sc = new Scanner(System.in);

    static int M, N, P, x, y, z;
    static SinhVienATTT at[] = new SinhVienATTT[100];
    static SinhVienCNTT ct[] = new SinhVienCNTT[100];
    static SinhVienDTVT dt[] = new SinhVienDTVT[100];

    static void input() {
        M = sc.nextInt();
        N = sc.nextInt();
        P = sc.nextInt();
        sc.nextLine();

        x = sc.nextInt();
        y = sc.nextInt();
        z = sc.nextInt();
        sc.nextLine();

        for (int i = 0; i < M; i++) {
            String hoTen = sc.nextLine();
            double diem1 = sc.nextDouble();
            double diem2 = sc.nextDouble();
            double diem3 = sc.nextDouble();
            sc.nextLine();
            at[i] = new SinhVienATTT(hoTen, diem1, diem2, diem3);
        }

        for (int i = 0; i < N; i++) {
            String hoTen = sc.nextLine();
            double diem1 = sc.nextDouble();
            double diem2 = sc.nextDouble();
            double diem3 = sc.nextDouble();
            sc.nextLine();
            ct[i] = new SinhVienCNTT(hoTen, diem1, diem2, diem3);
        }
        1
        2 2 2
1 1 0
Nguyen Van A 
        1,0 6,5 3,9 
Nguyen Van B 
        0,4 0,5 4,1 
Tran Cong C 
        6,4 1,3 7,4 
Tran Dinh D 
        3,0 9,8 7,4 
Dinh Manh E 
        4,6 3,7 7,7 
Duong Dinh F 
        9,4 6,5 7,2 
        for (int i = 0; i < P; i++) {
            String hoTen = sc.nextLine();
            double diem1 = sc.nextDouble();
            double diem2 = sc.nextDouble();
            double diem3 = sc.nextDouble();
            sc.nextLine();
            dt[i] = new SinhVienDTVT(hoTen, diem1, diem2, diem3);
        }
    }

    static void solve(int stt) {
        System.out.printf("Case #%d:\n", stt);
        System.out.println(at[x].hienThiThongTin());
        System.out.println(ct[y].hienThiThongTin());
        System.out.println(dt[z].hienThiThongTin());
    }

    public static void main(String[] args) {
        int T = sc.nextInt();
        for (int i = 0; i < T; i++) {
            input();
            solve(i + 1);
        }
    }
}
