package com.act.vn.Lesson08.Nguyen_Thanh_Tuan.Lab02;

public class SinhVienCNTT extends SinhVien {

    private double diemWeb, diemAndroid, diemNhung;

    public SinhVienCNTT(String HoTen, double diemWed, double diemAndroid, double diemNhung) {
        super(HoTen, "CNTT");
        this.diemWeb = diemWed;
        this.diemAndroid = diemAndroid;
        this.diemNhung = diemNhung;
    }

    @Override
    double getDiem() {
        return (diemWeb + diemAndroid * 2 + diemNhung * 2) / 5;
    }

}
