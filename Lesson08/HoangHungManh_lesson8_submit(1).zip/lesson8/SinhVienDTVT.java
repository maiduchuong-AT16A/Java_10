/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lesson8;

/**
 *
 * @author manh
 */
public class SinhVienDTVT extends SinhVien {
    public double diemVDK;
    public double diemTDS;
    public double diemTKModule;
    public SinhVienDTVT(double diemVDK, double diemTDS, double diemTKModule, String HoTen, String NganHoc) {
        super(HoTen, NganHoc);
        this.diemVDK = diemVDK;
        this.diemTDS = diemTDS;
        this.diemTKModule = diemTKModule;
    }
    @Override
    public double getDiem() {
        return (diemVDK * 2 + diemTDS + diemTKModule) / 4;

    }

}
