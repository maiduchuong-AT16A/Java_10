/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lesson8;

/**
 *
 * @author manh
 */
public class SinhVienATTT extends SinhVien {

    public double diemMD;
    public double diemLTAT;
    public double diemDTS;

    public SinhVienATTT(double diemMD, double diemLTAT, double diemDTS, String HoTen, String NganHoc) {
        super(HoTen, NganHoc);
        this.diemMD = diemMD;
        this.diemLTAT = diemLTAT;
        this.diemDTS = diemDTS;
    }
    @Override
    public double getDiem() {
        return (diemMD * 2 + diemLTAT * 2 + diemDTS) / 5;
    }

}
