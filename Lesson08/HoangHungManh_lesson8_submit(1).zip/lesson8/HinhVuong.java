/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lesson8;

/**
 *
 * @author manh
 */
public class HinhVuong extends abHinhChuNhat {

    public double canh;
    public HinhVuong(double canh) {
        super.chieudai = canh;
        super.chieurong = canh;
        this.canh = canh;
    }
    public void setCanh(double canh) {
        this.canh = canh;
    }
    public double getCanh() {
        return canh;
    }
    public HinhVuong() {
    }
    @Override
    public double getChuVi() {
        return this.canh * 4;
    }
    @Override
    public double getDienTich() {
        return this.canh * this.canh;
    }
    @Override
    public void hienThiThongTIn() {
        System.out.printf("HV(%.6f):", this.canh);
        System.out.printf("chu vi = %.3f," , getChuVi());
        System.out.printf("dien tich =%.3f" , getDienTich());
    }
    public static void main(String[] args) {
        HinhVuong hv = new HinhVuong(20);
        hv.hienThiThongTIn();
        
    }
}
