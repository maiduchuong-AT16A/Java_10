/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lesson8;

/**
 *
 * @author manh
 */
public class SinhVienCNTT extends SinhVien {

    public double diemWeb;
    public double diemAndroid;
    public double diemNhung;

    public SinhVienCNTT(double diemWeb, double diemAndroid, double diemNhung, String HoTen, String NganHoc) {
        super(HoTen, NganHoc);
        this.diemWeb = diemWeb;
        this.diemAndroid = diemAndroid;
        this.diemNhung = diemNhung;
    }
    
    @Override
    public double getDiem() {
        return (diemWeb + diemAndroid * 2 + diemNhung * 2)/5;
    }
    
    
}
