/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lesson8;

import java.util.Locale;

/**
 *
 * @author manh
 */
public abstract class SinhVien {

    public String HoTen;
    public String NganhHoc;

    public SinhVien(String HoTen, String NganHoc) {
        this.HoTen = HoTen;
        this.NganhHoc = NganHoc;
    }

    public String getHoTen() {
        return HoTen;
    }

    public void setHoTen(String HoTen) {
        this.HoTen = HoTen;
    }

    public String getNganhHoc() {
        return NganhHoc;
    }

    public void setNganHoc(String NganHoc) {
        this.NganhHoc = NganHoc;
    }

    public abstract double getDiem();

    public String getHocLuc() {
        double diem = getDiem();
        if (diem < 4.0) return "Yeu";
        else if (diem < 6.0) return "Trung binh";
        else if (diem < 7.0) return "Trung binh kha";
        else if (diem < 8.0) return "Kha";
        else if (diem < 9.0) return "Gioi";
        else return "Xuat sac";
    }
    public String hienThiThongTin() {
    return String.format("SV: %-20s – %s – %.2f – %s\n", HoTen, NganhHoc, getDiem(), getHocLuc());
    }
}
