/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lesson8;

import java.util.Scanner;

/**
 *
 * @author manh
 */
public class Lap02_Main {

    static Scanner sc = new Scanner(System.in);
    static int M, N, P, x, y, z;
    static SinhVienATTT[] svAttt = new SinhVienATTT[100];
    static SinhVienDTVT[] svDtvt = new SinhVienDTVT[100];
    static SinhVienCNTT[] svCntt = new SinhVienCNTT[100];

    static void input() {
        M = sc.nextInt();

        N = sc.nextInt();
        P = sc.nextInt();
        x = sc.nextInt();
        y = sc.nextInt();
        z = sc.nextInt();
        sc.nextLine(); // Clear buffer
        for (int i = 0; i < M; i++) {
            String HoTen = sc.nextLine();
            double diem1 = sc.nextDouble();
            double diem2 = sc.nextDouble();
            double diem3 = sc.nextDouble();
            sc.nextLine(); // Clear buffer

            svAttt[i] = new SinhVienATTT(diem1, diem2, diem3, HoTen, "ATTT");
        }
        for (int i = 0; i < N; i++) {
            String HoTen = sc.nextLine();
            double diem1 = sc.nextDouble();
            double diem2 = sc.nextDouble();
            double diem3 = sc.nextDouble();
            sc.nextLine(); // Clear buffer
            svCntt[i] = new SinhVienCNTT(diem1, diem2, diem3, HoTen, "CNTT");
        }
        for (int i = 0; i < P; i++) {
            String HoTen = sc.nextLine();
            double diem1 = sc.nextDouble();
            double diem2 = sc.nextDouble();
            double diem3 = sc.nextDouble();
            sc.nextLine(); // Clear buffer
            svDtvt[i] = new SinhVienDTVT(diem1, diem2, diem3, HoTen, "DTVT");
        }
    }

    static void solve(int stt) {
        System.out.println("Case #" + stt);
        System.out.println(svAttt[x].hienThiThongTin());
        System.out.println(svCntt[y].hienThiThongTin());
        System.out.println(svDtvt[z].hienThiThongTin());
    }

    public static void main(String[] args) {
        int T = sc.nextInt();
        for (int t = 0; t < T; t++) {
            input();
            solve(t + 1);
        }
    }

}
