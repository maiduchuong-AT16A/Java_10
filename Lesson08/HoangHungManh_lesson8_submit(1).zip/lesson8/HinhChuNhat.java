/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lesson8;

/**
 *
 * @author manh
 */
public class HinhChuNhat {

    public double chieudai;
    public double chieurong;

    public HinhChuNhat() {
    }

    public HinhChuNhat(double chieudai, double chieurong) {
        this.chieudai = chieudai;
        this.chieurong = chieurong;
    }

    public double getChieudai() {
        return chieudai;
    }

    public void setChieudai(double chieudai) {
        this.chieudai = chieudai;
    }

    public double getChieurong() {
        return chieurong;
    }

    public void setChieurong(double chieurong) {
        this.chieurong = chieurong;
    }

    public double getChuvi() {
        return Math.round((this.chieudai + this.chieurong) * 2 * 1000.0) / 1000.0;
    }

    public double getDienTich() {
        return Math.round(this.chieudai * this.chieurong * 1000.0) / 1000.0;
    }

    public void hienThiThongTIn() {
        System.out.printf("HCN(%.6f,%.6f):", this.chieudai, this.chieurong);
        System.out.printf("chu vi = %.3f,", getChuvi());
        System.out.printf("dien tich = %.3f\n", getDienTich());
    }

    public static void main(String[] args) {
        HinhChuNhat hinhchunhat = new HinhChuNhat(20.2, 20.5);
        hinhchunhat.hienThiThongTIn();

    }
}
