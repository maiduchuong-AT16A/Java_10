/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.act.vn.Lession08.Nguyen_Van_Kien;

/**
 *
 * @author Admin
 */
public class SinhVienDTVT extends SinhVien {

    private double diemTDS, diemTKM, diemVDK;

    public SinhVienDTVT(String hoTen, double diemTDS, double diemTKM, double diemVDK) {
        super(hoTen, "DTVT");
        this.diemTDS = diemTDS;
        this.diemTKM = diemTKM;
        this.diemVDK = diemVDK;
    }

    @Override
    public double getDiem() {
        return (diemVDK * 2 + diemTDS + diemTKM) / 4;

//throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
