/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.act.vn.Lession08.Nguyen_Van_Kien;

/**
 *
 * @author Admin
 */
public abstract class SinhVien {

    private String hoTen;
    private String nganh;

    public SinhVien(String hoTen, String nganh) {
        this.hoTen = hoTen;
        this.nganh = nganh;
    }

    public abstract double getDiem();

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public String getNganh() {
        return nganh;
    }

    public void setNganh(String nganh) {
        this.nganh = nganh;
    }

    public String getHocLuc() {
        double diem = getDiem();
        if (diem < 4) {
            return "Yeu";
        }
        if (diem < 6) {
            return "Trung binh";
        }
        if (diem < 7) {
            return "Trung binh kha";
        }
        if (diem < 8) {
            return "Kha";
        }
        if (diem < 9) {
            return "Gioi";
        }
        return "Xuat sac";
    }

    public String hienThiThongTin() {
        return String.format("SV:%20s - %s - %.2f - %s", hoTen, nganh, getDiem(), getHocLuc());
    }
}
