/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.act.vn.Lession08.Nguyen_Van_Kien;

/**
 *
 * @author Admin
 */
public class SinhVienCNTT extends SinhVien {
    private double diemW,diemA,diemN;
    public SinhVienCNTT(String hoTen, double diemW, double diemA, double diemN) {
        super(hoTen, "CNTT");
        this.diemW = diemW;
        this.diemA = diemA;
        this.diemN = diemN;
    }

    @Override
    public double getDiem() {
        return (diemW + diemA*2 + diemN*2)/5;
//throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
