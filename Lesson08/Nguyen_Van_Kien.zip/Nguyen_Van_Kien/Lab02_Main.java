/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.act.vn.Lession08.Nguyen_Van_Kien;

/**
 *
 * @author Admin
 */
import java.util.*;

public class Lab02_Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int T = Integer.parseInt(sc.nextLine());

        for (int test = 1; test <= T; test++) {
            String[] parts = sc.nextLine().split(" ");
            int M = Integer.parseInt(parts[0]);
            int N = Integer.parseInt(parts[1]);
            int P = Integer.parseInt(parts[2]);

            String[] idx = sc.nextLine().split(" ");
            int x = Integer.parseInt(idx[0]);
            int y = Integer.parseInt(idx[1]);
            int z = Integer.parseInt(idx[2]);

            SinhVienATTT[] svATTT = new SinhVienATTT[M];
            SinhVienCNTT[] svCNTT = new SinhVienCNTT[N];
            SinhVienDTVT[] svDTVT = new SinhVienDTVT[P];

            for (int i = 0; i < M; i++) {
                String hoTen = sc.nextLine();
                String[] d = sc.nextLine().split(" ");
                double md = Double.parseDouble(d[0]);
                double ltat = Double.parseDouble(d[1]);
                double dts = Double.parseDouble(d[2]);
                svATTT[i] = new SinhVienATTT(hoTen, md, ltat, dts);
            }

            for (int i = 0; i < N; i++) {
                String hoTen = sc.nextLine();
                String[] d = sc.nextLine().split(" ");
                double web = Double.parseDouble(d[0]);
                double android = Double.parseDouble(d[1]);
                double nhung = Double.parseDouble(d[2]);
                svCNTT[i] = new SinhVienCNTT(hoTen, web, android, nhung);
            }

            for (int i = 0; i < P; i++) {
                String hoTen = sc.nextLine();
                String[] d = sc.nextLine().split(" ");
                double tds = Double.parseDouble(d[0]);
                double tk = Double.parseDouble(d[1]);
                double vdk = Double.parseDouble(d[2]);
                svDTVT[i] = new SinhVienDTVT(hoTen, tds, tk, vdk);
            }

            System.out.println("Case #" + test);
            System.out.println(svATTT[x - 1].hienThiThongTin());
            System.out.println(svCNTT[y - 1].hienThiThongTin());
            System.out.println(svDTVT[z - 1].hienThiThongTin());
        }
    }

}
