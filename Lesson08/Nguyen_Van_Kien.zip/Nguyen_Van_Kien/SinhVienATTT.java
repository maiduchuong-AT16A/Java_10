/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.act.vn.Lession08.Nguyen_Van_Kien;

/**
 *
 * @author Admin
 */
public class SinhVienATTT extends SinhVien{
    private double diemMD,diemLTAT,diemDTS;

    public SinhVienATTT(String hoTen, double diemMD,double diemLTAT,double diemDTS) {
        super(hoTen,"ATTT" );
        this.diemMD = diemMD;
        this.diemLTAT = diemLTAT;
        this.diemDTS = diemDTS;
        
    }

    @Override
    public double getDiem() {
        return (diemMD*2 + diemLTAT*2 + diemDTS);
//throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
