/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.actvn.lession09.lab02.TruongTuanHai;

/**
 *
 * @author Admin
 */
public class FullTimeEmployee extends Employee {

    public FullTimeEmployee(String name, int paymentPerHour) {
        super(name, paymentPerHour);
    }

    @Override
    public int calculateSalary() {
        return super.getPaymentPerHour() * 8;
    }

    @Override
    public void showinfo() {
        System.out.printf("Full time employee:\n");
        System.out.printf("Name: %s, salary per day: %d\n", super.getName(), calculateSalary());
    }
}
