/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.actvn.lession09.lab02.TruongTuanHai;

/**
 *
 * @author Admin
 */
public class PartTimeEmployee extends Employee {

    private int workingHours;

    public PartTimeEmployee(String name, int paymentPerHour, int workingHours) {
        super(name, paymentPerHour);
        this.workingHours = workingHours;
    }

    @Override
    public int calculateSalary() {
        return super.getPaymentPerHour() * workingHours;
    }

    @Override
    public void showinfo() {
        System.out.printf("Part time employee:\n");
        System.out.printf("Name: %s, salary per day: %d\n", super.getName(), calculateSalary());
    }

}
