/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.act.Lession09.NguyenVanKien;

/**
 *
 * @author Admin
 */
import java.util.*;

public class Lab02_Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        FullTimeEmployee nvft[] = new FullTimeEmployee[105];
        int p[] = new int[105];
        int q[] = new int[105];
        PartTimeEmployee nvpt[] = new PartTimeEmployee[105];
        int T = sc.nextInt();
        for (int t = 1; t <= T; t++) {
            int M = sc.nextInt();
            int N = sc.nextInt();
            int P = sc.nextInt();
            int Q = sc.nextInt();
            for (int i = 0; i < M; i++) {
                sc.nextLine();
                String name = sc.nextLine();
                int luongMoiGio = sc.nextInt();

                nvft[i] = new FullTimeEmployee(name, luongMoiGio);
            }
            for (int i = 0; i < N; i++) {
                sc.nextLine();
                String name = sc.nextLine();
                int luongMoiGio = sc.nextInt();
                int soGioLam = sc.nextInt();

                nvpt[i] = new PartTimeEmployee(name, luongMoiGio, soGioLam);
            }
            for (int i = 0; i < P; i++) {
                p[i] = sc.nextInt();
            }
            for (int i = 0; i < Q; i++) {
                q[i] = sc.nextInt();
            }
            System.out.println("Case" + t + ":");
            System.out.println("Full time employee:");
            for (int i = 0; i < P; i++) {
                nvft[p[i]].showInfo();
            }
            System.out.println("\nPart time employee:");
            for (int i = 0; i < Q; i++) {
                nvpt[q[i]].showInfo();
            }
        }
    }
}
