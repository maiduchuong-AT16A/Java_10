/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.act.Lession09.NguyenVanKien;

/**
 *
 * @author Admin
 */
public class PartTimeEmployee extends Employee{
    int workingHours;

    public PartTimeEmployee(String name, int paymentPerHour, int workingHours) {
        super(name, paymentPerHour);
        this.workingHours = workingHours;
    }
    public int calculateSalary(){
        return paymentPerHour * workingHours;
    }
    public void showInfo(){
        System.out.printf("%s, salary per day: %d",name,calculateSalary());
    }
}
