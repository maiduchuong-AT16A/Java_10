/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lb02;

/**
 *
 * @author manh
 */
public class Employee implements IEmployee,IShow{
    String name;
    int paymentPerHour;

    public Employee(String name, int paymentPerHour) {
        this.name = name;
        this.paymentPerHour = paymentPerHour;
    }
    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public int calculateSlary() {
        return paymentPerHour;
    }

    @Override
    public void showInfo() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
