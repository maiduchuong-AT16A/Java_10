/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lb02;

/**
 *
 * @author manh
 */
public class PartTimeEmployee extends Employee{
    int workingHours;

    public PartTimeEmployee(int workingHours, String name, int paymentPerHour) {
        super(name, paymentPerHour);
        this.workingHours = workingHours;
    }
    public int calculateSalary()
    {
        return paymentPerHour*this.workingHours;
    }
    @Override
    public void showInfo() {
        System.out.println("Part time employee:");
        System.out.println("Name: " + name + ", salary per day: " + calculateSalary());
    }
}
