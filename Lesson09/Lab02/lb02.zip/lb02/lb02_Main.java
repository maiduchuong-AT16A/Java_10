/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lb02;

import java.util.Scanner;

/**
 *
 * @author manh
 */
public class lb02_Main {

    static Scanner sc = new Scanner(System.in);

    static int M, N, P, Q;
    static FullTimeEmployee employees[] = new FullTimeEmployee[105];
    static PartTimeEmployee employees1[] = new PartTimeEmployee[105];
    static int p[] = new int[105];
    static int q[] = new int[105];

    static void input() {
    M = sc.nextInt();
    N = sc.nextInt();
    P = sc.nextInt();
    Q = sc.nextInt();
    sc.nextLine(); // bỏ dòng thừa

    for (int i = 0; i < M; i++) {
        String hoten = sc.nextLine();  // Tên có thể có dấu cách
        int luong = sc.nextInt();
        sc.nextLine(); // bỏ dòng sau lương
        employees[i] = new FullTimeEmployee(hoten, luong);
    }

    for (int i = 0; i < N; i++) {
        String hoten = sc.nextLine();  // Tên part-time
        int luong = sc.nextInt();
        int gio = sc.nextInt();
        sc.nextLine(); // bỏ dòng sau giờ
        employees1[i] = new PartTimeEmployee(gio, hoten, luong);
    }

    for (int i = 0; i < P; i++) {
        p[i] = sc.nextInt();
    }

    for (int i = 0; i < Q; i++) {
        q[i] = sc.nextInt();
    }
}


    static void solve(int stt) {
        System.out.println("Case #" + stt);
        for (int i = 0; i < P; i++) {
            employees[p[i]].showInfo();
        }

        for (int i = 0; i < Q; i++) {
          employees1[q[i]].showInfo();
        }
    }

    public static void main(String[] args) {

        int T = sc.nextInt();

        for (int i = 0; i < T; i++) {
            input();
            solve(i + 1);
        }
    }
}
