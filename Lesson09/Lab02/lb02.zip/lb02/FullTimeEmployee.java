/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lb02;

/**
 *
 * @author manh
 */
public class FullTimeEmployee extends Employee{
    
    public FullTimeEmployee(String name, int paymentPerHour) {
        super(name, paymentPerHour);
    }
    public int calculateSalary()
    {
        return 8*paymentPerHour;
    }
    @Override
     public void showInfo() {
        System.out.println("Full time employee:");
        System.out.println("Name: " + name + ", salary per day: " + calculateSalary());
    }

    
}
