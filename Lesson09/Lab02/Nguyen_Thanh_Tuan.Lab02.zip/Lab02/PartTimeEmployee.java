package com.act.vn.Lesson09.Nguyen_Thanh_Tuan.Lab02;

public class PartTimeEmployee extends Employee {

    private int workingHours;

    public PartTimeEmployee(String name, int paymentPerHour, int workingHours) {
        super(name, paymentPerHour);
        this.workingHours = workingHours;
    }

    @Override
    public int calculateSalary() {
        return getPaymentPerHour() * workingHours;
    }

    @Override
    public void showInfo() {
        System.out.println("Part time employee:");
        System.out.printf("Name: %s, salary per day: %d\n", getName(), calculateSalary());
    }

}
