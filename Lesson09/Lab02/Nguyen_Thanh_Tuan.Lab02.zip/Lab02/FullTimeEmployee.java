package com.act.vn.Lesson09.Nguyen_Thanh_Tuan.Lab02;

public class FullTimeEmployee extends Employee {

    public FullTimeEmployee(String name, int paymentPerHour) {
        super(name, paymentPerHour);
    }

    @Override
    public int calculateSalary() {
        return getPaymentPerHour() * 8;
    }

    @Override
    public void showInfo() {
        System.out.println("Full time employee:");
        System.out.printf("Name: %s, salary per day: %d\n", getName(), calculateSalary());
    }
}
