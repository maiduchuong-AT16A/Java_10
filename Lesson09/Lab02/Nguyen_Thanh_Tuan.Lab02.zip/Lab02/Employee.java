package com.act.vn.Lesson09.Nguyen_Thanh_Tuan.Lab02;

public abstract class Employee implements IEmployee, IShow {

    private String name;
    private int paymentPerHour;

    public Employee(String name, int paymentPerHour) {
        this.name = name;
        this.paymentPerHour = paymentPerHour;
    }

    @Override
    public String getName() {
        return name;
    }

    public int getPaymentPerHour() {
        return paymentPerHour;
    }

}
