package com.act.vn.Lesson09.Nguyen_Thanh_Tuan.Lab02;

import java.util.Scanner;

public class Lab02_Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int T = Integer.parseInt(sc.nextLine());
        int M, N, P, Q;

        for (int t = 1; t <= T; t++) {
            M = sc.nextInt();
            N = sc.nextInt();
            sc.nextLine();

            P = sc.nextInt();
            Q = sc.nextInt();
            sc.nextLine();

            FullTimeEmployee[] full = new FullTimeEmployee[M];
            PartTimeEmployee[] part = new PartTimeEmployee[N];

            for (int i = 0; i < M; i++) {
                String name = sc.nextLine();
                int pay = Integer.parseInt(sc.nextLine());
                full[i] = new FullTimeEmployee(name, pay);
            }

            for (int i = 0; i < N; i++) {
                String name = sc.nextLine();
                String[] tokens = sc.nextLine().split(" ");
                int pay = Integer.parseInt(tokens[0]);
                int hours = Integer.parseInt(tokens[1]);
                part[i] = new PartTimeEmployee(name, pay, hours);
            }

            int[] posFull = new int[P];
            int[] posPart = new int[Q];

            for (int i = 0; i < P; i++) {
                posFull[i] = sc.nextInt();
            }
            for (int i = 0; i < Q; i++) {
                posPart[i] = sc.nextInt();
            }

            System.out.println("Case #" + t + ":");

            //System.out.println("Full time employee:");
            for (int i : posFull) {
                full[i].showInfo();
            }

            //System.out.println("Part time employee:");
            for (int i : posPart) {
                part[i].showInfo();
            }
        }
    }
}
