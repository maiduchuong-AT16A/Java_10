package com.act.vn.Lesson09.Nguyen_Thanh_Tuan.Lab02;

public interface IShow {

    void showInfo();
}
