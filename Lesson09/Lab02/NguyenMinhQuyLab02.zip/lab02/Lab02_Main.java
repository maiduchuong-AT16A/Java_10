/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lesson09.lab02;

/**
 *
 * @author Admin
 */
import java.util.Scanner;
public class Lab02_Main {
    static Scanner sc = new Scanner(System.in);
    static int M, N, P, Q;
    static FullTimeEmployee nvft[] = new FullTimeEmployee[105];
    static PartTimeEmployee nvpt[] = new PartTimeEmployee[105];
    static int p[] = new int[104];
    static int q[] = new int[104];
    
    
    
    static void input(){
        M = sc.nextInt();
        N = sc.nextInt();
        P = sc.nextInt();
        Q = sc.nextInt();
                
        
        for(int i = 0; i < M; i++){
            sc.nextLine();
            String ten = sc.nextLine();
            
            int luongMoiGio = sc.nextInt();
            nvft[i] = new FullTimeEmployee(ten, luongMoiGio);
        }
        
        for(int i = 0; i < N; i++){
            sc.nextLine();
            String ten = sc.nextLine();
            
            int luongMoiGio = sc.nextInt();
            int gioLamViec = sc.nextInt();
            nvpt[i] = new PartTimeEmployee(ten, luongMoiGio, gioLamViec );
        }
        
        for(int i = 0; i < P; i++){
            p[i] = sc.nextInt();
        }
        
        for(int i = 0; i < Q; i++){
            q[i] = sc.nextInt();
        }
    }
    
    static void solve(int stt){
        System.out.println("Case #" + stt);
        System.out.println("Full time employee:");
        for(int i = 0; i < P; i++){
            nvft[p[i]].showinfo();
        }
        System.out.println("Part time employee: ");
        for(int i = 0; i < Q; i++){
            nvpt[q[i]].showinfo();
        }
    }
    
    public static void main(String[] args) {
        int t = sc.nextInt();
        for(int i = 1; i <= t; i++){
            input();
            solve(i);
        }
    }
}
