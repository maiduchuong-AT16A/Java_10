package lessonn9.lap02;
public abstract class Employee implements IEmployee, IShow{
    private String name;
    private int paymentperHour;

    public Employee(String name, int paymentperHour) {
        this.name = name;
        this.paymentperHour = paymentperHour;
    }

    public int getPaymentperHour() {
        return paymentperHour;
    }

    public void setPaymentperHour(int paymentperHour) {
        this.paymentperHour = paymentperHour;
    }
    
    

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public abstract int calculateSlary();

    @Override
    public void showInfo(){
        
    };
    
}
