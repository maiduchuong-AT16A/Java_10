package lessonn9.lap02;
public interface IShow {
   void showInfo(); 
}
