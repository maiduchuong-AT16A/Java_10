package lessonn9.lap02;
public class PartTimeEmployee extends Employee{
    private int workingHour;

    public PartTimeEmployee(String name, int paymentperHour, int workingHour) {
        super(name, paymentperHour);
        this.workingHour = workingHour;
    }
    

    @Override
    public int calculateSlary() {
        return super.getPaymentperHour() * this.workingHour;
    }

    @Override
    public void showInfo() {
        System.out.println("Part time employee:");
        System.out.printf("Name: %s, salary per day: %d \n", super.getName(), calculateSlary());
    }
    
}
