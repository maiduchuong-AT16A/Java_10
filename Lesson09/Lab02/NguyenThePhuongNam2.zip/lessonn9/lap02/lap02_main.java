package lessonn9.lap02;

import java.util.Scanner;

public class lap02_main {
    static Scanner sc = new Scanner(System.in);
    static FullTimeEmployee FT[] = new FullTimeEmployee[105];
    static PartTimeEmployee PT[] = new PartTimeEmployee[105];
    static int M, N, P, Q;
    static int p[] = new int[105];
    static int q[] = new int[105];
    
    static void input(){
        M = sc.nextInt();
        N = sc.nextInt();
        P = sc.nextInt();
        Q = sc.nextInt();

        for(int i = 0; i < M; i++){
            sc.nextLine();
            String name = sc.nextLine();
            int pay = sc.nextInt();
            FT[i] = new FullTimeEmployee(name, pay);
        }
        
        for(int i = 0; i < M; i++){
            sc.nextLine();
            String name = sc.nextLine();
            int hour = sc.nextInt();
            int pay = sc.nextInt();
            PT[i] = new PartTimeEmployee(name, pay, hour);
        }
        
        for(int i = 0; i < P; i++){
            p[i] = sc.nextInt();
        }
        
        for(int i = 0; i < Q; i++){
            q[i] = sc.nextInt();
        }
    }
    
    static void slove(int stt){
        System.out.println("case #" + stt);
        for(int i = 0; i < P; i++){
            PT[p[i]].showInfo();
        }
        for(int i = 0; i < Q; i++){
            FT[q[i]].showInfo();
        }
    }
    
    
    public static void main(String[] args) {
        int T = sc.nextInt();
        for(int i = 0; i < T; i++){
            input();
            slove(i + 1);
        }
    }
}
