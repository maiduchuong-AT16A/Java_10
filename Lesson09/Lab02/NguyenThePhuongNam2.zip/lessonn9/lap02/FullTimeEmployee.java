package lessonn9.lap02;
public class FullTimeEmployee extends Employee{

    public FullTimeEmployee(String name, int paymentperHour) {
        super(name, paymentperHour);
    }

    @Override
    public int calculateSlary() {
        return super.getPaymentperHour() * 8;
    }

    @Override
    public void showInfo() {
        System.out.println("Full time employee:");
        System.out.printf("Name: %s, salary per day: %d \n", super.getName(), calculateSlary());
    }
    
    
    
}
