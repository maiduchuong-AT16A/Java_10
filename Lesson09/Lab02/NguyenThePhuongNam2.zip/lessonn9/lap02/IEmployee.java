package lessonn9.lap02;
public interface IEmployee {
    String getName();
    int calculateSlary();
}
