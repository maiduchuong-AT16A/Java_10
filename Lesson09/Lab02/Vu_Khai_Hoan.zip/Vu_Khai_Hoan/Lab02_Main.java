/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.act.vn.Lesson09.Lab02.Vu_Khai_Hoan;

import java.util.Scanner;

/**
 *
 * @author ACER
 */
public class Lab02_Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int T = sc.nextInt();
        for(int i = 0; i < T; i++) {
            int M = sc.nextInt();
            int N = sc.nextInt();
            int P = sc.nextInt();
            int Q = sc.nextInt();
            
            
            
            FullTimeEmployee ft[] = new FullTimeEmployee[M];
            for(int j = 0; j < M; j++) {
                sc.nextLine();
                String name = sc.nextLine();
                int s = sc.nextInt();
                ft[j] = new FullTimeEmployee(name, s);
            }
            
            PartTimeEmployee pt[] = new PartTimeEmployee[N];
            for(int j = 0; j < N; j++){
                sc.nextLine();
                String name = sc.nextLine();
                int s = sc.nextInt();
                int h = sc.nextInt();
                pt[j] = new PartTimeEmployee(name, s, h);
            }
            
            int arrP[] = new int[P];
            for(int j = 0; j < P; j++) {
                int p = sc.nextInt();
                arrP[j] = p;
            }
            
            int arrQ[] = new int[Q];
            for(int j = 0; j < Q; j++) {
                int q = sc.nextInt();
                arrQ[j] = q;
            }
            
            System.out.println("Case #"+(i+1)+": ");
            for(int j = 0; j < P; j++) {
                ft[arrP[j]].showInfo();
            }
            for(int j = 0; j < Q; j++) {
                pt[arrQ[j]].showInfo();
            }
        }
    }
}
