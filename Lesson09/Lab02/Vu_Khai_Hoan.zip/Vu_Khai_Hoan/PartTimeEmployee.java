/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.act.vn.Lesson09.Lab02.Vu_Khai_Hoan;

/**
 *
 * @author ACER
 */
public class PartTimeEmployee extends Employee{
    private int workingHour;

    public PartTimeEmployee(String name, int paymentPerHour, int workingHour) {
        super(name, paymentPerHour);
        this.workingHour = workingHour;
    }

    @Override
    public int calculateSalary() {
        return this.getPaymentPerHour() * workingHour;
    }

    @Override
    public void showInfo() {
        System.out.println("Part time employee: ");
        System.out.println("Name: " + this.getName() + ", " + "salary per day: " + this.calculateSalary());
    }

    @Override
    public String getName() {
        return super.getName(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }
    
}
