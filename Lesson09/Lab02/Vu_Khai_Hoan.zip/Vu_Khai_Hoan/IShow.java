/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.act.vn.Lesson09.Lab02.Vu_Khai_Hoan;

/**
 *
 * @author ACER
 */
public interface IShow {
    void showInfo();
}
