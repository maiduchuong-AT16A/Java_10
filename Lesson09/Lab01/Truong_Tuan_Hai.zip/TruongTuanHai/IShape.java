/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.actvn.lession09.lab01.TruongTuanHai;

/**
 *
 * @author Admin
 */
public interface IShape {

    double getPerimeter();

    double getArea();

    void show();
}
