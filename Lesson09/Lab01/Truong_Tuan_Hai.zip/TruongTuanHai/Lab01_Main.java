/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.actvn.lession09.lab01.TruongTuanHai;

import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class Lab01_Main {

    static Scanner sc = new Scanner(System.in);

    static int M, N, P, Q;
    static Rectangle HCN[] = new Rectangle[105];
    static Circle HT[] = new Circle[105];
    static int p[] = new int[105];
    static int q[] = new int[105];

    static void input() {
        M = sc.nextInt();
        N = sc.nextInt();
        P = sc.nextInt();
        Q = sc.nextInt();

        for (int i = 0; i < M; i++) {
            double chieuDai = sc.nextDouble();
            double chieuRong = sc.nextDouble();
            HCN[i] = new Rectangle(chieuDai, chieuRong);
        }

        for (int i = 0; i < N; i++) {
            double banKinh = sc.nextDouble();
            HT[i] = new Circle(banKinh);
        }

        for (int i = 0; i < P; i++) {
            p[i] = sc.nextInt();
        }

        for (int i = 0; i < Q; i++) {
            q[i] = sc.nextInt();
        }
    }

    static void solve(int stt) {
        System.out.println("Case #" + stt);
        for (int i = 0; i < P; i++) {
            HCN[p[i]].show();
        }

        for (int i = 0; i < Q; i++) {
            HT[q[i]].show();
        }
    }

    public static void main(String[] args) {

        int T = sc.nextInt();

        for (int i = 0; i < T; i++) {
            input();
            solve(i + 1);
        }
    }
}
