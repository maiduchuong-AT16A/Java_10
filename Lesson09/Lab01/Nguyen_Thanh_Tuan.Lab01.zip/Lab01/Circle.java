package com.act.vn.Lesson09.Nguyen_Thanh_Tuan.Lab01;

public class Circle implements IShape {

    private double radius;

    public Circle(double radius) {
        this.radius = radius;
    }

    @Override
    public double getPerimeter() {
        return 2 * Math.PI * radius;
    }

    @Override
    public double getArea() {
        return Math.PI * radius * radius;
    }

    @Override
    public String toString() {
        return String.format("Circle(r = %.6f): perimeter = %.3f, area = %.3f", radius, getPerimeter(), getArea());
    }

}
