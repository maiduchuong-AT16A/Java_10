package com.act.vn.Lesson09.Nguyen_Thanh_Tuan.Lab01;

public interface IShape {

    double getPerimeter();

    double getArea();

}
