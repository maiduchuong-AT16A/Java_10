package com.act.vn.Lesson09.Nguyen_Thanh_Tuan.Lab01;

public class Rectangle implements IShape {

    private double length;
    private double width;

    public Rectangle(double length, double width) {
        this.length = length;
        this.width = width;
    }

    @Override
    public double getPerimeter() {
        return 2 * (length + width);
    }

    @Override
    public double getArea() {
        return length * width;
    }

    @Override
    public String toString() {
        return String.format("Rectangle(%.6f, %.6f): perimeter = %.3f, area = %.3f", length, width, getPerimeter(), getArea());
    }
}
