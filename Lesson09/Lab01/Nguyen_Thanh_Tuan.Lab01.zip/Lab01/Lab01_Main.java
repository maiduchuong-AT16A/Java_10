package com.act.vn.Lesson09.Nguyen_Thanh_Tuan.Lab01;

import java.util.Scanner;

public class Lab01_Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int T = sc.nextInt();

        for (int t = 1; t <= T; t++) {
            int M = sc.nextInt();
            int N = sc.nextInt();
            int P = sc.nextInt();
            int Q = sc.nextInt();

            Rectangle[] rectangle = new Rectangle[M];
            Circle[] circle = new Circle[N];

            for (int i = 0; i < M; i++) {
                double length = sc.nextDouble();
                double width = sc.nextDouble();
                rectangle[i] = new Rectangle(length, width);
            }

            for (int i = 0; i < N; i++) {
                double radius = sc.nextDouble();
                circle[i] = new Circle(radius);
            }

            int[] posRec = new int[P];
            int[] posCir = new int[Q];

            for (int i = 0; i < P; i++) {
                posRec[i] = sc.nextInt();
            }
            for (int i = 0; i < Q; i++) {
                posCir[i] = sc.nextInt();
            }
            System.out.println("Case #" + t + ":");

            for (int i = 0; i < P; i++) {
                System.out.println(rectangle[posRec[i]].toString());
            }
            for (int i = 0; i < Q; i++) {
                System.out.println(circle[posCir[i]].toString());
            }
        }
    }
}
