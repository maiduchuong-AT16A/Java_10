/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lesson09.lab01;

/**
 *
 * @author Admin
 */
import java.util.Scanner;
public class Lab01Main {
    
    static Scanner sc = new Scanner(System.in);
    static int M, N, P, Q;
    static Rectangle hcn[] = new Rectangle[100];
    static Circle ht[] = new Circle[100];
    static int p[] = new int[100];
    static int q[] = new int[100];
    
    static void input(){
        M = sc.nextInt();
        N = sc.nextInt();
        P = sc.nextInt();
        Q = sc.nextInt();
        
        for(int i = 0; i< M; i++){
            double dai = sc.nextDouble();
            double rong = sc.nextDouble();
            hcn[i] = new Rectangle(dai, rong);
        }
        
        for(int i = 0; i< N; i++){
            double bankinh = sc.nextDouble();
            ht[i] = new Circle(bankinh);
        }
        
        for(int i = 0; i < P; i++){
            p[i] = sc.nextInt();
        }
        
        for(int i = 0; i < Q; i++){
            q[i] = sc.nextInt();
        }
    }
    
    static void solve(int stt){
        System.out.println("Case #" + stt);
        for(int i = 0; i < P; i++){
            hcn[p[i]].show();
        }
        
        for(int i = 0; i < Q; i++){
            ht[q[i]].show();
        }
    }
    
    public static void main(String[] args) {
        int t = sc.nextInt();
        for(int i = 1; i <= t; i++){
            input();
            solve(t);
        }
    }
}
