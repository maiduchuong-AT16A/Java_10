/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lesson09.lab01;

/**
 *
 * @author Admin
 */
public class Circle implements IShape{
    double radius;

    @Override
    public double getPerimeter() {
        return 2 * Math.PI * radius;
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public double getArea() {
        
        return Math.PI * radius * radius;
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void show() {
        System.out.printf("Circle(r = %.6f): perimetr = %.3f, area = %.3f/n", radius, getPerimeter(), getArea());
        
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public Circle(double radius) {
        this.radius = radius;
    }
    
}
