/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lab01;

/**
 *
 * @author manh
 */
public class HinhChuNhat implements IHinhHoc{
    double chieudai;
    double chieurong;
    public HinhChuNhat(double chieudai, double chieurong) {
        this.chieudai = chieudai;
        this.chieurong = chieurong;
    }
    
    @Override
    public double tinhChuVi() {
        return (this.chieudai+this.chieurong)*2;
    }

    @Override
    public double tinhDienTich() {
        return this.chieudai*this.chieurong;
    }

    @Override
    public void xuatThongTin() {
        System.out.printf("HCN(%.3f, %.3f): chu vi=%.3f, dien tich=%.3f\n",this.chieudai,this.chieurong,tinhChuVi(),tinhDienTich());
    }
}
