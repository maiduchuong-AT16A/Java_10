/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lab01;

/**
 *
 * @author manh
 */
public class Solution {
    public static void main(String[] args) {
        HinhChuNhat a = new HinhChuNhat(5,4);
        HinhTron b = new HinhTron(5);
        a.xuatThongTin();
        b.xuatThongTin();
        
    }
}
