/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lab01;

/**
 *
 * @author manh
 */
public class HinhTron implements IHinhHoc {
    double bankinh;

    public HinhTron(double bankinh) {
        this.bankinh = bankinh;
    }
    
    
    @Override
    public double tinhChuVi() {
        return 2*PI*this.bankinh ;
    }

    @Override
    public double tinhDienTich() {
        return PI*this.bankinh*this.bankinh;
    }

    @Override
    public void xuatThongTin() {
        System.out.printf("HT(%.3f): chu vi=%.3f, dien tich=%.3f\n",this.bankinh,tinhChuVi(),tinhDienTich());
    }

}
