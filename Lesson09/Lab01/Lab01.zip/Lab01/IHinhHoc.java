/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lab01;

/**
 *
 * @author manh
 */
public interface IHinhHoc {
    public final double  PI = 3.14159;
    double tinhChuVi();
    double tinhDienTich();
    void xuatThongTin();
}
