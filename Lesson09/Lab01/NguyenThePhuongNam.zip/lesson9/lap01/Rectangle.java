
package lesson9.lap01;

public class Rectangle implements IShape{
    private double length;
    private double width;

    public Rectangle(double length, double width) {
        this.length = length;
        this.width = width;
    }

    @Override
    public double getPerimeter() {
        return 2 * (length + width);
    }

    @Override
    public double getArea() {
        return length * width;
    }

    @Override
    public void show() {
        System.out.printf("Rectangle(%.6f, %.6f): perimeter = %.3f, area = %.3f\n", length, width, getPerimeter(),getArea());
    }
    
    
}
