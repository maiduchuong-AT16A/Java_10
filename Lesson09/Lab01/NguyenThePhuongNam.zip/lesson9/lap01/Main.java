package lesson9.lap01;

import java.util.Scanner;

public class Main {
    static Scanner sc = new Scanner(System.in);
    static int M, N, P, Q;
    static Rectangle[] HCN = new Rectangle[105];
    static Circle[] HV = new Circle[105];
    static int[] p = new int[105];
    static int[] q = new int[105];

    static void input() {
        M = sc.nextInt(); 
        N = sc.nextInt(); 
        P = sc.nextInt(); 
        Q = sc.nextInt(); 

        for (int i = 0; i < M; i++) {
            double dai = sc.nextDouble();
            double rong = sc.nextDouble();
            HCN[i] = new Rectangle(dai, rong);
        }

        for (int i = 0; i < N; i++) {
            double r = sc.nextDouble();
            HV[i] = new Circle(r);
        }

        for (int i = 0; i < P; i++) {
            p[i] = sc.nextInt();
        }

        for (int i = 0; i < Q; i++) {
            q[i] = sc.nextInt();
        }
    }

    static void solve(int stt) {
        System.out.println("Case #" + stt);
        for (int i = 0; i < P; i++) {
            HCN[p[i]].show();
        }
        for (int i = 0; i < Q; i++) {
            HV[q[i]].show();
        }
    }

    public static void main(String[] args) {
        int T = sc.nextInt();
        for (int i = 0; i < T; i++) {
            input();
            solve(i + 1);
        }
    }
}
