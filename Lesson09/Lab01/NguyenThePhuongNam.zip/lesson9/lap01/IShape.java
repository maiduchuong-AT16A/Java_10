/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package lesson9.lap01;

/**
 *
 * @author Phuong Nam
 */
public interface IShape {
    double getPerimeter();
    double getArea();
    void show();
    
}
