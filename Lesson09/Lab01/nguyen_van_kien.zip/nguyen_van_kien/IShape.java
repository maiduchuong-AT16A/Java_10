/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.act.lession09.nguyen_van_kien;

/**
 *
 * @author Admin
 */
public interface IShape {
    double PI = 3.14159;
    double getPerimeter();
    double getArea();
    void show();
}
