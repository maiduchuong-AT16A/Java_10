/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.act.lession09.nguyen_van_kien;

/**
 *
 * @author Admin
 */
import java.util.Scanner;

public class Lap01_Main {

    public static void main(String[] args) {
        Rectangle hcn[] = new Rectangle[100];
        Circle htr[] = new Circle[100];
        int p[] = new int[100];
        int q[] = new int[100];
        Scanner sc = new Scanner(System.in);
        int T = sc.nextInt();
        for (int t = 1; t < T; t++) {
            int M = sc.nextInt();
            int N = sc.nextInt();
            int P = sc.nextInt();
            int Q = sc.nextInt();
            for (int i = 0; i < M; i++) {
                double dai = sc.nextDouble();
                double rong = sc.nextDouble();
                hcn[i] = new Rectangle(dai, rong);
            }
            for (int i = 0; i < N; i++) {
                double banKinh = sc.nextDouble();
                htr[i] = new Circle(banKinh);
            }
            for (int i = 0; i < P; i++) {
                p[i] = sc.nextInt();
            }
            for (int i = 0; i < Q; i++) {
                q[i] = sc.nextInt();
            }
            System.out.printf("Case#%d:\n", t);
            for (int i = 0; i < P; i++) {
                hcn[p[i]].show();
                System.out.println("");
            }
            for (int i = 0; i < Q; i++) {
                htr[q[i]].show();
                System.out.println("");
            }
        }
    }
}
