/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.act.vn.Lesson09.Lab01.Vu_Khai_Hoan;

/**
 *
 * @author ACER
 */
public class Circle implements IShape{
    private double radius;

    public Circle(double radius) {
        this.radius = radius;
    }
    
    @Override
    public double getPerimeter() {
        return 2 * Math.PI * this.radius;
    }

    @Override
    public double getArea() {
        return Math.PI * this.radius * this.radius;
    }

    @Override
    public void show() {
        System.out.printf("Circle(r = %f): perimeter = %.3f, area = %.3f", this.radius, this.getPerimeter(), this.getArea());
    }
    
    
}
