/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.act.vn.Lesson09.Lab01.Vu_Khai_Hoan;

import java.util.Scanner;

/**
 *
 * @author ACER
 */
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int T = sc.nextInt();
        for(int i = 0; i < T; i++) {
            int M = sc.nextInt();
            int N = sc.nextInt();
            int P = sc.nextInt();
            int Q = sc.nextInt();
            
            Rectangle arrhcn[] = new Rectangle[M];
            for(int j = 0; j < M; j++) {
                double l = sc.nextDouble();
                double w = sc.nextDouble();
                arrhcn[j] = new Rectangle(l, w);
            }
            
            Circle arrht[] = new Circle[N];
            for(int j = 0; j < N; j++) {
                double r = sc.nextDouble();
                arrht[j] = new Circle(r);
            }

            int arrp[] = new int[P];
            for(int j = 0; j < P; j++) {
                int p = sc.nextInt();
                arrp[j] = p;
            }
            
            int arrq[] = new int[Q];
            for(int j = 0; j < Q; j++) {
                int q = sc.nextInt();
                arrq[j] = q;
            }

            System.out.println("Case #"+(i+1)+": ");
            for(int j = 0; j < P; j++) {
                arrhcn[arrp[j]].show();
                System.out.println("");
            }
            for(int j = 0; j < Q; j++) {
                arrht[arrq[j]].show();
                System.out.println("");
            }            
        }
    }

}
