import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.File;

public class Solution {

    static String viTrituongDoi(MyCircle b[], int i, int j) {
        double distance = (b[i].getI().getX() - b[j].getI().getX()) * ((b[i].getI().getX() - b[j].getI().getX()))
                + (b[i].getI().getY() - b[j].getI().getY()) * (b[i].getI().getY() - b[j].getI().getY());
        if (distance < Math.abs(b[i].getR() - b[j].getR())) {
            return String.format("Circle %d is inside Circle %d", i, j);
        }
        else if (Math.sqrt(distance) > b[i].getR() + b[j].getR()) {
            return String.format("Circle %d does not intersect Circle %d", i, j);
        } else {
            return String.format("Circle %d is intersects with Circle %d", i, j);
        } 
    }

    public static void main(String[] args) throws FileNotFoundException {
        Scanner sc = new Scanner(new File("E:\\input.txt"));

        int t = sc.nextInt();
        MyPoint a[] = new MyPoint[100];
        MyCircle b[] = new MyCircle[100];
        while (t-- != 0) {
            int n = sc.nextInt();
            if (n >= 2) {
                for (int i = 0; i < n; i++) {
                    double x = sc.nextDouble();
                    double y = sc.nextDouble();
                    a[i] = new MyPoint();
                    a[i].setXY(x, y);
                }
            }
            int k = sc.nextInt();
            double x1 = sc.nextDouble();
            double y1 = sc.nextDouble();
            int p = sc.nextInt();
            int m = sc.nextInt();
            for (int i = 0; i < m; i++) {
                double x2 = sc.nextDouble();
                double y2 = sc.nextDouble();
                MyPoint c = new MyPoint(x2, y2);
                b[i] = new MyCircle(c, 0);

            }
            for (int i = 0; i < m; i++) {
                double r = sc.nextDouble();
                b[i].setR(r);
            }
            int q = sc.nextInt();
            int i = sc.nextInt();
            int j = sc.nextInt();

            int count = 1;
            System.out.printf("CASE #%d:\n", count++);
            System.out.printf("distance = %3f\n", a[k].getDistance(x1, y1));
            System.out.println(a[p].toString());
            System.out.println(b[q].toString());
            System.out.println(viTrituongDoi(b, i, j));

        }
    }

}
