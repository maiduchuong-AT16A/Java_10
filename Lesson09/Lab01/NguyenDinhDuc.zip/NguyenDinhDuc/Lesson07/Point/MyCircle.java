public class MyCircle {

    private MyPoint I;
    private double r;

    public MyCircle() {
        this.I = new MyPoint(0, 0);
        this.r = 0;
    }

    public MyCircle(int x, int y, double r) {
        this.I = new MyPoint(x, y);
        this.r = r;
    }

    public MyCircle(MyPoint i, double r) {
        this.I = i;
        this.r = r;
    }

    public MyPoint getI() {
        return I;
    }

    public void setI(MyPoint i) {
        I = i;
    }

    public double getR() {
        return r;
    }

    public void setR(double r) {
        this.r = r;
    }

    public void setRandI(MyPoint i, double r) {
        setI(i);
        setR(r);
    }

    public double getCircumference() {
        return 2 * Math.PI * r;
    }

    public double getArea() {
        return Math.PI * r * r;
    }

    @Override
    public String toString() {
        return String.format("Circle info: (%.2f, %.2f), radius = %.2f, circumference = %.3f, area = %.3f", this.I.getX(),
                this.I.getY(), this.r, getCircumference(), getArea());
    }

}