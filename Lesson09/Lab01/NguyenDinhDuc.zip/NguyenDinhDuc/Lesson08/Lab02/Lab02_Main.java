package Lab02;

import java.util.Scanner;

public class Lab02_Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int T = sc.nextInt();
        int count = 1;

        while (T-- != 0) {
            int M = sc.nextInt();
            int N = sc.nextInt();
            int P = sc.nextInt();
            int x = sc.nextInt();
            int y = sc.nextInt();
            int z = sc.nextInt();
            SinhVienATTT a[] = new SinhVienATTT[M];
            SinhVienCNTT b[] = new SinhVienCNTT[N];
            SinhVienDTVT c[] = new SinhVienDTVT[P];
            sc.nextLine();
            for (int i = 0; i < M; i++) {
                String hoten = sc.nextLine();
                double diemMD = sc.nextDouble();
                double diemLTAT = sc.nextDouble();
                double diemDTS = sc.nextDouble();
                sc.nextLine();
                a[i] = new SinhVienATTT(hoten, diemMD, diemLTAT, diemDTS);
            }

            for (int i = 0; i < N; i++) {
                String hoten = sc.nextLine();
                double diemWeb = sc.nextDouble();
                double diemAndroid = sc.nextDouble();
                double diemNhung = sc.nextDouble();
                sc.nextLine();
                b[i] = new SinhVienCNTT(hoten, diemWeb, diemAndroid, diemNhung);
            }

            for (int i = 0; i < P; i++) {
                String hoten = sc.nextLine();
                double diemTDS = sc.nextDouble();
                double diemTKModule = sc.nextDouble();
                double diemVDK = sc.nextDouble();
                sc.nextLine();
                c[i] = new SinhVienDTVT(hoten, diemTDS, diemTKModule, diemVDK);
            }

            System.out.printf("Case #%d:", count++);
            System.out.println();
            a[x].hienThiThongTin();
            System.out.println();
            b[y].hienThiThongTin();
            System.out.println();
            c[z].hienThiThongTin();
            System.out.println();

        }
    }
}