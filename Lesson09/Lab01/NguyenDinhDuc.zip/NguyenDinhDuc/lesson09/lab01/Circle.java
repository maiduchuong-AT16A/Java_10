package lesson09.lab01;

public class Circle implements Ishape {

    private double radius;

    
    public Circle(double radius) {
        this.radius = radius;
    }
    public double getRadius() {
        return radius;
    }
    @Override
    public double getPerimeter() {
        return Math.PI*2*radius;
    }
    @Override
    public double getArea() {
        return Math.PI*radius*radius;
    }
    @Override
    public void show() {
        System.out.printf("Circle(r = %.6f): perimeter = %.3f, area = %.3f\n",getRadius(),getPerimeter(),getArea());
    }
    
    
}
