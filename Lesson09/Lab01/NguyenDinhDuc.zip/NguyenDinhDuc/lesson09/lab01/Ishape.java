package lesson09.lab01;

public interface Ishape {
 public double getPerimeter();
 public double getArea();
 public void show();
}
