package lesson09.lab01;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Lab01_Main {
    public static void main(String[] args) throws FileNotFoundException {
        File file = new File("E:\\input.txt");
        Scanner sc = new Scanner(file);
         

        int T = sc.nextInt();
        Rectangle a[] = new Rectangle[100];
        Circle b[] = new Circle[100];
        int count = 1;
        while (T-- != 0) {
            int M = sc.nextInt();
            int N = sc.nextInt();
            int P = sc.nextInt();
            int Q = sc.nextInt();

            for (int i = 0; i < M; i++) {
                double length = sc.nextDouble();
                double width = sc.nextDouble();
                a[i] = new Rectangle(length, width);
            }
            for (int i = 0; i < N; i++) {
                double radius = sc.nextDouble();
                b[i] = new Circle(radius);
            }

            int p = P;
            int q = Q;

            System.out.printf("CASE #%d:\n", count++);
            for (int i = 0; i < p; i++) {
                int index = sc.nextInt();
                a[index].show();
            }
            for (int i = 0; i < q; i++) {
                int index = sc.nextInt();
                b[index].show();
            }

        }
    }
}
