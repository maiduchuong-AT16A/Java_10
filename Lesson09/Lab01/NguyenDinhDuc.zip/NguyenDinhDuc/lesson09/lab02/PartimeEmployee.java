package lesson09.lab02;

public class PartimeEmployee extends Employee {

   private  int workingHours;
    public PartimeEmployee(String name, int paymentPerHour, int workingHours) {
        super(name, paymentPerHour);
        this.workingHours = workingHours;
    }
    @Override
    public int calculateSalary() {
       return workingHours*getPaymentPerHour();
    }

    
}
