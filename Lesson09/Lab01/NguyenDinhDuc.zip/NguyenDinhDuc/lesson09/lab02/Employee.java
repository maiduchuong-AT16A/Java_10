package lesson09.lab02;
public class Employee implements IShow, IEmployee{
    private String name;
    private int paymentPerHour;
   
    public Employee(String name, int paymentPerHour) {
        this.name = name;
        this.paymentPerHour = paymentPerHour;
    }
    @Override
    public String getName() {
       return name;
    }
     public int getPaymentPerHour() {
        return paymentPerHour;
    }
    @Override
    public int calculateSalary() {
        return calculateSalary();
    }
    @Override
    public void showinfo() {
        System.out.printf("Name: %s, salary per day: %d\n",getName(),calculateSalary());
    }
}