package lesson09.lab02;

public interface IShow {
    public void showinfo();
}
