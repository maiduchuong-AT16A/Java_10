package lesson09.lab02;

public interface IEmployee {
    public String getName();
    public int calculateSalary();
}
