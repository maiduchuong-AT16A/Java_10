package lesson09.lab02;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Lab2_Main {
    public static void main(String[] args) throws FileNotFoundException {
        File file = new File("E:\\input.txt");
        Scanner sc = new Scanner(file);
        int T = sc.nextInt();
        PartimeEmployee a[] = new PartimeEmployee[100];
        FullTimeEmployee b[] = new FullTimeEmployee[100];
        int count = 1;
        while (T-- != 0) {
            int M = sc.nextInt();
            int N = sc.nextInt();
            int P = sc.nextInt();
            int Q = sc.nextInt();
            sc.nextLine();
            for (int i = 0; i < M; i++) {
                String name = sc.nextLine();
                int paymentPerHour = sc.nextInt();
                b[i] = new FullTimeEmployee(name, paymentPerHour);
                sc.nextLine();
            }
            for (int i = 0; i < N; i++) {
                String name = sc.nextLine();
                int paymentPerHour = sc.nextInt();
                int workingHours = sc.nextInt();
                a[i] = new PartimeEmployee(name, paymentPerHour, workingHours);
                sc.nextLine();
            }
            System.out.printf("CASE #%d:\n", count++);

            for (int i = 0; i < P; i++) {
                System.out.println("Full time employee:");
                int index = sc.nextInt();
                b[index].showinfo();
            }

            for (int i = 0; i < Q; i++) {
                System.out.println("Part time employee:");
                int index = sc.nextInt();
                a[index].showinfo();
            }
        }
    }
}
